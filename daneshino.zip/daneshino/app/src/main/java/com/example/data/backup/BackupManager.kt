package com.example.data.backup

import com.example.data.local.AssignmentEntity
import com.example.data.local.ClassSessionEntity
import com.example.data.local.CourseAttachmentEntity
import com.example.data.local.CourseEntity
import com.example.data.local.ExamEntity
import com.example.data.local.FlashcardDeckEntity
import com.example.data.local.FlashcardEntity
import com.example.data.local.GoalEntity
import com.example.data.local.NoteEntity
import com.example.data.local.StudySessionEntity
import com.example.data.prefs.ReminderLeadTime
import com.example.data.prefs.ReminderMethod
import com.example.data.prefs.UserPreferences
import com.example.data.prefs.UserPreferencesRepository
import com.example.data.repository.DaneshinoRepository
import com.example.ui.theme.AppThemeMode
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

@JsonClass(generateAdapter = true)
data class BackupProfileDto(
    val studentName: String = "",
    val university: String = "",
    val major: String = "",
    val degreeLevel: String = "",
    val currentTerm: String = "",
    val totalDegreeCredits: Double = 140.0,
    val themeMode: String = AppThemeMode.SYSTEM.storageKey,
    val classRemindersEnabled: Boolean = true,
    val classReminderMinutesBefore: Int = ReminderLeadTime.DEFAULT_MINUTES,
    val classReminderMethod: String = ReminderMethod.NOTIFICATION.storageKey,
    val assignmentRemindersEnabled: Boolean = true,
    val examRemindersEnabled: Boolean = true
)

@JsonClass(generateAdapter = true)
data class BackupCourseDto(
    val id: Long,
    val name: String,
    val code: String = "",
    val credits: Double = 3.0,
    val instructorName: String = "",
    val instructorEmail: String = "",
    val instructorPhone: String = "",
    val instructorOffice: String = "",
    val instructorNotes: String = "",
    val term: String = "",
    val courseType: String = "تخصصی",
    val colorArgb: Int = 0xFF3B82F6.toInt(),
    val description: String = "",
    val isFavorite: Boolean = false,
    val grade: Double? = null,
    val createdAtMillis: Long = 0L
)

@JsonClass(generateAdapter = true)
data class BackupSessionDto(
    val id: Long,
    val courseId: Long,
    val dayOfWeek: Int,
    val startMinuteOfDay: Int,
    val endMinuteOfDay: Int,
    val roomNumber: String = "",
    val building: String = "",
    val notes: String = "",
    val repeatWeekly: Boolean = true
)

@JsonClass(generateAdapter = true)
data class BackupAssignmentDto(
    val id: Long,
    val courseId: Long? = null,
    val title: String,
    val description: String = "",
    val dueAtMillis: Long,
    val priority: String,
    val status: String,
    val reminderMinutesBefore: Int? = null,
    val createdAtMillis: Long = 0L
)

@JsonClass(generateAdapter = true)
data class BackupExamDto(
    val id: Long,
    val courseId: Long? = null,
    val title: String,
    val examAtMillis: Long,
    val location: String = "",
    val syllabus: String = "",
    val notes: String = "",
    val reminderMinutesBefore: Int? = 60,
    val createdAtMillis: Long = 0L
)

@JsonClass(generateAdapter = true)
data class BackupStudySessionDto(
    val id: Long,
    val courseId: Long? = null,
    val courseNameSnapshot: String = "",
    val startAtMillis: Long,
    val endAtMillis: Long,
    val durationSeconds: Long,
    val dateKey: String
)

@JsonClass(generateAdapter = true)
data class BackupGoalDto(
    val id: Long,
    val title: String,
    val period: String,
    val targetMinutes: Int,
    val courseId: Long? = null,
    val createdAtMillis: Long = 0L
)

@JsonClass(generateAdapter = true)
data class BackupDeckDto(
    val id: Long,
    val title: String,
    val courseId: Long? = null,
    val description: String = "",
    val createdAtMillis: Long = 0L
)

@JsonClass(generateAdapter = true)
data class BackupFlashcardDto(
    val id: Long,
    val deckId: Long,
    val front: String,
    val back: String,
    val knownCount: Int = 0,
    val reviewCount: Int = 0,
    val lastReviewedAtMillis: Long? = null
)

@JsonClass(generateAdapter = true)
data class BackupNoteDto(
    val id: Long,
    val courseId: Long? = null,
    val title: String,
    val content: String,
    val category: String = "عمومی",
    val updatedAtMillis: Long = 0L
)

@JsonClass(generateAdapter = true)
data class BackupAttachmentDto(
    val id: Long,
    val courseId: Long,
    val displayName: String,
    val uriString: String,
    val mimeType: String = "",
    val attachmentType: String = "OTHER",
    val addedAtMillis: Long = 0L
)

@JsonClass(generateAdapter = true)
data class DaneshinoBackupPayload(
    val appName: String = "Daneshino",
    val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
    val exportedAtMillis: Long = System.currentTimeMillis(),
    val attachmentsBinaryIncluded: Boolean = false,
    val profile: BackupProfileDto = BackupProfileDto(),
    val courses: List<BackupCourseDto> = emptyList(),
    val sessions: List<BackupSessionDto> = emptyList(),
    val assignments: List<BackupAssignmentDto> = emptyList(),
    val exams: List<BackupExamDto> = emptyList(),
    val studySessions: List<BackupStudySessionDto> = emptyList(),
    val goals: List<BackupGoalDto> = emptyList(),
    val decks: List<BackupDeckDto> = emptyList(),
    val flashcards: List<BackupFlashcardDto> = emptyList(),
    val notes: List<BackupNoteDto> = emptyList(),
    val attachments: List<BackupAttachmentDto> = emptyList()
) {
    companion object {
        const val CURRENT_SCHEMA_VERSION = 1
    }
}

sealed class BackupValidationResult {
    data class Valid(val payload: DaneshinoBackupPayload) : BackupValidationResult()
    data class Invalid(val errorMessage: String) : BackupValidationResult()
}

class BackupManager(
    private val repository: DaneshinoRepository,
    private val preferencesRepository: UserPreferencesRepository
) {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val adapter = moshi.adapter(DaneshinoBackupPayload::class.java).indent("  ")

    suspend fun exportToJson(): String {
        val prefs = preferencesRepository.getPreferencesOnce()
        val payload = DaneshinoBackupPayload(
            appName = "Daneshino",
            schemaVersion = DaneshinoBackupPayload.CURRENT_SCHEMA_VERSION,
            exportedAtMillis = System.currentTimeMillis(),
            attachmentsBinaryIncluded = false,
            profile = BackupProfileDto(
                studentName = prefs.studentName,
                university = prefs.university,
                major = prefs.major,
                degreeLevel = prefs.degreeLevel,
                currentTerm = prefs.currentTerm,
                totalDegreeCredits = prefs.totalDegreeCredits,
                themeMode = prefs.themeMode.storageKey,
                classRemindersEnabled = prefs.classRemindersEnabled,
                classReminderMinutesBefore = prefs.classReminderMinutesBefore,
                classReminderMethod = prefs.classReminderMethod.storageKey,
                assignmentRemindersEnabled = prefs.assignmentRemindersEnabled,
                examRemindersEnabled = prefs.examRemindersEnabled
            ),
            courses = repository.getAllCoursesOnce().map {
                BackupCourseDto(
                    id = it.id,
                    name = it.name,
                    code = it.code,
                    credits = it.credits,
                    instructorName = it.instructorName,
                    instructorEmail = it.instructorEmail,
                    instructorPhone = it.instructorPhone,
                    instructorOffice = it.instructorOffice,
                    instructorNotes = it.instructorNotes,
                    term = it.term,
                    courseType = it.courseType,
                    colorArgb = it.colorArgb,
                    description = it.description,
                    isFavorite = it.isFavorite,
                    grade = it.grade,
                    createdAtMillis = it.createdAtMillis
                )
            },
            sessions = repository.getAllSessionsOnce().map {
                BackupSessionDto(
                    id = it.id,
                    courseId = it.courseId,
                    dayOfWeek = it.dayOfWeek,
                    startMinuteOfDay = it.startMinuteOfDay,
                    endMinuteOfDay = it.endMinuteOfDay,
                    roomNumber = it.roomNumber,
                    building = it.building,
                    notes = it.notes,
                    repeatWeekly = it.repeatWeekly
                )
            },
            assignments = repository.getAllAssignmentsOnce().map {
                BackupAssignmentDto(
                    id = it.id,
                    courseId = it.courseId,
                    title = it.title,
                    description = it.description,
                    dueAtMillis = it.dueAtMillis,
                    priority = it.priority,
                    status = it.status,
                    reminderMinutesBefore = it.reminderMinutesBefore,
                    createdAtMillis = it.createdAtMillis
                )
            },
            exams = repository.getAllExamsOnce().map {
                BackupExamDto(
                    id = it.id,
                    courseId = it.courseId,
                    title = it.title,
                    examAtMillis = it.examAtMillis,
                    location = it.location,
                    syllabus = it.syllabus,
                    notes = it.notes,
                    reminderMinutesBefore = it.reminderMinutesBefore,
                    createdAtMillis = it.createdAtMillis
                )
            },
            studySessions = repository.getAllStudySessionsOnce().map {
                BackupStudySessionDto(
                    id = it.id,
                    courseId = it.courseId,
                    courseNameSnapshot = it.courseNameSnapshot,
                    startAtMillis = it.startAtMillis,
                    endAtMillis = it.endAtMillis,
                    durationSeconds = it.durationSeconds,
                    dateKey = it.dateKey
                )
            },
            goals = repository.getAllGoalsOnce().map {
                BackupGoalDto(
                    id = it.id,
                    title = it.title,
                    period = it.period,
                    targetMinutes = it.targetMinutes,
                    courseId = it.courseId,
                    createdAtMillis = it.createdAtMillis
                )
            },
            decks = repository.getAllDecksOnce().map {
                BackupDeckDto(
                    id = it.id,
                    title = it.title,
                    courseId = it.courseId,
                    description = it.description,
                    createdAtMillis = it.createdAtMillis
                )
            },
            flashcards = repository.getAllFlashcardsOnce().map {
                BackupFlashcardDto(
                    id = it.id,
                    deckId = it.deckId,
                    front = it.front,
                    back = it.back,
                    knownCount = it.knownCount,
                    reviewCount = it.reviewCount,
                    lastReviewedAtMillis = it.lastReviewedAtMillis
                )
            },
            notes = repository.getAllNotesOnce().map {
                BackupNoteDto(
                    id = it.id,
                    courseId = it.courseId,
                    title = it.title,
                    content = it.content,
                    category = it.category,
                    updatedAtMillis = it.updatedAtMillis
                )
            },
            attachments = repository.getAllAttachmentsOnce().map {
                BackupAttachmentDto(
                    id = it.id,
                    courseId = it.courseId,
                    displayName = it.displayName,
                    uriString = it.uriString,
                    mimeType = it.mimeType,
                    attachmentType = it.attachmentType,
                    addedAtMillis = it.addedAtMillis
                )
            }
        )
        return adapter.toJson(payload)
    }

    fun validateJson(rawJson: String): BackupValidationResult {
        if (rawJson.isBlank()) {
            return BackupValidationResult.Invalid("فایل انتخاب‌شده خالی است.")
        }
        return try {
            val payload = adapter.fromJson(rawJson)
                ?: return BackupValidationResult.Invalid("ساختار فایل پشتیبان نامعتبر است.")

            if (payload.appName != "Daneshino") {
                return BackupValidationResult.Invalid("این فایل متعلق به اپلیکیشن دانشینو نیست.")
            }
            if (payload.schemaVersion !in 1..DaneshinoBackupPayload.CURRENT_SCHEMA_VERSION) {
                return BackupValidationResult.Invalid("نسخه فایل پشتیبان با این نسخه از دانشینو سازگار نیست.")
            }

            // Validate referential integrity so Room foreign keys never fail during restore
            val courseIds = payload.courses.map { it.id }.toSet()
            val invalidSession = payload.sessions.any { it.courseId !in courseIds || it.dayOfWeek !in 0..6 }
            if (invalidSession) {
                return BackupValidationResult.Invalid("اطلاعات جلسات کلاس در فایل پشتیبان دچار ناسازگاری است.")
            }
            val deckIds = payload.decks.map { it.id }.toSet()
            if (payload.flashcards.any { it.deckId !in deckIds }) {
                return BackupValidationResult.Invalid("اطلاعات فلش‌کارت‌ها در فایل پشتیبان دچار ناسازگاری است.")
            }

            BackupValidationResult.Valid(payload)
        } catch (e: Exception) {
            BackupValidationResult.Invalid("خطا در خواندن فایل JSON: ساختار فایل معتبر نیست.")
        }
    }

    suspend fun restoreFromValidatedPayload(payload: DaneshinoBackupPayload) {
        val courseIds = payload.courses.map { it.id }.toSet()
        val restoredPrefs = UserPreferences(
            onboardingCompleted = true,
            studentName = payload.profile.studentName,
            university = payload.profile.university,
            major = payload.profile.major,
            degreeLevel = payload.profile.degreeLevel,
            currentTerm = payload.profile.currentTerm,
            totalDegreeCredits = payload.profile.totalDegreeCredits.coerceIn(1.0, 400.0),
            themeMode = AppThemeMode.fromKey(payload.profile.themeMode),
            classRemindersEnabled = payload.profile.classRemindersEnabled,
            classReminderMinutesBefore = ReminderLeadTime.sanitize(payload.profile.classReminderMinutesBefore),
            classReminderMethod = ReminderMethod.fromKey(payload.profile.classReminderMethod),
            assignmentRemindersEnabled = payload.profile.assignmentRemindersEnabled,
            examRemindersEnabled = payload.profile.examRemindersEnabled
        )

        preferencesRepository.restorePreferences(restoredPrefs)

        repository.replaceAllData(
            courses = payload.courses.map {
                CourseEntity(
                    id = it.id,
                    name = it.name,
                    code = it.code,
                    credits = it.credits,
                    instructorName = it.instructorName,
                    instructorEmail = it.instructorEmail,
                    instructorPhone = it.instructorPhone,
                    instructorOffice = it.instructorOffice,
                    instructorNotes = it.instructorNotes,
                    term = it.term,
                    courseType = it.courseType,
                    colorArgb = it.colorArgb,
                    description = it.description,
                    isFavorite = it.isFavorite,
                    grade = it.grade,
                    createdAtMillis = it.createdAtMillis
                )
            },
            sessions = payload.sessions.map {
                ClassSessionEntity(
                    id = it.id,
                    courseId = it.courseId,
                    dayOfWeek = it.dayOfWeek,
                    startMinuteOfDay = it.startMinuteOfDay,
                    endMinuteOfDay = it.endMinuteOfDay,
                    roomNumber = it.roomNumber,
                    building = it.building,
                    notes = it.notes,
                    repeatWeekly = it.repeatWeekly
                )
            },
            assignments = payload.assignments.map {
                AssignmentEntity(
                    id = it.id,
                    courseId = it.courseId?.takeIf { cid -> cid in courseIds },
                    title = it.title,
                    description = it.description,
                    dueAtMillis = it.dueAtMillis,
                    priority = it.priority,
                    status = it.status,
                    reminderMinutesBefore = it.reminderMinutesBefore,
                    createdAtMillis = it.createdAtMillis
                )
            },
            exams = payload.exams.map {
                ExamEntity(
                    id = it.id,
                    courseId = it.courseId?.takeIf { cid -> cid in courseIds },
                    title = it.title,
                    examAtMillis = it.examAtMillis,
                    location = it.location,
                    syllabus = it.syllabus,
                    notes = it.notes,
                    reminderMinutesBefore = it.reminderMinutesBefore,
                    createdAtMillis = it.createdAtMillis
                )
            },
            studySessions = payload.studySessions.map {
                StudySessionEntity(
                    id = it.id,
                    courseId = it.courseId?.takeIf { cid -> cid in courseIds },
                    courseNameSnapshot = it.courseNameSnapshot,
                    startAtMillis = it.startAtMillis,
                    endAtMillis = it.endAtMillis,
                    durationSeconds = it.durationSeconds,
                    dateKey = it.dateKey
                )
            },
            goals = payload.goals.map {
                GoalEntity(
                    id = it.id,
                    title = it.title,
                    period = it.period,
                    targetMinutes = it.targetMinutes,
                    courseId = it.courseId?.takeIf { cid -> cid in courseIds },
                    createdAtMillis = it.createdAtMillis
                )
            },
            decks = payload.decks.map {
                FlashcardDeckEntity(
                    id = it.id,
                    title = it.title,
                    courseId = it.courseId?.takeIf { cid -> cid in courseIds },
                    description = it.description,
                    createdAtMillis = it.createdAtMillis
                )
            },
            flashcards = payload.flashcards.map {
                FlashcardEntity(
                    id = it.id,
                    deckId = it.deckId,
                    front = it.front,
                    back = it.back,
                    knownCount = it.knownCount,
                    reviewCount = it.reviewCount,
                    lastReviewedAtMillis = it.lastReviewedAtMillis
                )
            },
            notes = payload.notes.map {
                NoteEntity(
                    id = it.id,
                    courseId = it.courseId?.takeIf { cid -> cid in courseIds },
                    title = it.title,
                    content = it.content,
                    category = it.category,
                    updatedAtMillis = it.updatedAtMillis
                )
            },
            attachments = payload.attachments
                .filter { it.courseId in courseIds }
                .map {
                    CourseAttachmentEntity(
                        id = it.id,
                        courseId = it.courseId,
                        displayName = it.displayName,
                        uriString = it.uriString,
                        mimeType = it.mimeType,
                        attachmentType = it.attachmentType,
                        addedAtMillis = it.addedAtMillis
                    )
                },
            prefs = restoredPrefs
        )
    }
}
