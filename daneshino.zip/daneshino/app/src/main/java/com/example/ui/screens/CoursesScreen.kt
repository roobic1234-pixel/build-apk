package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CalendarViewWeek
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Room
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.PersianDateUtil
import com.example.data.local.ClassSessionEntity
import com.example.data.local.CourseEntity
import com.example.data.local.CourseWithSessions
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.DaneshinoCard
import com.example.ui.components.DaneshinoEmptyState
import com.example.ui.components.PillBadge
import com.example.ui.components.ScreenHeader
import com.example.ui.theme.CourseColorPalette
import com.example.ui.viewmodel.DaneshinoDataState

private enum class CourseSortOption(val label: String) {
    RECENT("جدیدترین"),
    NAME("نام درس"),
    CREDITS("واحد"),
    GRADE("نمره")
}

@Composable
fun CoursesScreen(
    state: DaneshinoDataState,
    onSaveCourse: (CourseEntity, List<ClassSessionEntity>) -> Unit,
    onDeleteCourse: (Long) -> Unit,
    onToggleFavorite: (CourseEntity) -> Unit,
    onOpenAttachments: (Long) -> Unit,
    onOpenCourseDetail: (Long) -> Unit,
    showAddDialogExternal: Boolean,
    onDismissAddDialogExternal: () -> Unit
) {
    // 0 = Weekly Schedule ("برنامه هفتگی کلاس‌ها"), 1 = Course List ("لیست درس‌ها")
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var onlyFavorites by rememberSaveable { mutableStateOf(false) }
    var sortOption by rememberSaveable { mutableStateOf(CourseSortOption.RECENT) }

    var editingCourse by remember { mutableStateOf<CourseWithSessions?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var pendingDeleteCourse by remember { mutableStateOf<CourseEntity?>(null) }

    val openCreate = { showCreateDialog = true }

    if (showCreateDialog || showAddDialogExternal) {
        CourseEditorDialog(
            existing = null,
            defaultTerm = state.preferences.currentTerm,
            onSave = { course, sessions ->
                onSaveCourse(course, sessions)
                showCreateDialog = false
                onDismissAddDialogExternal()
            },
            onDismiss = {
                showCreateDialog = false
                onDismissAddDialogExternal()
            }
        )
    }

    editingCourse?.let { target ->
        CourseEditorDialog(
            existing = target,
            defaultTerm = state.preferences.currentTerm,
            onSave = { course, sessions ->
                onSaveCourse(course, sessions)
                editingCourse = null
            },
            onDismiss = { editingCourse = null }
        )
    }

    pendingDeleteCourse?.let { target ->
        ConfirmDeleteDialog(
            title = stringResource(R.string.course_delete_confirm_title),
            body = stringResource(R.string.course_delete_confirm_body, target.name),
            onConfirm = {
                onDeleteCourse(target.id)
                pendingDeleteCourse = null
            },
            onDismiss = { pendingDeleteCourse = null }
        )
    }

    val filteredCourses = remember(state.coursesWithSessions, searchQuery, onlyFavorites, sortOption) {
        val q = searchQuery.trim().lowercase()
        val filtered = state.coursesWithSessions.filter { cws ->
            val matchesFav = !onlyFavorites || cws.course.isFavorite
            val matchesQuery = q.isEmpty() ||
                cws.course.name.lowercase().contains(q) ||
                cws.course.code.lowercase().contains(q) ||
                cws.course.instructorName.lowercase().contains(q) ||
                cws.course.term.lowercase().contains(q)
            matchesFav && matchesQuery
        }
        when (sortOption) {
            CourseSortOption.RECENT -> filtered.sortedWith(
                compareByDescending<CourseWithSessions> { it.course.isFavorite }
                    .thenByDescending { it.course.createdAtMillis }
            )
            CourseSortOption.NAME -> filtered.sortedBy { it.course.name }
            CourseSortOption.CREDITS -> filtered.sortedByDescending { it.course.credits }
            CourseSortOption.GRADE -> filtered.sortedByDescending { it.course.grade ?: -1.0 }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = stringResource(R.string.nav_courses),
            subtitle = if (state.courses.isEmpty()) null else "${PersianDateUtil.formatInt(state.courses.size)} درس ثبت‌شده"
        )

        // Prominent 2-Tab Segmented Selector with unmistakable active highlight
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surfaceContainerHigh
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CoursesTabButton(
                    label = stringResource(R.string.courses_tab_schedule),
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    testTag = "courses_tab_schedule",
                    modifier = Modifier.weight(1f)
                )
                CoursesTabButton(
                    label = stringResource(R.string.courses_tab_list),
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    testTag = "courses_tab_list",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        if (selectedTab == 0) {
            WeeklyScheduleTab(
                coursesWithSessions = state.coursesWithSessions,
                onOpenCourse = onOpenCourseDetail,
                onAddFirstCourse = openCreate
            )
        } else {
            CoursesListTab(
                allCount = state.coursesWithSessions.size,
                filteredCourses = filteredCourses,
                searchQuery = searchQuery,
                onSearchChange = { searchQuery = it },
                onlyFavorites = onlyFavorites,
                onToggleOnlyFavorites = { onlyFavorites = !onlyFavorites },
                sortOption = sortOption,
                onSelectSort = { sortOption = it },
                onAddFirstCourse = openCreate,
                onOpenDetail = onOpenCourseDetail,
                onEdit = { editingCourse = it },
                onDelete = { pendingDeleteCourse = it },
                onToggleFavorite = onToggleFavorite,
                onOpenAttachments = onOpenAttachments
            )
        }
    }
}

@Composable
private fun CoursesTabButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .height(48.dp)
            .clip(MaterialTheme.shapes.small)
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = MaterialTheme.shapes.small,
        color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 8.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun WeeklyScheduleTab(
    coursesWithSessions: List<CourseWithSessions>,
    onOpenCourse: (Long) -> Unit,
    onAddFirstCourse: () -> Unit
) {
    val sessionsByDay = remember(coursesWithSessions) {
        (0..6).associateWith { day ->
            coursesWithSessions.flatMap { cws ->
                cws.sessions
                    .filter { it.dayOfWeek == day }
                    .map { cws.course to it }
            }.sortedBy { it.second.startMinuteOfDay }
        }
    }
    val hasAnySession = sessionsByDay.values.any { it.isNotEmpty() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 92.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (!hasAnySession) {
            item {
                DaneshinoEmptyState(
                    icon = Icons.Default.CalendarViewWeek,
                    title = stringResource(R.string.schedule_empty_title),
                    subtitle = stringResource(R.string.schedule_empty_subtitle),
                    actionLabel = stringResource(R.string.courses_add_first),
                    onAction = onAddFirstCourse,
                    actionTestTag = "schedule_add_first_course"
                )
            }
        } else {
            val activeDays = (0..6).filter { sessionsByDay[it].orEmpty().isNotEmpty() }
            items(activeDays, key = { it }) { dayIndex ->
                val daySessions = sessionsByDay[dayIndex].orEmpty()
                DaneshinoCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = PersianDateUtil.weekDayNames[dayIndex],
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        PillBadge(
                            text = "${PersianDateUtil.formatInt(daySessions.size)} جلسه",
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        daySessions.forEach { (course, session) ->
                            val courseColor = CourseColorPalette.safeColor(course.colorArgb)
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(MaterialTheme.shapes.small)
                                    .clickable { onOpenCourse(course.id) },
                                shape = MaterialTheme.shapes.small,
                                color = courseColor.copy(alpha = 0.12f)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(5.dp)
                                            .height(44.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(courseColor)
                                    )
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = course.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            text = PersianDateUtil.formatTimeRange(
                                                session.startMinuteOfDay,
                                                session.endMinuteOfDay
                                            ),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        val loc = listOf(session.building, session.roomNumber)
                                            .filter { it.isNotBlank() }
                                            .joinToString(" • ")
                                        if (loc.isNotBlank() || course.instructorName.isNotBlank()) {
                                            Text(
                                                text = listOf(course.instructorName, loc)
                                                    .filter { it.isNotBlank() }
                                                    .joinToString(" • "),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CoursesListTab(
    allCount: Int,
    filteredCourses: List<CourseWithSessions>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onlyFavorites: Boolean,
    onToggleOnlyFavorites: () -> Unit,
    sortOption: CourseSortOption,
    onSelectSort: (CourseSortOption) -> Unit,
    onAddFirstCourse: () -> Unit,
    onOpenDetail: (Long) -> Unit,
    onEdit: (CourseWithSessions) -> Unit,
    onDelete: (CourseEntity) -> Unit,
    onToggleFavorite: (CourseEntity) -> Unit,
    onOpenAttachments: (Long) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 92.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (allCount == 0) {
            item {
                DaneshinoEmptyState(
                    icon = Icons.Default.MenuBook,
                    title = stringResource(R.string.courses_empty_title),
                    subtitle = stringResource(R.string.courses_empty_subtitle),
                    actionLabel = stringResource(R.string.courses_add_first),
                    onAction = onAddFirstCourse,
                    actionTestTag = "courses_add_first_button"
                )
            }
        } else {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchChange,
                        placeholder = { Text("جستجو در نام درس، کد یا استاد...") },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = "جستجو")
                        },
                        singleLine = true,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("courses_search_input")
                    )

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = onlyFavorites,
                                onClick = onToggleOnlyFavorites,
                                label = { Text("علاقه‌مندی‌ها") }
                            )
                        }
                        items(CourseSortOption.entries) { option ->
                            FilterChip(
                                selected = sortOption == option,
                                onClick = { onSelectSort(option) },
                                label = { Text("مرتب: ${option.label}") }
                            )
                        }
                    }
                }
            }

            if (filteredCourses.isEmpty()) {
                item {
                    DaneshinoCard {
                        Text(
                            text = "درسی با این فیلتر پیدا نشد.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(filteredCourses, key = { it.course.id }) { cws ->
                    CourseItemCard(
                        courseWithSessions = cws,
                        onClick = { onOpenDetail(cws.course.id) },
                        onEdit = { onEdit(cws) },
                        onDelete = { onDelete(cws.course) },
                        onToggleFavorite = { onToggleFavorite(cws.course) },
                        onOpenAttachments = { onOpenAttachments(cws.course.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CourseItemCard(
    courseWithSessions: CourseWithSessions,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleFavorite: () -> Unit,
    onOpenAttachments: () -> Unit
) {
    val course = courseWithSessions.course
    val courseColor = CourseColorPalette.safeColor(course.colorArgb)

    DaneshinoCard(onClick = onClick) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Exact real course color indicator (never black!)
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(courseColor)
            )
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = course.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (course.code.isNotBlank() || course.term.isNotBlank()) {
                    Text(
                        text = listOf(course.code, course.courseType, course.term)
                            .filter { it.isNotBlank() }
                            .joinToString(" • "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            PillBadge(
                text = "${PersianDateUtil.formatCredits(course.credits)} واحد",
                containerColor = courseColor.copy(alpha = 0.16f),
                contentColor = courseColor
            )
        }

        Spacer(Modifier.height(10.dp))

        if (course.instructorName.isNotBlank()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = "استاد: ${course.instructorName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(4.dp))
        }

        courseWithSessions.sessions.forEach { session ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Schedule,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(6.dp))
                val day = PersianDateUtil.weekDayNames.getOrElse(session.dayOfWeek) { "" }
                val loc = listOf(session.building, session.roomNumber).filter { it.isNotBlank() }.joinToString(" - ")
                Text(
                    text = "$day ${PersianDateUtil.formatTimeRange(session.startMinuteOfDay, session.endMinuteOfDay)}" +
                        if (loc.isNotBlank()) " • $loc" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(4.dp))
        }

        if (course.grade != null) {
            Spacer(Modifier.height(4.dp))
            PillBadge(
                text = "نمره: ${PersianDateUtil.formatDecimal(course.grade, 2)} از ۲۰",
                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
            )
        }

        Spacer(Modifier.height(8.dp))

        // Accessible 48dp action buttons with Persian contentDescriptions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("course_favorite_${course.id}")
            ) {
                Icon(
                    imageVector = if (course.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                    contentDescription = stringResource(R.string.cd_favorite_course),
                    tint = if (course.isFavorite) Color(0xFFF59E0B) else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(
                onClick = onOpenAttachments,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("course_attach_${course.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.AttachFile,
                    contentDescription = stringResource(R.string.cd_attach_course),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(
                onClick = onEdit,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("course_edit_${course.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = stringResource(R.string.cd_edit_course),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("course_delete_${course.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = stringResource(R.string.cd_delete_course),
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
