# Daneshino ProGuard / R8 Rules

# Keep Room entities and database classes
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# Keep Moshi generated adapters and backup DTO models
-keep class com.example.data.backup.** { *; }
-keep class * implements com.squareup.moshi.JsonAdapter {
    public <init>(com.squareup.moshi.Moshi);
}

# Keep BroadcastReceivers and Services declared in AndroidManifest
-keep class com.example.reminder.** { *; }

# Keep line numbers for crash diagnostics
-keepattributes SourceFile,LineNumberTable
