package com.example.data.repository

import com.example.data.local.AssignmentEntity
import com.example.data.local.ClassSessionEntity
import com.example.data.local.CourseAttachmentEntity
import com.example.data.local.CourseEntity
import com.example.data.local.CourseWithSessions
import com.example.data.local.DaneshinoDao
import com.example.data.local.ExamEntity
import com.example.data.local.FlashcardDeckEntity
import com.example.data.local.FlashcardEntity
import com.example.data.local.GoalEntity
import com.example.data.local.NoteEntity
import com.example.data.local.SessionWithCourse
import com.example.data.local.StudySessionEntity
import com.example.data.prefs.UserPreferences
import com.example.reminder.ReminderController
import kotlinx.coroutines.flow.Flow

/**
 * Single source of truth repository coordinating Room persistence and reminder scheduling/cancellation.
 * Guarantees that deleting or modifying any course, session, assignment, or exam immediately
 * cancels stale alarms, PendingIntents, active notifications, and audio playback for those IDs only.
 */
class DaneshinoRepository(
    private val dao: DaneshinoDao,
    private val reminderController: ReminderController
) {
    val coursesWithSessions: Flow<List<CourseWithSessions>> = dao.observeCoursesWithSessions()
    val allCourses: Flow<List<CourseEntity>> = dao.observeAllCourses()
    val allSessions: Flow<List<ClassSessionEntity>> = dao.observeAllSessions()
    val allAssignments: Flow<List<AssignmentEntity>> = dao.observeAllAssignments()
    val allExams: Flow<List<ExamEntity>> = dao.observeAllExams()
    val allStudySessions: Flow<List<StudySessionEntity>> = dao.observeAllStudySessions()
    val allGoals: Flow<List<GoalEntity>> = dao.observeAllGoals()
    val allDecks: Flow<List<FlashcardDeckEntity>> = dao.observeAllDecks()
    val allFlashcards: Flow<List<FlashcardEntity>> = dao.observeAllFlashcards()
    val allNotes: Flow<List<NoteEntity>> = dao.observeAllNotes()
    val allAttachments: Flow<List<CourseAttachmentEntity>> = dao.observeAllAttachments()

    fun observeCourse(courseId: Long): Flow<CourseWithSessions?> = dao.observeCourseWithSessions(courseId)
    fun observeAttachmentsForCourse(courseId: Long): Flow<List<CourseAttachmentEntity>> =
        dao.observeAttachmentsForCourse(courseId)
    fun observeFlashcardsForDeck(deckId: Long): Flow<List<FlashcardEntity>> =
        dao.observeFlashcardsForDeck(deckId)

    // --- Courses & Sessions ---
    suspend fun saveCourseWithSessions(
        course: CourseEntity,
        sessions: List<ClassSessionEntity>,
        prefs: UserPreferences
    ): Long {
        val isEdit = course.id > 0L
        val oldSessionIds = if (isEdit) {
            dao.getSessionsForCourseOnce(course.id).map { it.id }
        } else emptyList()

        // Cancel old session reminders before replacing sessions to avoid ghost reminders on time/day edit
        oldSessionIds.forEach { reminderController.cancelClassSessionReminder(it) }

        val courseId = if (isEdit) {
            dao.updateCourse(course)
            dao.deleteSessionsForCourse(course.id)
            course.id
        } else {
            dao.insertCourse(course)
        }

        val savedCourse = course.copy(id = courseId)
        sessions.forEach { session ->
            val newId = dao.insertSession(session.copy(id = 0L, courseId = courseId))
            if (prefs.classRemindersEnabled) {
                reminderController.scheduleClassSessionReminder(
                    session = session.copy(id = newId, courseId = courseId),
                    course = savedCourse,
                    prefs = prefs
                )
            }
        }
        return courseId
    }

    suspend fun toggleCourseFavorite(course: CourseEntity) {
        dao.updateCourse(course.copy(isFavorite = !course.isFavorite))
    }

    suspend fun updateCourseGrade(courseId: Long, grade: Double?) {
        val existing = dao.getCourseById(courseId) ?: return
        dao.updateCourse(existing.copy(grade = grade))
    }

    /**
     * Deletes a course and cancels ONLY the reminders (AlarmManager, PendingIntent, active notifications,
     * and active audio alarm) associated with this course's sessions, assignments, and exams.
     * Other courses' reminders remain untouched.
     */
    suspend fun deleteCourse(courseId: Long) {
        val sessions = dao.getSessionsForCourseOnce(courseId)
        val assignments = dao.getAssignmentsForCourseOnce(courseId)
        val exams = dao.getExamsForCourseOnce(courseId)

        sessions.forEach { reminderController.cancelClassSessionReminder(it.id) }
        assignments.forEach { reminderController.cancelAssignmentReminder(it.id) }
        exams.forEach { reminderController.cancelExamReminder(it.id) }

        dao.deleteCourseById(courseId)
    }

    suspend fun getSessionWithCourse(sessionId: Long): SessionWithCourse? =
        dao.getSessionWithCourse(sessionId)

    // --- Assignments ---
    suspend fun saveAssignment(assignment: AssignmentEntity, prefs: UserPreferences): Long {
        if (assignment.id > 0L) {
            reminderController.cancelAssignmentReminder(assignment.id)
        }
        val savedId = if (assignment.id > 0L) {
            dao.updateAssignment(assignment)
            assignment.id
        } else {
            dao.insertAssignment(assignment)
        }
        val saved = assignment.copy(id = savedId)
        val courseName = saved.courseId?.let { dao.getCourseById(it)?.name } ?: ""
        if (prefs.assignmentRemindersEnabled && saved.reminderMinutesBefore != null) {
            reminderController.scheduleAssignmentReminder(saved, courseName)
        } else {
            reminderController.cancelAssignmentReminder(savedId)
        }
        return savedId
    }

    suspend fun deleteAssignment(assignmentId: Long) {
        reminderController.cancelAssignmentReminder(assignmentId)
        dao.deleteAssignmentById(assignmentId)
    }

    suspend fun getAssignmentById(id: Long): AssignmentEntity? = dao.getAssignmentById(id)

    // --- Exams ---
    suspend fun saveExam(exam: ExamEntity, prefs: UserPreferences): Long {
        if (exam.id > 0L) {
            reminderController.cancelExamReminder(exam.id)
        }
        val savedId = if (exam.id > 0L) {
            dao.updateExam(exam)
            exam.id
        } else {
            dao.insertExam(exam)
        }
        val saved = exam.copy(id = savedId)
        val courseName = saved.courseId?.let { dao.getCourseById(it)?.name } ?: ""
        if (prefs.examRemindersEnabled && saved.reminderMinutesBefore != null) {
            reminderController.scheduleExamReminder(saved, courseName)
        } else {
            reminderController.cancelExamReminder(savedId)
        }
        return savedId
    }

    suspend fun deleteExam(examId: Long) {
        reminderController.cancelExamReminder(examId)
        dao.deleteExamById(examId)
    }

    suspend fun getExamById(id: Long): ExamEntity? = dao.getExamById(id)

    // --- Study Sessions ---
    suspend fun insertStudySession(session: StudySessionEntity): Long =
        dao.insertStudySession(session)

    suspend fun deleteStudySession(id: Long) = dao.deleteStudySessionById(id)

    // --- Goals ---
    suspend fun saveGoal(goal: GoalEntity): Long =
        if (goal.id > 0L) {
            dao.updateGoal(goal)
            goal.id
        } else {
            dao.insertGoal(goal)
        }

    suspend fun deleteGoal(id: Long) = dao.deleteGoalById(id)

    // --- Flashcards ---
    suspend fun saveDeck(deck: FlashcardDeckEntity): Long =
        if (deck.id > 0L) {
            dao.updateDeck(deck)
            deck.id
        } else {
            dao.insertDeck(deck)
        }

    suspend fun deleteDeck(id: Long) = dao.deleteDeckById(id)

    suspend fun saveFlashcard(card: FlashcardEntity): Long =
        if (card.id > 0L) {
            dao.updateFlashcard(card)
            card.id
        } else {
            dao.insertFlashcard(card)
        }

    suspend fun deleteFlashcard(id: Long) = dao.deleteFlashcardById(id)

    // --- Notes ---
    suspend fun saveNote(note: NoteEntity): Long =
        if (note.id > 0L) {
            dao.updateNote(note)
            note.id
        } else {
            dao.insertNote(note)
        }

    suspend fun deleteNote(id: Long) = dao.deleteNoteById(id)

    // --- Attachments ---
    suspend fun addAttachment(attachment: CourseAttachmentEntity): Long =
        dao.insertAttachment(attachment)

    suspend fun deleteAttachment(id: Long) = dao.deleteAttachmentById(id)

    // --- Bulk Reminder Sync (After Settings Change, Reboot, or Backup Restore) ---
    suspend fun rescheduleAllReminders(prefs: UserPreferences) {
        val courses = dao.getAllCoursesOnce().associateBy { it.id }
        val sessions = dao.getAllSessionsOnce()
        val assignments = dao.getAllAssignmentsOnce()
        val exams = dao.getAllExamsOnce()

        sessions.forEach { session ->
            val course = courses[session.courseId]
            if (prefs.classRemindersEnabled && course != null) {
                reminderController.scheduleClassSessionReminder(session, course, prefs)
            } else {
                reminderController.cancelClassSessionReminder(session.id)
            }
        }

        assignments.forEach { assignment ->
            val courseName = assignment.courseId?.let { courses[it]?.name } ?: ""
            if (prefs.assignmentRemindersEnabled && assignment.reminderMinutesBefore != null) {
                reminderController.scheduleAssignmentReminder(assignment, courseName)
            } else {
                reminderController.cancelAssignmentReminder(assignment.id)
            }
        }

        exams.forEach { exam ->
            val courseName = exam.courseId?.let { courses[it]?.name } ?: ""
            if (prefs.examRemindersEnabled && exam.reminderMinutesBefore != null) {
                reminderController.scheduleExamReminder(exam, courseName)
            } else {
                reminderController.cancelExamReminder(exam.id)
            }
        }
    }

    suspend fun cancelAllExistingReminders() {
        dao.getAllSessionsOnce().forEach { reminderController.cancelClassSessionReminder(it.id) }
        dao.getAllAssignmentsOnce().forEach { reminderController.cancelAssignmentReminder(it.id) }
        dao.getAllExamsOnce().forEach { reminderController.cancelExamReminder(it.id) }
        reminderController.stopAlarmAudio()
    }

    // --- Snapshot Queries for Backup ---
    suspend fun getAllCoursesOnce() = dao.getAllCoursesOnce()
    suspend fun getAllSessionsOnce() = dao.getAllSessionsOnce()
    suspend fun getAllAssignmentsOnce() = dao.getAllAssignmentsOnce()
    suspend fun getAllExamsOnce() = dao.getAllExamsOnce()
    suspend fun getAllStudySessionsOnce() = dao.getAllStudySessionsOnce()
    suspend fun getAllGoalsOnce() = dao.getAllGoalsOnce()
    suspend fun getAllDecksOnce() = dao.getAllDecksOnce()
    suspend fun getAllFlashcardsOnce() = dao.getAllFlashcardsOnce()
    suspend fun getAllNotesOnce() = dao.getAllNotesOnce()
    suspend fun getAllAttachmentsOnce() = dao.getAllAttachmentsOnce()

    suspend fun replaceAllData(
        courses: List<CourseEntity>,
        sessions: List<ClassSessionEntity>,
        assignments: List<AssignmentEntity>,
        exams: List<ExamEntity>,
        studySessions: List<StudySessionEntity>,
        goals: List<GoalEntity>,
        decks: List<FlashcardDeckEntity>,
        flashcards: List<FlashcardEntity>,
        notes: List<NoteEntity>,
        attachments: List<CourseAttachmentEntity>,
        prefs: UserPreferences
    ) {
        cancelAllExistingReminders()
        dao.replaceAllData(
            courses = courses,
            sessions = sessions,
            assignments = assignments,
            exams = exams,
            studySessions = studySessions,
            goals = goals,
            decks = decks,
            flashcards = flashcards,
            notes = notes,
            attachments = attachments
        )
        rescheduleAllReminders(prefs)
    }
}
