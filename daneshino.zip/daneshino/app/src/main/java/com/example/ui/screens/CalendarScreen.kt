package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.PersianDateUtil
import com.example.data.local.AssignmentStatus
import com.example.data.local.GoalPeriod
import com.example.ui.components.DaneshinoCard
import com.example.ui.components.PillBadge
import com.example.ui.components.ScreenHeader
import com.example.ui.theme.CourseColorPalette
import com.example.ui.theme.DaneshinoAmber
import com.example.ui.theme.DaneshinoBlue
import com.example.ui.theme.DaneshinoCoral
import com.example.ui.theme.DaneshinoPurple
import com.example.ui.theme.DaneshinoTeal
import com.example.ui.viewmodel.DaneshinoDataState

private enum class CalendarViewMode(val label: String) {
    DAY("روزانه"),
    WEEK("هفتگی"),
    MONTH("ماهانه")
}

@Composable
fun CalendarScreen(
    state: DaneshinoDataState,
    nowMillis: Long
) {
    var viewModeIndex by rememberSaveable { mutableIntStateOf(2) } // Default: Monthly
    val viewMode = CalendarViewMode.entries[viewModeIndex]

    val todayStart = remember(nowMillis / 60_000L) { PersianDateUtil.startOfDayMillis(nowMillis) }
    var selectedDayMillis by rememberSaveable { mutableLongStateOf(todayStart) }

    val selectedShamsi = remember(selectedDayMillis) { PersianDateUtil.toShamsi(selectedDayMillis) }
    var displayYear by rememberSaveable { mutableIntStateOf(selectedShamsi.year) }
    var displayMonth by rememberSaveable { mutableIntStateOf(selectedShamsi.month) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = stringResource(R.string.nav_calendar),
            subtitle = PersianDateUtil.formatFullShamsiDate(selectedDayMillis),
            actions = {
                TextButton(
                    onClick = {
                        selectedDayMillis = todayStart
                        val todayShamsi = PersianDateUtil.toShamsi(todayStart)
                        displayYear = todayShamsi.year
                        displayMonth = todayShamsi.month
                    },
                    modifier = Modifier.testTag("calendar_today_button")
                ) {
                    Text("امروز")
                }
            }
        )

        // View mode switcher: Daily / Weekly / Monthly
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surfaceContainerHigh
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CalendarViewMode.entries.forEachIndexed { idx, mode ->
                    val selected = idx == viewModeIndex
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(MaterialTheme.shapes.small)
                            .clickable { viewModeIndex = idx }
                            .testTag("calendar_mode_${mode.name.lowercase()}"),
                        shape = MaterialTheme.shapes.small,
                        color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = mode.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (viewMode) {
                CalendarViewMode.MONTH -> {
                    item {
                        ShamsiMonthGridCard(
                            year = displayYear,
                            month = displayMonth,
                            selectedDayMillis = selectedDayMillis,
                            todayStartMillis = todayStart,
                            state = state,
                            onPrevMonth = {
                                if (displayMonth == 1) {
                                    displayMonth = 12
                                    displayYear -= 1
                                } else {
                                    displayMonth -= 1
                                }
                            },
                            onNextMonth = {
                                if (displayMonth == 12) {
                                    displayMonth = 1
                                    displayYear += 1
                                } else {
                                    displayMonth += 1
                                }
                            },
                            onSelectDay = { dayMillis ->
                                selectedDayMillis = dayMillis
                            }
                        )
                    }
                }

                CalendarViewMode.WEEK -> {
                    item {
                        ShamsiWeekStripCard(
                            selectedDayMillis = selectedDayMillis,
                            todayStartMillis = todayStart,
                            state = state,
                            onPrevWeek = { selectedDayMillis -= 7L * 86_400_000L },
                            onNextWeek = { selectedDayMillis += 7L * 86_400_000L },
                            onSelectDay = { selectedDayMillis = it }
                        )
                    }
                }

                CalendarViewMode.DAY -> {
                    item {
                        DaneshinoCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                IconButton(
                                    onClick = { selectedDayMillis -= 86_400_000L },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                        contentDescription = "روز قبل"
                                    )
                                }
                                Text(
                                    text = PersianDateUtil.formatFullShamsiDate(selectedDayMillis),
                                    style = MaterialTheme.typography.titleMedium,
                                    textAlign = TextAlign.Center
                                )
                                IconButton(
                                    onClick = { selectedDayMillis += 86_400_000L },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                        contentDescription = "روز بعد"
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Legend strip
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    LegendDot("کلاس", DaneshinoBlue)
                    LegendDot("تکلیف", DaneshinoAmber)
                    LegendDot("امتحان", DaneshinoCoral)
                    LegendDot("مطالعه", DaneshinoTeal)
                    LegendDot("هدف", DaneshinoPurple)
                }
            }

            // Selected Day Details
            item {
                SelectedDayAgendaSection(
                    dayMillis = selectedDayMillis,
                    state = state,
                    nowMillis = nowMillis
                )
            }
        }
    }
}

@Composable
private fun ShamsiMonthGridCard(
    year: Int,
    month: Int,
    selectedDayMillis: Long,
    todayStartMillis: Long,
    state: DaneshinoDataState,
    onPrevMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onSelectDay: (Long) -> Unit
) {
    val daysCount = remember(year, month) { PersianDateUtil.daysInShamsiMonth(year, month) }
    val firstDow = remember(year, month) { PersianDateUtil.firstDayOfWeekInShamsiMonth(year, month) }

    DaneshinoCard {
        // Month / Year Header (properly aligned)
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onPrevMonth,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                    contentDescription = "ماه قبل"
                )
            }
            Text(
                text = PersianDateUtil.formatMonthYear(year, month),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
            IconButton(
                onClick = onNextMonth,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "ماه بعد"
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        // Weekday header row (Saturday .. Friday, aligned in 7 equal columns)
        Row(modifier = Modifier.fillMaxWidth()) {
            PersianDateUtil.weekDayShortNames.forEach { shortName ->
                Text(
                    text = shortName,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        val totalCells = firstDow + daysCount
        val rows = (totalCells + 6) / 7

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            for (r in 0 until rows) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (c in 0 until 7) {
                        val cellIndex = r * 7 + c
                        val dayNum = cellIndex - firstDow + 1
                        if (dayNum in 1..daysCount) {
                            val cellMillis = PersianDateUtil.shamsiToEpochMillis(year, month, dayNum, 0, 0)
                            val isSelected = PersianDateUtil.isSameLocalDay(cellMillis, selectedDayMillis)
                            val isToday = PersianDateUtil.isSameLocalDay(cellMillis, todayStartMillis)
                            val markers = dayMarkers(cellMillis, c, state)

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(0.95f)
                                    .padding(2.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        when {
                                            isSelected -> MaterialTheme.colorScheme.primary
                                            isToday -> MaterialTheme.colorScheme.primaryContainer
                                            else -> Color.Transparent
                                        }
                                    )
                                    .clickable { onSelectDay(cellMillis) },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = PersianDateUtil.formatInt(dayNum),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal,
                                        color = when {
                                            isSelected -> MaterialTheme.colorScheme.onPrimary
                                            isToday -> MaterialTheme.colorScheme.onPrimaryContainer
                                            else -> MaterialTheme.colorScheme.onSurface
                                        }
                                    )
                                    if (markers.isNotEmpty()) {
                                        Spacer(Modifier.height(2.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                            markers.take(3).forEach { dotColor ->
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(if (isSelected) MaterialTheme.colorScheme.onPrimary else dotColor)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShamsiWeekStripCard(
    selectedDayMillis: Long,
    todayStartMillis: Long,
    state: DaneshinoDataState,
    onPrevWeek: () -> Unit,
    onNextWeek: () -> Unit,
    onSelectDay: (Long) -> Unit
) {
    val weekStart = remember(selectedDayMillis) { PersianDateUtil.startOfPersianWeekMillis(selectedDayMillis) }
    val startShamsi = remember(weekStart) { PersianDateUtil.toShamsi(weekStart) }

    DaneshinoCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onPrevWeek,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "هفته قبل")
            }
            Text(
                text = PersianDateUtil.formatMonthYear(startShamsi.year, startShamsi.month),
                style = MaterialTheme.typography.titleMedium
            )
            IconButton(
                onClick = onNextWeek,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "هفته بعد")
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for (dow in 0..6) {
                val dayMillis = weekStart + dow * 86_400_000L
                val shamsi = PersianDateUtil.toShamsi(dayMillis)
                val isSelected = PersianDateUtil.isSameLocalDay(dayMillis, selectedDayMillis)
                val isToday = PersianDateUtil.isSameLocalDay(dayMillis, todayStartMillis)
                val markers = dayMarkers(dayMillis, dow, state)

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            when {
                                isSelected -> MaterialTheme.colorScheme.primary
                                isToday -> MaterialTheme.colorScheme.primaryContainer
                                else -> MaterialTheme.colorScheme.surfaceContainerLow
                            }
                        )
                        .clickable { onSelectDay(dayMillis) }
                        .padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = PersianDateUtil.weekDayShortNames[dow],
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = PersianDateUtil.formatInt(shamsi.day),
                        style = MaterialTheme.typography.titleSmall,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        markers.take(3).forEach { color ->
                            Box(
                                modifier = Modifier
                                    .size(5.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) MaterialTheme.colorScheme.onPrimary else color)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SelectedDayAgendaSection(
    dayMillis: Long,
    state: DaneshinoDataState,
    nowMillis: Long
) {
    val dow = PersianDateUtil.todayPersianDayOfWeek(dayMillis)
    val dateKey = PersianDateUtil.dateKey(dayMillis)

    val classes = state.coursesWithSessions.flatMap { cws ->
        cws.sessions.filter { it.dayOfWeek == dow }.map { cws.course to it }
    }.sortedBy { it.second.startMinuteOfDay }

    val assignments = state.assignments.filter { PersianDateUtil.isSameLocalDay(it.dueAtMillis, dayMillis) }
    val exams = state.exams.filter { PersianDateUtil.isSameLocalDay(it.examAtMillis, dayMillis) }
    val studies = state.studySessions.filter { it.dateKey == dateKey }
    val dailyGoals = state.goals.filter { GoalPeriod.fromName(it.period) == GoalPeriod.DAILY }

    val hasAny = classes.isNotEmpty() || assignments.isNotEmpty() || exams.isNotEmpty() || studies.isNotEmpty() || dailyGoals.isNotEmpty()

    if (!hasAny) {
        DaneshinoCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CalendarMonth,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    text = stringResource(R.string.calendar_empty_day),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        return
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        classes.forEach { (course, session) ->
            val color = CourseColorPalette.safeColor(course.colorArgb)
            DaneshinoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(color)
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(course.name, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = PersianDateUtil.formatTimeRange(session.startMinuteOfDay, session.endMinuteOfDay),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    PillBadge("کلاس", color.copy(alpha = 0.16f), color)
                }
            }
        }

        exams.forEach { exam ->
            DaneshinoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.EventNote, contentDescription = null, tint = DaneshinoCoral)
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(exam.title, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "ساعت ${PersianDateUtil.formatTimeFromMillis(exam.examAtMillis)}" +
                                if (exam.location.isNotBlank()) " • ${exam.location}" else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    PillBadge(
                        PersianDateUtil.formatDaysUntilExam(exam.examAtMillis, nowMillis),
                        MaterialTheme.colorScheme.errorContainer,
                        MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
        }

        assignments.forEach { task ->
            DaneshinoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = DaneshinoAmber)
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(task.title, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "مهلت ساعت ${PersianDateUtil.formatTimeFromMillis(task.dueAtMillis)} • ${AssignmentStatus.fromName(task.status).persianLabel}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    PillBadge("تکلیف", DaneshinoAmber.copy(alpha = 0.18f), MaterialTheme.colorScheme.onSurface)
                }
            }
        }

        studies.forEach { session ->
            DaneshinoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = DaneshinoTeal)
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("مطالعه: ${session.courseNameSnapshot.ifBlank { "آزاد" }}", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = PersianDateUtil.formatDurationMinutes((session.durationSeconds / 60L).toInt()),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    PillBadge("مطالعه", MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                }
            }
        }

        dailyGoals.forEach { goal ->
            DaneshinoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Flag, contentDescription = null, tint = DaneshinoPurple)
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(goal.title, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "هدف روزانه: ${PersianDateUtil.formatDurationMinutes(goal.targetMinutes)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    PillBadge("هدف", MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer)
                }
            }
        }
    }
}

@Composable
private fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun dayMarkers(dayMillis: Long, persianDow: Int, state: DaneshinoDataState): List<Color> {
    val dots = mutableListOf<Color>()
    if (state.allSessions.any { it.dayOfWeek == persianDow }) dots.add(DaneshinoBlue)
    if (state.exams.any { PersianDateUtil.isSameLocalDay(it.examAtMillis, dayMillis) }) dots.add(DaneshinoCoral)
    if (state.assignments.any { PersianDateUtil.isSameLocalDay(it.dueAtMillis, dayMillis) }) dots.add(DaneshinoAmber)
    val dk = PersianDateUtil.dateKey(dayMillis)
    if (state.studySessions.any { it.dateKey == dk }) dots.add(DaneshinoTeal)
    return dots
}
