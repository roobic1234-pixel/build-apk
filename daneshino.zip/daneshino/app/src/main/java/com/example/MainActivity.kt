package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.reminder.ReminderNotificationHelper
import com.example.ui.screens.AttachmentsScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.CourseDetailScreen
import com.example.ui.screens.CoursesScreen
import com.example.ui.screens.FlashcardsScreen
import com.example.ui.screens.GlobalSearchScreen
import com.example.ui.screens.GoalsScreen
import com.example.ui.screens.GradesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NotesScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.StudyTimerScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.theme.DaneshinoTheme
import com.example.ui.viewmodel.DaneshinoViewModel

object Routes {
    const val HOME = "home"
    const val COURSES = "courses"
    const val CALENDAR = "calendar"
    const val TASKS = "tasks"
    const val PROFILE = "profile"

    const val GRADES = "grades"
    const val STUDY_TIMER = "study_timer"
    const val GOALS = "goals"
    const val FLASHCARDS = "flashcards"
    const val NOTES = "notes"
    const val FILES = "files"
    const val FILES_FOR_COURSE = "files/{courseId}"
    const val SEARCH = "search"
    const val COURSE_DETAIL = "course_detail/{courseId}"

    fun filesForCourse(courseId: Long) = "files/$courseId"
    fun courseDetail(courseId: Long) = "course_detail/$courseId"
}

private data class BottomTabItem(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

// Exact RTL order: خانه، درس‌ها، تقویم، کارها، پروفایل
private val bottomTabs = listOf(
    BottomTabItem(Routes.HOME, R.string.nav_home, Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
    BottomTabItem(Routes.COURSES, R.string.nav_courses, Icons.Filled.MenuBook, Icons.Outlined.MenuBook, "nav_courses"),
    BottomTabItem(Routes.CALENDAR, R.string.nav_calendar, Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth, "nav_calendar"),
    BottomTabItem(Routes.TASKS, R.string.nav_tasks, Icons.Filled.Checklist, Icons.Outlined.Checklist, "nav_tasks"),
    BottomTabItem(Routes.PROFILE, R.string.nav_profile, Icons.Filled.Person, Icons.Outlined.Person, "nav_profile")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val initialDestination = intent?.getStringExtra(ReminderNotificationHelper.EXTRA_NAV_DESTINATION)
        val app = application as DaneshinoApplication

        setContent {
            val viewModel: DaneshinoViewModel = viewModel(
                factory = DaneshinoViewModel.Factory(app.container)
            )
            val dataState by viewModel.dataState.collectAsStateWithLifecycle()
            val timerState by viewModel.timerState.collectAsStateWithLifecycle()
            val nowMillis by viewModel.nowMillis.collectAsStateWithLifecycle()
            val isAlarmPlaying by viewModel.isAlarmPlaying.collectAsStateWithLifecycle()
            val pendingRestore by viewModel.pendingRestorePayload.collectAsStateWithLifecycle()

            // Complete Persian RTL direction across the entire app
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                DaneshinoTheme(themeMode = dataState.preferences.themeMode) {
                    if (dataState.isLoading) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    } else if (!dataState.preferences.onboardingCompleted) {
                        OnboardingScreen(
                            onComplete = { name -> viewModel.completeOnboarding(name) }
                        )
                    } else {
                        DaneshinoRootScaffold(
                            viewModel = viewModel,
                            initialDestination = initialDestination,
                            state = dataState,
                            timerState = timerState,
                            nowMillis = nowMillis,
                            isAlarmPlaying = isAlarmPlaying,
                            pendingRestore = pendingRestore
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DaneshinoRootScaffold(
    viewModel: DaneshinoViewModel,
    initialDestination: String?,
    state: com.example.ui.viewmodel.DaneshinoDataState,
    timerState: com.example.data.prefs.PersistedTimerState,
    nowMillis: Long,
    isAlarmPlaying: Boolean,
    pendingRestore: com.example.data.backup.DaneshinoBackupPayload?
) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    var triggerAddCourse by remember { mutableStateOf(false) }
    var triggerAddTask by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.messages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    LaunchedEffect(initialDestination) {
        if (initialDestination == Routes.COURSES || initialDestination == Routes.TASKS) {
            navController.navigate(initialDestination) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }
    }

    val topLevelRoutes = remember { bottomTabs.map { it.route }.toSet() }
    val showBottomBar = currentRoute in topLevelRoutes
    val showFab = currentRoute == Routes.COURSES || currentRoute == Routes.TASKS

    // Single root Scaffold — no nested Scaffolds anywhere in the app!
    // contentWindowInsets = WindowInsets(0, 0, 0, 0) ensures system insets are applied exactly once
    // (statusBarsPadding on screen headers, navigationBars automatically on Material 3 NavigationBar).
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp
                ) {
                    bottomTabs.forEach { tab ->
                        val selected = currentRoute == tab.route
                        val label = stringResource(tab.labelRes)
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (!selected) {
                                    navController.navigate(tab.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = label,
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (showFab) {
                FloatingActionButton(
                    onClick = {
                        when (currentRoute) {
                            Routes.COURSES -> triggerAddCourse = true
                            Routes.TASKS -> triggerAddTask = true
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("main_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = if (currentRoute == Routes.COURSES) "افزودن درس" else "افزودن مورد جدید"
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    state = state,
                    nowMillis = nowMillis,
                    onNavigateSearch = { navController.navigate(Routes.SEARCH) },
                    onNavigateCourses = {
                        navController.navigate(Routes.COURSES) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onNavigateTasks = {
                        navController.navigate(Routes.TASKS) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onNavigateGrades = { navController.navigate(Routes.GRADES) },
                    onNavigateStudyTimer = { navController.navigate(Routes.STUDY_TIMER) },
                    onNavigateGoals = { navController.navigate(Routes.GOALS) },
                    onNavigateFlashcards = { navController.navigate(Routes.FLASHCARDS) },
                    onNavigateNotes = { navController.navigate(Routes.NOTES) },
                    onNavigateFiles = { navController.navigate(Routes.FILES) }
                )
            }

            composable(Routes.COURSES) {
                CoursesScreen(
                    state = state,
                    onSaveCourse = viewModel::saveCourseWithSessions,
                    onDeleteCourse = viewModel::deleteCourse,
                    onToggleFavorite = viewModel::toggleCourseFavorite,
                    onOpenAttachments = { cid -> navController.navigate(Routes.filesForCourse(cid)) },
                    onOpenCourseDetail = { cid -> navController.navigate(Routes.courseDetail(cid)) },
                    showAddDialogExternal = triggerAddCourse,
                    onDismissAddDialogExternal = { triggerAddCourse = false }
                )
            }

            composable(Routes.CALENDAR) {
                CalendarScreen(
                    state = state,
                    nowMillis = nowMillis
                )
            }

            composable(Routes.TASKS) {
                TasksScreen(
                    state = state,
                    nowMillis = nowMillis,
                    onSaveAssignment = viewModel::saveAssignment,
                    onDeleteAssignment = viewModel::deleteAssignment,
                    onSaveExam = viewModel::saveExam,
                    onDeleteExam = viewModel::deleteExam,
                    showAddDialogExternal = triggerAddTask,
                    onDismissAddDialogExternal = { triggerAddTask = false }
                )
            }

            composable(Routes.PROFILE) {
                ProfileScreen(
                    state = state,
                    isAlarmPlaying = isAlarmPlaying,
                    pendingRestorePayload = pendingRestore,
                    canScheduleExactAlarms = viewModel::canScheduleExactAlarms,
                    isDeviceSilencedOrDnd = viewModel::isDeviceSilencedOrDnd,
                    onUpdateProfile = viewModel::updateProfile,
                    onSetThemeMode = viewModel::setThemeMode,
                    onSetClassRemindersEnabled = viewModel::setClassRemindersEnabled,
                    onSetClassReminderMinutes = viewModel::setClassReminderMinutes,
                    onSetClassReminderMethod = viewModel::setClassReminderMethod,
                    onSetAssignmentRemindersEnabled = viewModel::setAssignmentRemindersEnabled,
                    onSetExamRemindersEnabled = viewModel::setExamRemindersEnabled,
                    onStopAlarmAudio = viewModel::stopAlarmAudio,
                    onTestAlarm = viewModel::testAlarm,
                    onSendTestNotification = viewModel::sendTestNotification,
                    onBuildBackupJson = { viewModel.buildBackupJson() },
                    onInspectBackupJson = viewModel::inspectBackupJson,
                    onConfirmRestore = viewModel::confirmPendingRestore,
                    onCancelRestore = viewModel::cancelPendingRestore,
                    onMessage = viewModel::emitMessage
                )
            }

            composable(Routes.GRADES) {
                GradesScreen(
                    state = state,
                    onUpdateGrade = viewModel::updateCourseGrade,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.STUDY_TIMER) {
                StudyTimerScreen(
                    state = state,
                    timerState = timerState,
                    nowMillis = nowMillis,
                    onConfigureTimer = viewModel::configureTimer,
                    onStart = viewModel::startTimer,
                    onPause = viewModel::pauseTimer,
                    onResume = viewModel::resumeTimer,
                    onStopAndSave = viewModel::stopAndSaveStudyTimer,
                    onReset = viewModel::resetTimer,
                    onDeleteSession = viewModel::deleteStudySession,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.GOALS) {
                GoalsScreen(
                    state = state,
                    nowMillis = nowMillis,
                    onSaveGoal = viewModel::saveGoal,
                    onDeleteGoal = viewModel::deleteGoal,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.FLASHCARDS) {
                FlashcardsScreen(
                    state = state,
                    onSaveDeck = viewModel::saveDeck,
                    onDeleteDeck = viewModel::deleteDeck,
                    onSaveCard = viewModel::saveFlashcard,
                    onMarkReviewed = viewModel::markFlashcardReviewed,
                    onDeleteCard = viewModel::deleteFlashcard,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.NOTES) {
                NotesScreen(
                    state = state,
                    onSaveNote = viewModel::saveNote,
                    onDeleteNote = viewModel::deleteNote,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.FILES) {
                AttachmentsScreen(
                    state = state,
                    initialCourseId = null,
                    onAddAttachment = viewModel::addAttachment,
                    onDeleteAttachment = viewModel::deleteAttachment,
                    onMessage = viewModel::emitMessage,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = Routes.FILES_FOR_COURSE,
                arguments = listOf(navArgument("courseId") { type = NavType.LongType })
            ) { entry ->
                val cid = entry.arguments?.getLong("courseId")
                AttachmentsScreen(
                    state = state,
                    initialCourseId = cid,
                    onAddAttachment = viewModel::addAttachment,
                    onDeleteAttachment = viewModel::deleteAttachment,
                    onMessage = viewModel::emitMessage,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = Routes.COURSE_DETAIL,
                arguments = listOf(navArgument("courseId") { type = NavType.LongType })
            ) { entry ->
                val cid = entry.arguments?.getLong("courseId") ?: -1L
                CourseDetailScreen(
                    courseId = cid,
                    state = state,
                    onSaveCourse = viewModel::saveCourseWithSessions,
                    onDeleteCourse = viewModel::deleteCourse,
                    onOpenAttachments = { id -> navController.navigate(Routes.filesForCourse(id)) },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.SEARCH) {
                GlobalSearchScreen(
                    state = state,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
