package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Style
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.core.PersianDateUtil
import com.example.data.local.CourseEntity
import com.example.data.local.FlashcardDeckEntity
import com.example.data.local.FlashcardEntity
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.DaneshinoCard
import com.example.ui.components.DaneshinoEmptyState
import com.example.ui.components.PillBadge
import com.example.ui.components.ScreenHeader
import com.example.ui.viewmodel.DaneshinoDataState

@Composable
fun FlashcardsScreen(
    state: DaneshinoDataState,
    onSaveDeck: (FlashcardDeckEntity) -> Unit,
    onDeleteDeck: (Long) -> Unit,
    onSaveCard: (FlashcardEntity) -> Unit,
    onMarkReviewed: (FlashcardEntity, Boolean) -> Unit,
    onDeleteCard: (Long) -> Unit,
    onBack: () -> Unit
) {
    var activeDeckId by remember { mutableStateOf<Long?>(null) }
    var reviewingDeckId by remember { mutableStateOf<Long?>(null) }

    var showDeckEditor by remember { mutableStateOf(false) }
    var editingDeck by remember { mutableStateOf<FlashcardDeckEntity?>(null) }
    var deletingDeck by remember { mutableStateOf<FlashcardDeckEntity?>(null) }

    var showCardEditor by remember { mutableStateOf(false) }
    var editingCard by remember { mutableStateOf<FlashcardEntity?>(null) }
    var deletingCard by remember { mutableStateOf<FlashcardEntity?>(null) }

    // Interactive Review Mode
    reviewingDeckId?.let { deckId ->
        val deck = state.decks.firstOrNull { it.id == deckId }
        val cards = state.flashcards.filter { it.deckId == deckId }
        if (deck != null) {
            FlashcardReviewView(
                deckTitle = deck.title,
                cards = cards,
                onMarkReviewed = onMarkReviewed,
                onExit = { reviewingDeckId = null }
            )
            return
        }
    }

    if (showDeckEditor || editingDeck != null) {
        DeckEditorDialog(
            existing = editingDeck,
            courses = state.courses,
            onSave = {
                onSaveDeck(it)
                showDeckEditor = false
                editingDeck = null
            },
            onDismiss = {
                showDeckEditor = false
                editingDeck = null
            }
        )
    }

    deletingDeck?.let { target ->
        ConfirmDeleteDialog(
            title = "حذف دسته فلش‌کارت",
            body = "آیا از حذف دسته «${target.title}» و تمام کارت‌های داخل آن مطمئن هستید؟",
            onConfirm = {
                onDeleteDeck(target.id)
                if (activeDeckId == target.id) activeDeckId = null
                deletingDeck = null
            },
            onDismiss = { deletingDeck = null }
        )
    }

    val selectedDeck = activeDeckId?.let { id -> state.decks.firstOrNull { it.id == id } }

    if (selectedDeck != null && (showCardEditor || editingCard != null)) {
        CardEditorDialog(
            deckId = selectedDeck.id,
            existing = editingCard,
            onSave = {
                onSaveCard(it)
                showCardEditor = false
                editingCard = null
            },
            onDismiss = {
                showCardEditor = false
                editingCard = null
            }
        )
    }

    deletingCard?.let { target ->
        ConfirmDeleteDialog(
            title = "حذف کارت",
            body = "آیا از حذف این فلش‌کارت مطمئن هستید؟",
            onConfirm = {
                onDeleteCard(target.id)
                deletingCard = null
            },
            onDismiss = { deletingCard = null }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
    ) {
        if (selectedDeck == null) {
            ScreenHeader(
                title = "فلش‌کارت‌ها",
                subtitle = "دسته‌بندی‌شده بر اساس درس برای مرور سریع",
                onBack = onBack,
                actions = {
                    IconButton(
                        onClick = { showDeckEditor = true },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "ساخت دسته جدید")
                    }
                }
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (state.decks.isEmpty()) {
                    item {
                        DaneshinoEmptyState(
                            icon = Icons.Default.Style,
                            title = "هنوز دسته فلش‌کارتی نساخته‌اید",
                            subtitle = "دسته‌های فلش‌کارت برای هر درس بسازید و مفاهیم مهم امتحان را مرور کنید.",
                            actionLabel = "ساخت اولین دسته",
                            onAction = { showDeckEditor = true }
                        )
                    }
                } else {
                    items(state.decks, key = { it.id }) { deck ->
                        val count = state.flashcards.count { it.deckId == deck.id }
                        val course = state.courseById(deck.courseId)
                        DaneshinoCard(onClick = { activeDeckId = deck.id }) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(deck.title, style = MaterialTheme.typography.titleMedium)
                                    if (course != null) {
                                        Text(course.name, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                    }
                                    if (deck.description.isNotBlank()) {
                                        Text(deck.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                PillBadge(
                                    text = "${PersianDateUtil.formatInt(count)} کارت",
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                FilledTonalButton(
                                    onClick = { reviewingDeckId = deck.id },
                                    enabled = count > 0
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                                    Spacer(Modifier.width(4.dp))
                                    Text("شروع مرور")
                                }
                                Row {
                                    IconButton(
                                        onClick = { editingDeck = deck },
                                        modifier = Modifier.minimumInteractiveComponentSize()
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "ویرایش دسته", tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(
                                        onClick = { deletingDeck = deck },
                                        modifier = Modifier.minimumInteractiveComponentSize()
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف دسته", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            val deckCards = state.flashcards.filter { it.deckId == selectedDeck.id }
            ScreenHeader(
                title = selectedDeck.title,
                subtitle = "${PersianDateUtil.formatInt(deckCards.size)} کارت",
                onBack = { activeDeckId = null },
                actions = {
                    IconButton(
                        onClick = { showCardEditor = true },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "افزودن کارت جدید")
                    }
                }
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (deckCards.isNotEmpty()) {
                    item {
                        Button(
                            onClick = { reviewingDeckId = selectedDeck.id },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("مرور کارت‌های این دسته")
                        }
                    }
                }

                if (deckCards.isEmpty()) {
                    item {
                        DaneshinoEmptyState(
                            icon = Icons.Default.Style,
                            title = "این دسته هنوز کارتی ندارد",
                            subtitle = "روی‌کارت (پرسش) و پشت‌کارت (پاسخ) را اضافه کنید.",
                            actionLabel = "افزودن اولین کارت",
                            onAction = { showCardEditor = true }
                        )
                    }
                } else {
                    items(deckCards, key = { it.id }) { card ->
                        DaneshinoCard {
                            Text("روی کارت:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Text(card.front, style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(6.dp))
                            Text("پشت کارت:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                            Text(card.back, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                IconButton(
                                    onClick = { editingCard = card },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "ویرایش کارت", tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(
                                    onClick = { deletingCard = card },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف کارت", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FlashcardReviewView(
    deckTitle: String,
    cards: List<FlashcardEntity>,
    onMarkReviewed: (FlashcardEntity, Boolean) -> Unit,
    onExit: () -> Unit
) {
    var index by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
    ) {
        ScreenHeader(
            title = "مرور: $deckTitle",
            subtitle = if (cards.isEmpty() || index >= cards.size) "پایان مرور" else "کارت ${PersianDateUtil.formatInt(index + 1)} از ${PersianDateUtil.formatInt(cards.size)}",
            onBack = onExit
        )

        if (cards.isEmpty() || index >= cards.size) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                DaneshinoEmptyState(
                    icon = Icons.Default.Check,
                    title = "مرور این دسته کامل شد!",
                    subtitle = "همه کارت‌های این دسته را مرور کردید.",
                    actionLabel = "مرور دوباره",
                    onAction = {
                        index = 0
                        flipped = false
                    }
                )
            }
        } else {
            val current = cards[index]
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                DaneshinoCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    containerColor = if (flipped) {
                        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f)
                    } else {
                        MaterialTheme.colorScheme.surfaceContainer
                    },
                    onClick = { flipped = !flipped }
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            PillBadge(
                                text = if (flipped) "پشت کارت (پاسخ)" else "روی کارت (پرسش)",
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(Modifier.height(20.dp))
                            Text(
                                text = if (flipped) current.back else current.front,
                                style = MaterialTheme.typography.headlineSmall,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(24.dp))
                            Text(
                                text = "برای برگرداندن کارت لمس کنید",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            onMarkReviewed(current, false)
                            flipped = false
                            index += 1
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("نیاز به مرور")
                    }
                    Button(
                        onClick = {
                            onMarkReviewed(current, true)
                            flipped = false
                            index += 1
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("بلد بودم")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DeckEditorDialog(
    existing: FlashcardDeckEntity?,
    courses: List<CourseEntity>,
    onSave: (FlashcardDeckEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var description by remember { mutableStateOf(existing?.description ?: "") }
    var courseId by remember { mutableStateOf(existing?.courseId) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "دسته فلش‌کارت جدید" else "ویرایش دسته") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; error = null },
                    label = { Text("عنوان دسته *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("توضیحات") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                if (courses.isNotEmpty()) {
                    Text("درس مرتبط", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = courseId == null, onClick = { courseId = null }, label = { Text("عمومی") })
                        courses.forEach { c ->
                            FilterChip(selected = courseId == c.id, onClick = { courseId = c.id }, label = { Text(c.name) })
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (title.trim().isBlank()) {
                    error = "لطفاً عنوان دسته را وارد کنید."
                    return@Button
                }
                onSave(
                    FlashcardDeckEntity(
                        id = existing?.id ?: 0L,
                        title = title.trim(),
                        courseId = courseId,
                        description = description.trim(),
                        createdAtMillis = existing?.createdAtMillis ?: System.currentTimeMillis()
                    )
                )
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun CardEditorDialog(
    deckId: Long,
    existing: FlashcardEntity?,
    onSave: (FlashcardEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var front by remember { mutableStateOf(existing?.front ?: "") }
    var back by remember { mutableStateOf(existing?.back ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "کارت جدید" else "ویرایش کارت") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                OutlinedTextField(
                    value = front,
                    onValueChange = { front = it; error = null },
                    label = { Text("روی کارت (پرسش / مفهوم) *") },
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = back,
                    onValueChange = { back = it; error = null },
                    label = { Text("پشت کارت (پاسخ / توضیح) *") },
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                if (front.trim().isBlank() || back.trim().isBlank()) {
                    error = "لطفاً هر دو روی کارت را کامل کنید."
                    return@Button
                }
                onSave(
                    FlashcardEntity(
                        id = existing?.id ?: 0L,
                        deckId = deckId,
                        front = front.trim(),
                        back = back.trim(),
                        knownCount = existing?.knownCount ?: 0,
                        reviewCount = existing?.reviewCount ?: 0,
                        lastReviewedAtMillis = existing?.lastReviewedAtMillis
                    )
                )
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
