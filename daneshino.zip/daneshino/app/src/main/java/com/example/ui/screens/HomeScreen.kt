package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.NoteAlt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.PersianDateUtil
import com.example.data.local.AssignmentStatus
import com.example.data.local.ClassSessionEntity
import com.example.data.local.CourseEntity
import com.example.reminder.ReminderTriggerCalculator
import com.example.ui.components.DaneshinoCard
import com.example.ui.components.PillBadge
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CourseColorPalette
import com.example.ui.theme.DaneshinoBlue
import com.example.ui.theme.DaneshinoNavy
import com.example.ui.theme.DaneshinoPurple
import com.example.ui.theme.DaneshinoTeal
import com.example.ui.viewmodel.DaneshinoDataState
import java.util.Calendar

@Composable
fun HomeScreen(
    state: DaneshinoDataState,
    nowMillis: Long,
    onNavigateSearch: () -> Unit,
    onNavigateCourses: () -> Unit,
    onNavigateTasks: () -> Unit,
    onNavigateGrades: () -> Unit,
    onNavigateStudyTimer: () -> Unit,
    onNavigateGoals: () -> Unit,
    onNavigateFlashcards: () -> Unit,
    onNavigateNotes: () -> Unit,
    onNavigateFiles: () -> Unit
) {
    val todayPersianDow = remember(nowMillis) { PersianDateUtil.todayPersianDayOfWeek(nowMillis) }
    val todayDateText = remember(nowMillis / 60_000L) { PersianDateUtil.formatFullShamsiDate(nowMillis) }

    val todayClasses = remember(state.coursesWithSessions, todayPersianDow) {
        state.coursesWithSessions.flatMap { cws ->
            cws.sessions
                .filter { it.dayOfWeek == todayPersianDow }
                .map { cws.course to it }
        }.sortedBy { it.second.startMinuteOfDay }
    }

    val nextClassEntry = remember(state.coursesWithSessions, nowMillis / 30_000L) {
        findNextUpcomingClass(state, nowMillis)
    }

    val upcomingAssignments = remember(state.assignments) {
        state.assignments
            .filter { it.status != AssignmentStatus.COMPLETED.name }
            .sortedBy { it.dueAtMillis }
            .take(3)
    }

    val upcomingExams = remember(state.exams, nowMillis / 60_000L) {
        val todayStart = PersianDateUtil.startOfDayMillis(nowMillis)
        state.exams
            .filter { it.examAtMillis >= todayStart }
            .sortedBy { it.examAtMillis }
            .take(3)
    }

    val todayStudyMinutes = remember(state.studySessions, nowMillis / 60_000L) {
        val todayKey = PersianDateUtil.dateKey(nowMillis)
        (state.studySessions.filter { it.dateKey == todayKey }.sumOf { it.durationSeconds } / 60L).toInt()
    }

    val weekStudyMinutes = remember(state.studySessions, nowMillis / 60_000L) {
        val weekStart = PersianDateUtil.startOfPersianWeekMillis(nowMillis)
        (state.studySessions.filter { it.startAtMillis >= weekStart }.sumOf { it.durationSeconds } / 60L).toInt()
    }

    val completedTasksThisWeek = remember(state.assignments) {
        state.assignments.count { it.status == AssignmentStatus.COMPLETED.name }
    }
    val totalTasks = state.assignments.size

    val isCompletelyEmpty = state.courses.isEmpty() &&
        state.assignments.isEmpty() &&
        state.exams.isEmpty() &&
        state.studySessions.isEmpty() &&
        state.goals.isEmpty()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 0.dp,
            bottom = 28.dp
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Greeting Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(top = 12.dp)
                    .clip(MaterialTheme.shapes.large)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(DaneshinoNavy, DaneshinoBlue)
                        )
                    )
                    .padding(18.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            val greeting = if (state.preferences.studentName.isNotBlank()) {
                                stringResource(R.string.home_greeting_named, state.preferences.studentName)
                            } else {
                                stringResource(R.string.home_greeting_default)
                            }
                            Text(
                                text = greeting,
                                style = MaterialTheme.typography.headlineSmall,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = todayDateText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.88f)
                            )
                        }
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.16f)
                        ) {
                            IconButton(
                                onClick = onNavigateSearch,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("home_search_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "جستجوی سراسری",
                                    tint = Color.White
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // Real-data summary strip (shows real zeros on fresh install)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        HeroStatPill(
                            label = "مطالعه امروز",
                            value = PersianDateUtil.formatDurationMinutes(todayStudyMinutes),
                            modifier = Modifier.weight(1f)
                        )
                        HeroStatPill(
                            label = "مطالعه هفته",
                            value = PersianDateUtil.formatDurationMinutes(weekStudyMinutes),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // First-run Getting Started Guide (never fake data!)
        if (isCompletelyEmpty) {
            item {
                DaneshinoCard(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)) {
                    Text(
                        text = stringResource(R.string.home_empty_guide_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.home_empty_guide_body),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onNavigateCourses,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("home_guide_add_course")
                        ) {
                            Text("افزودن درس")
                        }
                        FilledTonalButton(
                            onClick = onNavigateTasks,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("home_guide_add_task")
                        ) {
                            Text("ثبت تکلیف/امتحان")
                        }
                    }
                }
            }
        }

        // Quick Access Grid (6 tools without cluttering bottom nav)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeader(title = stringResource(R.string.home_quick_access))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickToolTile(
                        title = stringResource(R.string.tool_grades),
                        icon = Icons.Default.Calculate,
                        accent = DaneshinoBlue,
                        onClick = onNavigateGrades,
                        testTag = "quick_grades",
                        modifier = Modifier.weight(1f)
                    )
                    QuickToolTile(
                        title = stringResource(R.string.tool_study_timer),
                        icon = Icons.Default.Timer,
                        accent = DaneshinoTeal,
                        onClick = onNavigateStudyTimer,
                        testTag = "quick_timer",
                        modifier = Modifier.weight(1f)
                    )
                    QuickToolTile(
                        title = stringResource(R.string.tool_goals),
                        icon = Icons.Default.Flag,
                        accent = DaneshinoPurple,
                        onClick = onNavigateGoals,
                        testTag = "quick_goals",
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickToolTile(
                        title = stringResource(R.string.tool_flashcards),
                        icon = Icons.Default.Style,
                        accent = Color(0xFFF59E0B),
                        onClick = onNavigateFlashcards,
                        testTag = "quick_flashcards",
                        modifier = Modifier.weight(1f)
                    )
                    QuickToolTile(
                        title = stringResource(R.string.tool_notes),
                        icon = Icons.Default.NoteAlt,
                        accent = Color(0xFFFB7185),
                        onClick = onNavigateNotes,
                        testTag = "quick_notes",
                        modifier = Modifier.weight(1f)
                    )
                    QuickToolTile(
                        title = stringResource(R.string.tool_files),
                        icon = Icons.Default.AttachFile,
                        accent = Color(0xFF6366F1),
                        onClick = onNavigateFiles,
                        testTag = "quick_files",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Next Class Countdown Card
        if (nextClassEntry != null) {
            item {
                val (course, session, startEpoch) = nextClassEntry
                val courseColor = CourseColorPalette.safeColor(course.colorArgb)
                DaneshinoCard(onClick = onNavigateCourses) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(courseColor)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.home_next_class),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        PillBadge(
                            text = PersianDateUtil.formatCountdownMinutes(startEpoch, nowMillis),
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = course.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(4.dp))
                    val dayName = PersianDateUtil.weekDayNames.getOrElse(session.dayOfWeek) { "" }
                    val loc = listOf(session.building, session.roomNumber).filter { it.isNotBlank() }.joinToString(" • ")
                    Text(
                        text = "$dayName • ${PersianDateUtil.formatTimeRange(session.startMinuteOfDay, session.endMinuteOfDay)}" +
                            if (loc.isNotBlank()) " • $loc" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Today's Classes
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionHeader(
                    title = stringResource(R.string.home_today_classes),
                    actionText = "برنامه هفتگی",
                    onAction = onNavigateCourses
                )
                if (todayClasses.isEmpty()) {
                    DaneshinoCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = "امروز کلاسی در برنامه شما ثبت نشده است.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    todayClasses.forEach { (course, session) ->
                        val color = CourseColorPalette.safeColor(course.colorArgb)
                        DaneshinoCard(onClick = onNavigateCourses) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(5.dp)
                                        .height(40.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(color)
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = course.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    val loc = listOf(session.building, session.roomNumber)
                                        .filter { it.isNotBlank() }
                                        .joinToString(" - ")
                                    Text(
                                        text = PersianDateUtil.formatTimeRange(
                                            session.startMinuteOfDay,
                                            session.endMinuteOfDay
                                        ) + if (loc.isNotBlank()) " • $loc" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Weekly Progress Summary (Real data only)
        item {
            DaneshinoCard {
                Text(
                    text = stringResource(R.string.home_weekly_progress),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "تکالیف تکمیل‌شده: ${PersianDateUtil.formatInt(completedTasksThisWeek)} از ${PersianDateUtil.formatInt(totalTasks)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val pct = if (totalTasks > 0) (completedTasksThisWeek * 100 / totalTasks) else 0
                    Text(
                        text = "${PersianDateUtil.formatInt(pct)}٪",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { if (totalTasks > 0) completedTasksThisWeek.toFloat() / totalTasks else 0f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }

        // Upcoming Assignments
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionHeader(
                    title = stringResource(R.string.home_upcoming_assignments),
                    actionText = "مشاهده همه",
                    onAction = onNavigateTasks
                )
                if (upcomingAssignments.isEmpty()) {
                    DaneshinoCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Assignment,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = "تکلیف در حال انجامی برای نمایش وجود ندارد.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    upcomingAssignments.forEach { assignment ->
                        val course = state.courseById(assignment.courseId)
                        DaneshinoCard(onClick = onNavigateTasks) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = assignment.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = (course?.name?.let { "$it • " } ?: "") +
                                            "مهلت: ${PersianDateUtil.formatShortShamsiDate(assignment.dueAtMillis)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                PillBadge(
                                    text = PersianDateUtil.formatTimeFromMillis(assignment.dueAtMillis),
                                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }
                    }
                }
            }
        }

        // Upcoming Exams with "X روز تا امتحان"
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionHeader(
                    title = stringResource(R.string.home_upcoming_exams),
                    actionText = "امتحانات",
                    onAction = onNavigateTasks
                )
                if (upcomingExams.isEmpty()) {
                    DaneshinoCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Event,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = "امتحان نزدیکی ثبت نشده است.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    upcomingExams.forEach { exam ->
                        val course = state.courseById(exam.courseId)
                        DaneshinoCard(onClick = onNavigateTasks) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = exam.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = (course?.name?.let { "$it • " } ?: "") +
                                            PersianDateUtil.formatShortShamsiDate(exam.examAtMillis),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(Modifier.width(8.dp))
                                PillBadge(
                                    text = PersianDateUtil.formatDaysUntilExam(exam.examAtMillis, nowMillis),
                                    containerColor = MaterialTheme.colorScheme.errorContainer,
                                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }
                }
            }
        }

        // Active Goals Snapshot
        if (state.goals.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionHeader(
                        title = stringResource(R.string.home_goals_section),
                        actionText = "مدیریت اهداف",
                        onAction = onNavigateGoals
                    )
                    state.goals.take(2).forEach { goal ->
                        val doneMin = state.studyMinutesForGoal(goal, nowMillis)
                        val progress = if (goal.targetMinutes > 0) {
                            (doneMin.toFloat() / goal.targetMinutes).coerceIn(0f, 1f)
                        } else 0f
                        DaneshinoCard(onClick = onNavigateGoals) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = goal.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${PersianDateUtil.formatDurationMinutes(doneMin)} از ${PersianDateUtil.formatDurationMinutes(goal.targetMinutes)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(7.dp)
                                    .clip(RoundedCornerShape(7.dp))
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroStatPill(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = Color.White.copy(alpha = 0.14f)
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.8f)
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun QuickToolTile(
    title: String,
    icon: ImageVector,
    accent: Color,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                shape = CircleShape,
                color = accent.copy(alpha = 0.16f),
                modifier = Modifier.size(42.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accent,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

private data class NextClassEntry(
    val course: CourseEntity,
    val session: ClassSessionEntity,
    val startEpochMillis: Long
)

private fun findNextUpcomingClass(state: DaneshinoDataState, nowMillis: Long): NextClassEntry? {
    var best: NextClassEntry? = null
    for (cws in state.coursesWithSessions) {
        for (session in cws.sessions) {
            val nextStart = ReminderTriggerCalculator.nextClassTriggerMillis(
                dayOfWeekPersian = session.dayOfWeek,
                startMinuteOfDay = session.startMinuteOfDay,
                leadMinutesBefore = 0,
                repeatWeekly = true,
                nowMillis = nowMillis
            ) ?: continue
            if (best == null || nextStart < best.startEpochMillis) {
                best = NextClassEntry(cws.course, session, nextStart)
            }
        }
    }
    return best
}
