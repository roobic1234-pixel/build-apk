package com.example.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.DaneshinoApplication
import com.example.core.PersianDateUtil
import com.example.data.local.AssignmentStatus
import com.example.data.prefs.ReminderMethod
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * BroadcastReceiver for scheduled class, assignment, and exam reminders.
 * CRITICAL GUARD: Always verifies entity existence in Room and current preference toggle BEFORE
 * firing any notification or audio alarm so deleted courses/items can NEVER produce ghost alerts.
 */
class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val entityId = intent.getLongExtra(EXTRA_ENTITY_ID, -1L)
        if (entityId <= 0L) return

        val pendingResult = goAsync()
        val app = context.applicationContext as? DaneshinoApplication
        if (app == null) {
            pendingResult.finish()
            return
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val container = app.container
                val prefs = container.preferencesRepository.getPreferencesOnce()

                when (action) {
                    ACTION_CLASS_REMINDER -> {
                        val sessionWithCourse = container.repository.getSessionWithCourse(entityId)
                        val course = sessionWithCourse?.course
                        if (!prefs.classRemindersEnabled || sessionWithCourse == null || course == null) {
                            // Entity was deleted or reminders disabled — clean up and stay completely silent
                            container.reminderController.cancelClassSessionReminder(entityId)
                            return@launch
                        }

                        val session = sessionWithCourse.session
                        val startTimeText = PersianDateUtil.formatTime(session.startMinuteOfDay)
                        val location = listOf(session.building, session.roomNumber)
                            .filter { it.isNotBlank() }
                            .joinToString(" - ")
                        val notifId = ReminderIds.classRequestCode(session.id)

                        when (prefs.classReminderMethod) {
                            ReminderMethod.NOTIFICATION -> {
                                ReminderNotificationHelper.showClassNotification(
                                    context = context,
                                    notificationId = notifId,
                                    courseName = course.name,
                                    startTimeText = startTimeText,
                                    locationText = location
                                )
                            }
                            ReminderMethod.AUDIO_ALARM -> {
                                ClassAlarmService.start(
                                    context = context,
                                    sessionId = session.id,
                                    courseName = course.name,
                                    startTimeText = startTimeText
                                )
                            }
                            ReminderMethod.BOTH -> {
                                // Strictly 1 notification + 1 audio alarm for this occurrence
                                ReminderNotificationHelper.showClassNotification(
                                    context = context,
                                    notificationId = notifId,
                                    courseName = course.name,
                                    startTimeText = startTimeText,
                                    locationText = location
                                )
                                ClassAlarmService.start(
                                    context = context,
                                    sessionId = session.id,
                                    courseName = course.name,
                                    startTimeText = startTimeText
                                )
                            }
                        }

                        // Reschedule next week's occurrence if weekly repeat is active
                        if (session.repeatWeekly) {
                            container.reminderController.scheduleClassSessionReminder(session, course, prefs)
                        }
                    }

                    ACTION_ASSIGNMENT_REMINDER -> {
                        val assignment = container.repository.getAssignmentById(entityId)
                        if (!prefs.assignmentRemindersEnabled ||
                            assignment == null ||
                            assignment.reminderMinutesBefore == null ||
                            assignment.status == AssignmentStatus.COMPLETED.name
                        ) {
                            container.reminderController.cancelAssignmentReminder(entityId)
                            return@launch
                        }

                        val dueText = "${PersianDateUtil.formatShortShamsiDate(assignment.dueAtMillis)} ساعت ${PersianDateUtil.formatTimeFromMillis(assignment.dueAtMillis)}"
                        ReminderNotificationHelper.showTaskOrExamNotification(
                            context = context,
                            notificationId = ReminderIds.assignmentRequestCode(assignment.id),
                            title = "یادآوری تکلیف: ${assignment.title}",
                            body = "مهلت تحویل: $dueText"
                        )
                    }

                    ACTION_EXAM_REMINDER -> {
                        val exam = container.repository.getExamById(entityId)
                        if (!prefs.examRemindersEnabled || exam == null || exam.reminderMinutesBefore == null) {
                            container.reminderController.cancelExamReminder(entityId)
                            return@launch
                        }

                        val examTimeText = "${PersianDateUtil.formatShortShamsiDate(exam.examAtMillis)} ساعت ${PersianDateUtil.formatTimeFromMillis(exam.examAtMillis)}"
                        val loc = if (exam.location.isNotBlank()) " • ${exam.location}" else ""
                        ReminderNotificationHelper.showTaskOrExamNotification(
                            context = context,
                            notificationId = ReminderIds.examRequestCode(exam.id),
                            title = "یادآوری امتحان: ${exam.title}",
                            body = "$examTimeText$loc"
                        )
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        const val ACTION_CLASS_REMINDER = "com.example.reminder.ACTION_CLASS_REMINDER"
        const val ACTION_ASSIGNMENT_REMINDER = "com.example.reminder.ACTION_ASSIGNMENT_REMINDER"
        const val ACTION_EXAM_REMINDER = "com.example.reminder.ACTION_EXAM_REMINDER"

        const val EXTRA_ENTITY_ID = "extra_entity_id"
        const val EXTRA_COURSE_ID = "extra_course_id"
    }
}
