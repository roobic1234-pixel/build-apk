package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.core.GpaCalculator
import com.example.core.PersianDateUtil
import com.example.core.TargetGpaResult
import com.example.data.local.CourseEntity
import com.example.ui.components.DaneshinoCard
import com.example.ui.components.DaneshinoEmptyState
import com.example.ui.components.PillBadge
import com.example.ui.components.ScreenHeader
import com.example.ui.theme.CourseColorPalette
import com.example.ui.viewmodel.DaneshinoDataState

@Composable
fun GradesScreen(
    state: DaneshinoDataState,
    onUpdateGrade: (Long, Double?) -> Unit,
    onBack: () -> Unit
) {
    val summary = state.gpaSummary
    var editingGradeCourse by remember { mutableStateOf<CourseEntity?>(null) }

    // Target GPA calculator state
    var targetGpaInput by rememberSaveable { mutableStateOf("18") }
    var upcomingCreditsInput by rememberSaveable { mutableStateOf("18") }
    var customCurrentGpaInput by rememberSaveable { mutableStateOf("") }
    var customCompletedCreditsInput by rememberSaveable { mutableStateOf("") }
    var calcResult by remember { mutableStateOf<TargetGpaResult?>(null) }

    editingGradeCourse?.let { course ->
        GradeEditDialog(
            course = course,
            onSave = { newGrade ->
                onUpdateGrade(course.id, newGrade)
                editingGradeCourse = null
            },
            onDismiss = { editingGradeCourse = null }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
    ) {
        ScreenHeader(
            title = "نمرات و معدل",
            subtitle = "مقیاس ۰ تا ۲۰ با محاسبه وزنی واحدها",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // GPA Overview Card
            item {
                DaneshinoCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "معدل کل",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = summary.overallGpa?.let { "${PersianDateUtil.formatDecimal(it, 2)} از ۲۰" } ?: "ثبت نشده",
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "گذرانده: ${PersianDateUtil.formatCredits(summary.passedCredits)} واحد",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "باقی‌مانده: ${PersianDateUtil.formatCredits(summary.remainingCredits)} واحد",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (summary.termGpas.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        HorizontalDivider()
                        Spacer(Modifier.height(10.dp))
                        Text("معدل هر ترم", style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(6.dp))
                        summary.termGpas.forEach { (term, gpa) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(term, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    text = PersianDateUtil.formatDecimal(gpa, 2),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            // Target GPA Calculator Card
            item {
                DaneshinoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Calculate, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("ماشین‌حساب نمره لازم برای معدل هدف", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = if (summary.gradedCredits > 0.0) {
                            "بر اساس معدل فعلی شما (${PersianDateUtil.formatDecimal(summary.overallGpa ?: 0.0, 2)} در ${PersianDateUtil.formatCredits(summary.gradedCredits)} واحد) یا مقادیر دلخواه زیر محاسبه می‌شود."
                        } else {
                            "اگر هنوز نمره‌ای ثبت نکرده‌اید، معدل فعلی و واحد گذرانده را وارد کنید (یا برای ترم اول صفر بگذارید)."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = customCurrentGpaInput,
                            onValueChange = { customCurrentGpaInput = it },
                            label = { Text("معدل فعلی") },
                            placeholder = {
                                Text(summary.overallGpa?.let { String.format("%.2f", it) } ?: "0")
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = customCompletedCreditsInput,
                            onValueChange = { customCompletedCreditsInput = it },
                            label = { Text("واحد گذرانده") },
                            placeholder = { Text(summary.gradedCredits.toInt().toString()) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = targetGpaInput,
                            onValueChange = { targetGpaInput = it },
                            label = { Text("معدل هدف (۰ تا ۲۰)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("target_gpa_input")
                        )
                        OutlinedTextField(
                            value = upcomingCreditsInput,
                            onValueChange = { upcomingCreditsInput = it },
                            label = { Text("واحدهای پیش‌رو") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("upcoming_credits_input")
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val currentGpa = customCurrentGpaInput.replace(",", ".").toDoubleOrNull()
                                ?: summary.overallGpa ?: 0.0
                            val completedCredits = customCompletedCreditsInput.replace(",", ".").toDoubleOrNull()
                                ?: summary.gradedCredits
                            val targetGpa = targetGpaInput.replace(",", ".").toDoubleOrNull() ?: -1.0
                            val upcoming = upcomingCreditsInput.replace(",", ".").toDoubleOrNull() ?: 0.0
                            calcResult = GpaCalculator.calculateRequiredAverage(
                                currentGpa = currentGpa,
                                completedCredits = completedCredits,
                                upcomingCredits = upcoming,
                                targetGpa = targetGpa
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("calculate_target_gpa_button")
                    ) {
                        Text("محاسبه نمره لازم")
                    }

                    calcResult?.let { res ->
                        Spacer(Modifier.height(12.dp))
                        val (bg, fg, msg) = when (res) {
                            is TargetGpaResult.Achievable -> Triple(
                                MaterialTheme.colorScheme.primaryContainer,
                                MaterialTheme.colorScheme.onPrimaryContainer,
                                res.explanation
                            )
                            is TargetGpaResult.AlreadyAchieved -> Triple(
                                MaterialTheme.colorScheme.secondaryContainer,
                                MaterialTheme.colorScheme.onSecondaryContainer,
                                res.explanation
                            )
                            is TargetGpaResult.Impossible -> Triple(
                                MaterialTheme.colorScheme.errorContainer,
                                MaterialTheme.colorScheme.onErrorContainer,
                                res.explanation
                            )
                            is TargetGpaResult.InvalidInput -> Triple(
                                MaterialTheme.colorScheme.errorContainer,
                                MaterialTheme.colorScheme.onErrorContainer,
                                res.explanation
                            )
                        }
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = bg,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = msg,
                                style = MaterialTheme.typography.bodyMedium,
                                color = fg,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }

            // Course Grades List
            item {
                Text(
                    text = "نمرات درس‌ها",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            if (state.courses.isEmpty()) {
                item {
                    DaneshinoEmptyState(
                        icon = Icons.Default.School,
                        title = "درسی برای ثبت نمره وجود ندارد",
                        subtitle = "ابتدا از بخش درس‌ها، درس‌های ترم خود را اضافه کنید و سپس نمره هر درس را اینجا ثبت نمایید."
                    )
                }
            } else {
                items(state.courses, key = { it.id }) { course ->
                    val courseColor = CourseColorPalette.safeColor(course.colorArgb)
                    DaneshinoCard(onClick = { editingGradeCourse = course }) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(courseColor)
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(course.name, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    text = "${PersianDateUtil.formatCredits(course.credits)} واحد" +
                                        if (course.term.isNotBlank()) " • ${course.term}" else "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (course.grade != null) {
                                PillBadge(
                                    text = PersianDateUtil.formatDecimal(course.grade, 2),
                                    containerColor = if (course.grade >= 10.0) {
                                        MaterialTheme.colorScheme.secondaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.errorContainer
                                    },
                                    contentColor = if (course.grade >= 10.0) {
                                        MaterialTheme.colorScheme.onSecondaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.onErrorContainer
                                    }
                                )
                            } else {
                                Text(
                                    text = "بدون نمره",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = { editingGradeCourse = course },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "ثبت یا ویرایش نمره")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GradeEditDialog(
    course: CourseEntity,
    onSave: (Double?) -> Unit,
    onDismiss: () -> Unit
) {
    var gradeText by remember { mutableStateOf(course.grade?.toString() ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("نمره درس ${course.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "نمره را در بازه ۰ تا ۲۰ وارد کنید (برای حذف نمره، کادر را خالی بگذارید).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = gradeText,
                    onValueChange = { gradeText = it; error = null },
                    label = { Text("نمره (۰ تا ۲۰)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val trimmed = gradeText.trim().replace(",", ".")
                if (trimmed.isEmpty()) {
                    onSave(null)
                    return@Button
                }
                val value = trimmed.toDoubleOrNull()
                if (value == null || value !in 0.0..20.0) {
                    error = "نمره باید عددی بین ۰ تا ۲۰ باشد."
                    return@Button
                }
                onSave(value)
            }) { Text("ذخیره") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}
