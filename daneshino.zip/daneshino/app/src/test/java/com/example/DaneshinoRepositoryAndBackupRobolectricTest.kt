package com.example

import android.content.Context
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.EmptySponsorSource
import com.example.data.backup.BackupManager
import com.example.data.backup.BackupValidationResult
import com.example.data.local.AssignmentEntity
import com.example.data.local.ClassSessionEntity
import com.example.data.local.CourseEntity
import com.example.data.local.DaneshinoDatabase
import com.example.data.local.ExamEntity
import com.example.data.prefs.ReminderMethod
import com.example.data.prefs.UserPreferences
import com.example.data.prefs.UserPreferencesRepository
import com.example.data.repository.DaneshinoRepository
import com.example.reminder.ReminderController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

private class SpyReminderController : ReminderController {
    val scheduledSessions = mutableSetOf<Long>()
    val cancelledSessions = mutableListOf<Long>()
    val scheduledAssignments = mutableSetOf<Long>()
    val cancelledAssignments = mutableListOf<Long>()
    val scheduledExams = mutableSetOf<Long>()
    val cancelledExams = mutableListOf<Long>()

    override fun scheduleClassSessionReminder(session: ClassSessionEntity, course: CourseEntity, prefs: UserPreferences) {
        scheduledSessions.add(session.id)
    }

    override fun cancelClassSessionReminder(sessionId: Long) {
        scheduledSessions.remove(sessionId)
        cancelledSessions.add(sessionId)
    }

    override fun scheduleAssignmentReminder(assignment: AssignmentEntity, courseName: String) {
        scheduledAssignments.add(assignment.id)
    }

    override fun cancelAssignmentReminder(assignmentId: Long) {
        scheduledAssignments.remove(assignmentId)
        cancelledAssignments.add(assignmentId)
    }

    override fun scheduleExamReminder(exam: ExamEntity, courseName: String) {
        scheduledExams.add(exam.id)
    }

    override fun cancelExamReminder(examId: Long) {
        scheduledExams.remove(examId)
        cancelledExams.add(examId)
    }

    override fun triggerTestAlarm() {}
    override fun sendTestNotification() {}
    override fun stopAlarmAudio() {}
    override fun stopAlarmIfSessionMatches(sessionId: Long) {}
    override fun canScheduleExactAlarms(): Boolean = true
    override fun isDeviceSilencedOrDnd(): Boolean = false
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DaneshinoRepositoryAndBackupRobolectricTest {

    private lateinit var db: DaneshinoDatabase
    private lateinit var spyReminder: SpyReminderController
    private lateinit var repository: DaneshinoRepository
    private lateinit var prefsRepo: UserPreferencesRepository
    private lateinit var backupManager: BackupManager
    private lateinit var dsScope: CoroutineScope
    private lateinit var tempFile: File

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, DaneshinoDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        spyReminder = SpyReminderController()
        repository = DaneshinoRepository(db.daneshinoDao(), spyReminder)

        dsScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        tempFile = File.createTempFile("daneshino_test_prefs", ".preferences_pb", context.cacheDir)
        val ds = PreferenceDataStoreFactory.create(scope = dsScope) { tempFile }
        prefsRepo = UserPreferencesRepository(ds)
        backupManager = BackupManager(repository, prefsRepo)
    }

    @After
    fun tearDown() {
        db.close()
        dsScope.cancel()
        tempFile.delete()
    }

    @Test
    fun `fresh install contains zero sample data and zero sponsors`() = runTest {
        assertTrue(repository.getAllCoursesOnce().isEmpty())
        assertTrue(repository.getAllSessionsOnce().isEmpty())
        assertTrue(repository.getAllAssignmentsOnce().isEmpty())
        assertTrue(repository.getAllExamsOnce().isEmpty())
        assertTrue(repository.getAllStudySessionsOnce().isEmpty())
        assertTrue(repository.getAllGoalsOnce().isEmpty())
        assertTrue(repository.getAllDecksOnce().isEmpty())
        assertTrue(repository.getAllNotesOnce().isEmpty())
        assertTrue(EmptySponsorSource().getSponsors().isEmpty())
    }

    @Test
    fun `deleting course 1 cancels only course 1 reminders and survives simulated reboot without returning`() = runTest {
        val prefs = UserPreferences(
            classRemindersEnabled = true,
            classReminderMinutesBefore = 15,
            classReminderMethod = ReminderMethod.BOTH
        )

        val course1Id = repository.saveCourseWithSessions(
            CourseEntity(name = "ساختمان داده", credits = 3.0),
            listOf(ClassSessionEntity(courseId = 0, dayOfWeek = 0, startMinuteOfDay = 600, endMinuteOfDay = 690)),
            prefs
        )
        val course2Id = repository.saveCourseWithSessions(
            CourseEntity(name = "سیستم‌عامل", credits = 3.0),
            listOf(ClassSessionEntity(courseId = 0, dayOfWeek = 2, startMinuteOfDay = 720, endMinuteOfDay = 810)),
            prefs
        )

        val s1 = repository.getAllSessionsOnce().first { it.courseId == course1Id }
        val s2 = repository.getAllSessionsOnce().first { it.courseId == course2Id }

        val a1Id = repository.saveAssignment(
            AssignmentEntity(courseId = course1Id, title = "تمرین ۱", dueAtMillis = System.currentTimeMillis() + 86_400_000L, reminderMinutesBefore = 60),
            prefs
        )

        assertTrue(s1.id in spyReminder.scheduledSessions)
        assertTrue(s2.id in spyReminder.scheduledSessions)
        assertTrue(a1Id in spyReminder.scheduledAssignments)

        // Delete Course 1
        repository.deleteCourse(course1Id)

        // Course 1 session & assignment reminders MUST be cancelled; Course 2 MUST remain scheduled
        assertTrue(s1.id in spyReminder.cancelledSessions)
        assertTrue(a1Id in spyReminder.cancelledAssignments)
        assertFalse(s2.id in spyReminder.cancelledSessions)
        assertTrue(s2.id in spyReminder.scheduledSessions)

        // Simulate device reboot (rescheduleAllReminders from DB)
        spyReminder.scheduledSessions.clear()
        repository.rescheduleAllReminders(prefs)

        // Only Course 2's session is rescheduled; Course 1 NEVER returns
        assertFalse(s1.id in spyReminder.scheduledSessions)
        assertTrue(s2.id in spyReminder.scheduledSessions)
        assertEquals(null, repository.getSessionWithCourse(s1.id))
    }

    @Test
    fun `JSON backup export, validation, and atomic restore work accurately`() = runTest {
        val prefs = UserPreferences(
            studentName = "سارا",
            university = "دانشگاه تهران",
            classRemindersEnabled = true,
            classReminderMinutesBefore = 30,
            classReminderMethod = ReminderMethod.AUDIO_ALARM
        )
        prefsRepo.restorePreferences(prefs)

        val cid = repository.saveCourseWithSessions(
            CourseEntity(name = "هوش مصنوعی", credits = 3.0, grade = 19.25),
            listOf(ClassSessionEntity(courseId = 0, dayOfWeek = 1, startMinuteOfDay = 540, endMinuteOfDay = 630)),
            prefs
        )
        repository.saveAssignment(
            AssignmentEntity(courseId = cid, title = "پروژه جستجو", dueAtMillis = System.currentTimeMillis() + 172_800_000L, reminderMinutesBefore = 60),
            prefs
        )

        val json = backupManager.exportToJson()
        val validation = backupManager.validateJson(json)
        assertTrue(validation is BackupValidationResult.Valid)

        // Reject invalid / corrupted backup
        assertTrue(backupManager.validateJson("{invalid json}") is BackupValidationResult.Invalid)
        assertTrue(backupManager.validateJson("""{"appName":"OtherApp","schemaVersion":1}""") is BackupValidationResult.Invalid)

        // Wipe database then restore from backup
        repository.deleteCourse(cid)
        assertTrue(repository.getAllCoursesOnce().isEmpty())

        val validPayload = (validation as BackupValidationResult.Valid).payload
        backupManager.restoreFromValidatedPayload(validPayload)

        val restoredCourses = repository.getAllCoursesOnce()
        assertEquals(1, restoredCourses.size)
        assertEquals("هوش مصنوعی", restoredCourses.first().name)
        assertEquals(19.25, restoredCourses.first().grade ?: 0.0, 0.001)
        assertEquals(1, repository.getAllAssignmentsOnce().size)
        assertEquals("سارا", prefsRepo.preferencesFlow.first().studentName)
        assertEquals(30, prefsRepo.preferencesFlow.first().classReminderMinutesBefore)
    }
}
