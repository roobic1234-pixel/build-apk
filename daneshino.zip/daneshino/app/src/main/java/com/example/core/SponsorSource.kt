package com.example.core

/**
 * Developer-only sponsor extension seam.
 * In this release, Daneshino contains zero ads, zero sponsors, zero sponsor UI, and zero network calls.
 * Future sponsors can only be added or removed by the developer in source code in a new official release.
 */
data class SponsorItem(
    val id: String,
    val title: String,
    val description: String
)

interface SponsorSource {
    fun getSponsors(): List<SponsorItem>
}

class EmptySponsorSource : SponsorSource {
    override fun getSponsors(): List<SponsorItem> = emptyList()
}
