package com.example

import android.app.Application
import android.content.Context
import com.example.core.EmptySponsorSource
import com.example.core.SponsorSource
import com.example.data.backup.BackupManager
import com.example.data.local.DaneshinoDatabase
import com.example.data.prefs.UserPreferencesRepository
import com.example.data.repository.DaneshinoRepository
import com.example.reminder.AndroidReminderScheduler
import com.example.reminder.ReminderController
import com.example.reminder.ReminderNotificationHelper

class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val database: DaneshinoDatabase = DaneshinoDatabase.getInstance(appContext)
    val preferencesRepository: UserPreferencesRepository = UserPreferencesRepository(appContext)
    val reminderController: ReminderController = AndroidReminderScheduler(appContext)
    val repository: DaneshinoRepository = DaneshinoRepository(
        dao = database.daneshinoDao(),
        reminderController = reminderController
    )
    val backupManager: BackupManager = BackupManager(
        repository = repository,
        preferencesRepository = preferencesRepository
    )
    val sponsorSource: SponsorSource = EmptySponsorSource()
}

class DaneshinoApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        ReminderNotificationHelper.ensureChannels(this)
    }
}
