package com.example

import com.example.data.prefs.ReminderLeadTime
import com.example.reminder.ReminderIds
import com.example.reminder.ReminderTriggerCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

class ReminderLogicTest {

    @Test
    fun `allowed lead times match specification exactly`() {
        assertEquals(listOf(60, 30, 25, 20, 15, 10), ReminderLeadTime.allowedMinutes)
        assertEquals(15, ReminderLeadTime.DEFAULT_MINUTES)
        assertEquals(15, ReminderLeadTime.sanitize(99))
    }

    @Test
    fun `trigger calculator never schedules past timestamps immediately and wraps weekly`() {
        val tz = TimeZone.getTimeZone("Asia/Tehran")
        // Saturday 2026-11-21 at 10:00 local time
        val now = Calendar.getInstance(tz).apply {
            set(2026, Calendar.NOVEMBER, 21, 10, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        // Class on Saturday (persian index 0) at 10:10 with 15 min lead -> trigger would be 09:55 (past!)
        val nextWeekly = ReminderTriggerCalculator.nextClassTriggerMillis(
            dayOfWeekPersian = 0,
            startMinuteOfDay = 10 * 60 + 10,
            leadMinutesBefore = 15,
            repeatWeekly = true,
            nowMillis = now,
            timeZone = tz
        )
        assertNotNull(nextWeekly)
        assertTrue("Trigger must strictly be in the future", nextWeekly!! > now)
        // Should be next week's Saturday at 09:55 (~7 days - 5 min later)
        val expectedDiff = 7L * 86_400_000L - 5L * 60_000L
        assertEquals(expectedDiff, nextWeekly - now)

        // Non-repeating past class returns null instead of firing immediately
        val nonRepeatingPast = ReminderTriggerCalculator.nextClassTriggerMillis(
            dayOfWeekPersian = 0,
            startMinuteOfDay = 10 * 60 + 10,
            leadMinutesBefore = 15,
            repeatWeekly = false,
            nowMillis = now,
            timeZone = tz
        )
        assertNull(nonRepeatingPast)
    }

    @Test
    fun `reminder request codes are unique across entity types and IDs`() {
        val c1 = ReminderIds.classRequestCode(1L)
        val c2 = ReminderIds.classRequestCode(2L)
        val a1 = ReminderIds.assignmentRequestCode(1L)
        val e1 = ReminderIds.examRequestCode(1L)
        assertNotEquals(c1, c2)
        assertNotEquals(c1, a1)
        assertNotEquals(c1, e1)
        assertNotEquals(a1, e1)
    }
}
