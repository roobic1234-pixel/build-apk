package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.PersianDateUtil
import com.example.ui.components.DaneshinoCard
import com.example.ui.components.DaneshinoEmptyState
import com.example.ui.components.ScreenHeader
import com.example.ui.viewmodel.DaneshinoDataState

private data class SearchResultGroup(
    val categoryTitle: String,
    val items: List<Pair<String, String>>
)

@Composable
fun GlobalSearchScreen(
    state: DaneshinoDataState,
    onBack: () -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }

    val groups = remember(query, state) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return@remember emptyList()

        val result = mutableListOf<SearchResultGroup>()

        // 1. Courses
        val matchedCourses = state.courses.filter {
            it.name.lowercase().contains(q) || it.code.lowercase().contains(q) || it.description.lowercase().contains(q)
        }
        if (matchedCourses.isNotEmpty()) {
            result.add(
                SearchResultGroup(
                    "درس‌ها",
                    matchedCourses.map { it.name to "${PersianDateUtil.formatCredits(it.credits)} واحد • ${it.courseType}" }
                )
            )
        }

        // 2. Instructors
        val matchedInstructors = state.courses.filter {
            it.instructorName.lowercase().contains(q) || it.instructorEmail.lowercase().contains(q) || it.instructorOffice.lowercase().contains(q)
        }.filter { it.instructorName.isNotBlank() }
        if (matchedInstructors.isNotEmpty()) {
            result.add(
                SearchResultGroup(
                    "استادها",
                    matchedInstructors.map { it.instructorName to "درس: ${it.name}" }
                )
            )
        }

        // 3. Assignments
        val matchedAssignments = state.assignments.filter {
            it.title.lowercase().contains(q) || it.description.lowercase().contains(q)
        }
        if (matchedAssignments.isNotEmpty()) {
            result.add(
                SearchResultGroup(
                    "تکالیف",
                    matchedAssignments.map { it.title to "مهلت: ${PersianDateUtil.formatShortShamsiDate(it.dueAtMillis)}" }
                )
            )
        }

        // 4. Exams
        val matchedExams = state.exams.filter {
            it.title.lowercase().contains(q) || it.syllabus.lowercase().contains(q) || it.location.lowercase().contains(q)
        }
        if (matchedExams.isNotEmpty()) {
            result.add(
                SearchResultGroup(
                    "امتحانات",
                    matchedExams.map { it.title to PersianDateUtil.formatShortShamsiDate(it.examAtMillis) }
                )
            )
        }

        // 5. Notes
        val matchedNotes = state.notes.filter {
            it.title.lowercase().contains(q) || it.content.lowercase().contains(q) || it.category.lowercase().contains(q)
        }
        if (matchedNotes.isNotEmpty()) {
            result.add(
                SearchResultGroup(
                    "یادداشت‌ها",
                    matchedNotes.map { it.title to it.content.take(80) }
                )
            )
        }

        // 6. Files / Attachments
        val matchedFiles = state.attachments.filter {
            it.displayName.lowercase().contains(q)
        }
        if (matchedFiles.isNotEmpty()) {
            result.add(
                SearchResultGroup(
                    "فایل‌های درسی",
                    matchedFiles.map { it.displayName to (state.courseById(it.courseId)?.name ?: "") }
                )
            )
        }

        // 7. Goals
        val matchedGoals = state.goals.filter { it.title.lowercase().contains(q) }
        if (matchedGoals.isNotEmpty()) {
            result.add(
                SearchResultGroup(
                    "اهداف",
                    matchedGoals.map { it.title to "هدف: ${PersianDateUtil.formatDurationMinutes(it.targetMinutes)}" }
                )
            )
        }

        // 8. Flashcards & Decks
        val matchedDecks = state.decks.filter { it.title.lowercase().contains(q) || it.description.lowercase().contains(q) }
            .map { it.title to "دسته فلش‌کارت" }
        val matchedCards = state.flashcards.filter { it.front.lowercase().contains(q) || it.back.lowercase().contains(q) }
            .map { it.front to it.back.take(70) }
        val allFlash = matchedDecks + matchedCards
        if (allFlash.isNotEmpty()) {
            result.add(SearchResultGroup("فلش‌کارت‌ها", allFlash))
        }

        result
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
    ) {
        ScreenHeader(
            title = "جستجوی سراسری",
            subtitle = "در همه بخش‌های دانشینو",
            onBack = onBack
        )

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text(stringResource(R.string.search_placeholder)) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "جستجو") },
            singleLine = true,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("global_search_input")
        )

        Spacer(Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when {
                query.isBlank() -> {
                    item {
                        DaneshinoEmptyState(
                            icon = Icons.Default.Search,
                            title = "جستجو در دانشینو",
                            subtitle = stringResource(R.string.search_empty_prompt)
                        )
                    }
                }
                groups.isEmpty() -> {
                    item {
                        DaneshinoEmptyState(
                            icon = Icons.Default.Search,
                            title = "نتیجه‌ای یافت نشد",
                            subtitle = stringResource(R.string.search_no_results)
                        )
                    }
                }
                else -> {
                    groups.forEach { group ->
                        item(key = "header_${group.categoryTitle}") {
                            Text(
                                text = "${group.categoryTitle} (${PersianDateUtil.formatInt(group.items.size)})",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        items(group.items) { (title, subtitle) ->
                            DaneshinoCard {
                                Text(title, style = MaterialTheme.typography.titleSmall)
                                if (subtitle.isNotBlank()) {
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
