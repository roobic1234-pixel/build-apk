package com.example.reminder

import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Foreground service (mediaPlayback) that plays class reminder audio alert.
 * - Strictly respects AudioFocus, current device volume, Silent mode, and Do Not Disturb.
 * - Never bypasses Silent/DND or forces system volume up.
 * - Automatically stops after 45 seconds and exposes instant stop action + session-specific stop.
 */
class ClassAlarmService : Service() {

    private var mediaPlayer: MediaPlayer? = null
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null
    private var currentSessionId: Long = -1L
    private val mainHandler = Handler(Looper.getMainLooper())
    private val autoStopRunnable = Runnable { stopSelfSafely() }

    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            stopSelfSafely()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALARM -> {
                stopSelfSafely()
                return START_NOT_STICKY
            }
            ACTION_STOP_IF_MATCHING -> {
                val targetId = intent.getLongExtra(EXTRA_SESSION_ID, -1L)
                if (targetId > 0L && targetId == currentSessionId) {
                    stopSelfSafely()
                }
                return START_NOT_STICKY
            }
        }

        val sessionId = intent?.getLongExtra(EXTRA_SESSION_ID, -1L) ?: -1L
        val courseName = intent?.getStringExtra(EXTRA_COURSE_NAME).orEmpty().ifBlank { "کلاس درسی" }
        val startTimeText = intent?.getStringExtra(EXTRA_START_TIME).orEmpty().ifBlank { "به‌زودی" }

        ReminderNotificationHelper.ensureChannels(this)
        startForeground(
            ReminderIds.ALARM_SERVICE_NOTIFICATION_ID,
            buildForegroundNotification(courseName, startTimeText)
        )

        currentSessionId = sessionId
        startAlarmPlayback()

        return START_NOT_STICKY
    }

    private fun buildForegroundNotification(courseName: String, startTimeText: String) =
        NotificationCompat.Builder(this, ReminderIds.CHANNEL_ALARM)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.reminder_alarm_active_title, courseName))
            .setContentText(getString(R.string.reminder_alarm_active_body, startTimeText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(
                PendingIntent.getActivity(
                    this,
                    ReminderIds.ALARM_SERVICE_NOTIFICATION_ID,
                    Intent(this, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .addAction(
                android.R.drawable.ic_media_pause,
                getString(R.string.reminder_stop_audio),
                PendingIntent.getService(
                    this,
                    ReminderIds.ALARM_SERVICE_NOTIFICATION_ID + 1,
                    Intent(this, ClassAlarmService::class.java).apply { action = ACTION_STOP_ALARM },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()

    private fun startAlarmPlayback() {
        releaseMediaResources()

        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager = am

        // Strictly respect device Silent mode and Do Not Disturb — never bypass them.
        if (isSilencedOrDnd(this)) {
            _isAlarmPlaying.value = false
            stopSelfSafely()
            return
        }

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val granted = requestFocus(am, audioAttributes)
        if (!granted) {
            stopSelfSafely()
            return
        }

        val alertUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)

        if (alertUri == null) {
            stopSelfSafely()
            return
        }

        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(audioAttributes)
                setDataSource(this@ClassAlarmService, alertUri)
                isLooping = true
                prepare()
                start()
            }
            mediaPlayer = player
            _isAlarmPlaying.value = true

            mainHandler.removeCallbacks(autoStopRunnable)
            mainHandler.postDelayed(autoStopRunnable, AUTO_STOP_DURATION_MS)
        } catch (_: Exception) {
            stopSelfSafely()
        }
    }

    private fun requestFocus(am: AudioManager, attrs: AudioAttributes): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(focusChangeListener)
                .build()
            focusRequest = req
            am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                focusChangeListener,
                AudioManager.STREAM_ALARM,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
            ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
    }

    private fun releaseMediaResources() {
        mainHandler.removeCallbacks(autoStopRunnable)
        try {
            mediaPlayer?.let {
                if (it.isPlaying) it.stop()
                it.reset()
                it.release()
            }
        } catch (_: Exception) {
            // Safe cleanup
        } finally {
            mediaPlayer = null
        }

        audioManager?.let { am ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                focusRequest?.let { am.abandonAudioFocusRequest(it) }
                focusRequest = null
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(focusChangeListener)
            }
        }
        _isAlarmPlaying.value = false
    }

    private fun stopSelfSafely() {
        releaseMediaResources()
        currentSessionId = -1L
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        releaseMediaResources()
        currentSessionId = -1L
        super.onDestroy()
    }

    companion object {
        const val ACTION_START_ALARM = "com.example.reminder.ACTION_START_ALARM"
        const val ACTION_STOP_ALARM = "com.example.reminder.ACTION_STOP_ALARM"
        const val ACTION_STOP_IF_MATCHING = "com.example.reminder.ACTION_STOP_IF_MATCHING"

        const val EXTRA_SESSION_ID = "extra_session_id"
        const val EXTRA_COURSE_NAME = "extra_course_name"
        const val EXTRA_START_TIME = "extra_start_time"

        private const val AUTO_STOP_DURATION_MS = 45_000L

        private val _isAlarmPlaying = MutableStateFlow(false)
        val isAlarmPlaying: StateFlow<Boolean> = _isAlarmPlaying.asStateFlow()

        fun isSilencedOrDnd(context: Context): Boolean {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (am.ringerMode == AudioManager.RINGER_MODE_SILENT) return true
            if (am.getStreamVolume(AudioManager.STREAM_ALARM) == 0) return true
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val filter = nm.currentInterruptionFilter
            return filter == NotificationManager.INTERRUPTION_FILTER_NONE
        }

        fun start(context: Context, sessionId: Long, courseName: String, startTimeText: String) {
            val intent = Intent(context, ClassAlarmService::class.java).apply {
                action = ACTION_START_ALARM
                putExtra(EXTRA_SESSION_ID, sessionId)
                putExtra(EXTRA_COURSE_NAME, courseName)
                putExtra(EXTRA_START_TIME, startTimeText)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            if (!_isAlarmPlaying.value) {
                // Still attempt stopService safely in case foreground notification is lingering
                context.stopService(Intent(context, ClassAlarmService::class.java))
                return
            }
            val intent = Intent(context, ClassAlarmService::class.java).apply {
                action = ACTION_STOP_ALARM
            }
            context.startService(intent)
        }

        fun stopIfSessionMatches(context: Context, sessionId: Long) {
            if (!_isAlarmPlaying.value) return
            val intent = Intent(context, ClassAlarmService::class.java).apply {
                action = ACTION_STOP_IF_MATCHING
                putExtra(EXTRA_SESSION_ID, sessionId)
            }
            context.startService(intent)
        }
    }
}
