package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.NoteAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.core.PersianDateUtil
import com.example.data.local.CourseEntity
import com.example.data.local.NoteEntity
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.DaneshinoCard
import com.example.ui.components.DaneshinoEmptyState
import com.example.ui.components.PillBadge
import com.example.ui.components.ScreenHeader
import com.example.ui.viewmodel.DaneshinoDataState

private val noteCategories = listOf("عمومی", "جزوه", "خلاصه", "فرمول", "تمرین")

@Composable
fun NotesScreen(
    state: DaneshinoDataState,
    onSaveNote: (NoteEntity) -> Unit,
    onDeleteNote: (Long) -> Unit,
    onBack: () -> Unit
) {
    var search by rememberSaveable { mutableStateOf("") }
    var selectedCategory by rememberSaveable { mutableStateOf("همه") }
    var showEditor by remember { mutableStateOf(false) }
    var editingNote by remember { mutableStateOf<NoteEntity?>(null) }
    var deletingNote by remember { mutableStateOf<NoteEntity?>(null) }

    if (showEditor || editingNote != null) {
        NoteEditorDialog(
            existing = editingNote,
            courses = state.courses,
            onSave = {
                onSaveNote(it)
                showEditor = false
                editingNote = null
            },
            onDismiss = {
                showEditor = false
                editingNote = null
            }
        )
    }

    deletingNote?.let { target ->
        ConfirmDeleteDialog(
            title = "حذف یادداشت",
            body = "آیا از حذف یادداشت «${target.title}» مطمئن هستید؟",
            onConfirm = {
                onDeleteNote(target.id)
                deletingNote = null
            },
            onDismiss = { deletingNote = null }
        )
    }

    val filtered = remember(state.notes, search, selectedCategory) {
        val q = search.trim().lowercase()
        state.notes.filter { note ->
            val catOk = selectedCategory == "همه" || note.category == selectedCategory
            val qOk = q.isEmpty() || note.title.lowercase().contains(q) || note.content.lowercase().contains(q)
            catOk && qOk
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
    ) {
        ScreenHeader(
            title = "یادداشت‌ها",
            subtitle = "جزوه، خلاصه و نکات درسی",
            onBack = onBack,
            actions = {
                IconButton(
                    onClick = { showEditor = true },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Default.Add, contentDescription = "ثبت یادداشت جدید")
                }
            }
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (state.notes.isEmpty()) {
                item {
                    DaneshinoEmptyState(
                        icon = Icons.Default.NoteAlt,
                        title = "هنوز یادداشتی ثبت نکرده‌اید",
                        subtitle = "نکات مهم کلاس‌ها، خلاصه فصل‌ها و فرمول‌ها را اینجا یادداشت و دسته‌بندی کنید.",
                        actionLabel = "ثبت اولین یادداشت",
                        onAction = { showEditor = true }
                    )
                }
            } else {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = search,
                            onValueChange = { search = it },
                            placeholder = { Text("جستجو در یادداشت‌ها...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "جستجو") },
                            singleLine = true,
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier.fillMaxWidth()
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(listOf("همه") + noteCategories) { cat ->
                                FilterChip(
                                    selected = selectedCategory == cat,
                                    onClick = { selectedCategory = cat },
                                    label = { Text(cat) }
                                )
                            }
                        }
                    }
                }

                items(filtered, key = { it.id }) { note ->
                    val course = state.courseById(note.courseId)
                    DaneshinoCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(note.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            PillBadge(
                                text = note.category,
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                        if (course != null) {
                            Spacer(Modifier.height(4.dp))
                            Text(course.name, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = note.content,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = PersianDateUtil.formatShortShamsiDate(note.updatedAtMillis),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row {
                                IconButton(
                                    onClick = { editingNote = note },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "ویرایش یادداشت", tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(
                                    onClick = { deletingNote = note },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف یادداشت", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NoteEditorDialog(
    existing: NoteEntity?,
    courses: List<CourseEntity>,
    onSave: (NoteEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var content by remember { mutableStateOf(existing?.content ?: "") }
    var category by remember { mutableStateOf(existing?.category ?: "عمومی") }
    var courseId by remember { mutableStateOf(existing?.courseId) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "یادداشت جدید" else "ویرایش یادداشت") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; error = null },
                    label = { Text("عنوان یادداشت *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it; error = null },
                    label = { Text("متن یادداشت *") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("دسته‌بندی", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    noteCategories.forEach { cat ->
                        FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat) })
                    }
                }
                if (courses.isNotEmpty()) {
                    Text("اتصال به درس", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = courseId == null, onClick = { courseId = null }, label = { Text("بدون درس") })
                        courses.forEach { c ->
                            FilterChip(selected = courseId == c.id, onClick = { courseId = c.id }, label = { Text(c.name) })
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (title.trim().isBlank() || content.trim().isBlank()) {
                    error = "لطفاً عنوان و متن یادداشت را وارد کنید."
                    return@Button
                }
                onSave(
                    NoteEntity(
                        id = existing?.id ?: 0L,
                        courseId = courseId,
                        title = title.trim(),
                        content = content.trim(),
                        category = category,
                        updatedAtMillis = System.currentTimeMillis()
                    )
                )
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
