# راهنمای ساخت نسخه Release اپلیکیشن دانشینو (Daneshino)

این راهنما به‌صورت مرحله‌به‌مرحله نحوه باز کردن پروژه در Android Studio، ساخت خروجی APK نسخه **Release** امضاشده با کلید اختصاصی پروژه (`daneshino-release.jks`) و بررسی صحت امضا را توضیح می‌دهد.

---

## ۱. پیش‌نیازها

- نصب **Android Studio** (نسخه Ladybug یا جدیدتر با JDK 17+)
- نصب Android SDK نسخه **36**
- فایل‌های کلید امضا که هم‌اکنون داخل ریشه پروژه قرار دارند:
  - `daneshino-release.jks` (فایل Keystore اصلی — الگوریتم RSA 2048 بیت، اعتبار تا سال ۲۰۵۴)
  - `keystore.properties` (شامل مسیر، alias و رمزهای تصادفی ساخته‌شده)

> **هشدار امنیتی بسیار مهم:**  
> فایل‌های `daneshino-release.jks` و `keystore.properties` در `.gitignore` قرار گرفته‌اند تا وارد Git نشوند. هرگز این پروژه را همراه با این دو فایل در مخازن عمومی (مانند GitHub Public) منتشر نکنید و از این دو فایل یک نسخه پشتیبان امن نگهداری کنید. برای تمام آپدیت‌های آینده دانشینو باید **دقیقاً از همین کلید** استفاده کنید.

---

## ۲. باز کردن پروژه در Android Studio

1. فایل ZIP پروژه را در یک پوشه با مسیر انگلیسی (مثلاً `C:\Projects\Daneshino`) استخراج کنید.
2. Android Studio را باز کنید و گزینه **Open** را بزنید.
3. پوشه پروژه (`Daneshino`) را انتخاب کرده و منتظر بمانید تا **Gradle Sync** کامل شود.

---

## ۳. ساخت APK نسخه Release

### روش اول (ساده‌ترین روش — از داخل Android Studio)

1. از منوی بالا مسیر زیر را باز کنید:  
   **Build ← Generate Signed App Bundle / APK...**
2. گزینه **APK** را انتخاب کرده و **Next** را بزنید.
3. فایل `keystore.properties` داخل ریشه پروژه را باز کنید و مقادیر آن را در کادرها وارد کنید:
   - **Key store path:** فایل `daneshino-release.jks` در ریشه پروژه
   - **Key store password:** مقدار `storePassword` از فایل `keystore.properties`
   - **Key alias:** `daneshino`
   - **Key password:** مقدار `keyPassword` از فایل `keystore.properties`
4. روی **Next** بزنید، گزینه **release** را انتخاب کنید و **Create** را بزنید.

### روش دوم (از طریق ترمینال با `gradlew assembleRelease`)

در پروژه AI Studio، تنظیمات پیش‌فرض `signingConfigs.release` در `app/build.gradle.kts` برای سازگاری با سیستم ساخت خودکار پلتفرم حفظ شده است. برای ساخت Release خودکار در کامپیوتر شخصی خود با خواندن از `keystore.properties`:

1. می‌توانید در نسخه محلی کامپیوتر خود، بلوک `release` در `app/build.gradle.kts` را به شکل زیر متصل به `keystore.properties` کنید (تا اگر فایل پیدا نشد Build شکست بخورد و به Debug برنگردد):

```kotlin
val keystorePropsFile = rootProject.file("keystore.properties")
val keystoreProps = java.util.Properties()
if (keystorePropsFile.exists()) {
    keystorePropsFile.inputStream().use { keystoreProps.load(it) }
}

signingConfigs {
    create("release") {
        if (!keystorePropsFile.exists()) {
            throw GradleException("فایل keystore.properties پیدا نشد! ساخت Release بدون کلید رسمی مجاز نیست.")
        }
        val jksFile = rootProject.file(keystoreProps.getProperty("storeFile"))
        if (!jksFile.exists()) {
            throw GradleException("فایل Keystore (${jksFile.name}) پیدا نشد!")
        }
        storeFile = jksFile
        storePassword = keystoreProps.getProperty("storePassword")
        keyAlias = keystoreProps.getProperty("keyAlias")
        keyPassword = keystoreProps.getProperty("keyPassword")
    }
}
```

2. سپس در ترمینال Android Studio اجرا کنید:
   - ویندوز:
     ```bat
     gradlew.bat assembleRelease
     ```
   - لینوکس / مک:
     ```bash
     ./gradlew assembleRelease
     ```

---

## ۴. مسیر فایل APK خروجی

پس از پایان موفق Build، فایل APK نسخه Release در مسیر زیر ساخته می‌شود:

```text
app/build/outputs/apk/release/app-release.apk
```

(در روش Generate Signed APK نیز مسیر دقیق در پوشه `app/release/app-release.apk` خواهد بود.)

---

## ۵. بررسی امضای APK و اطمینان از Debug نبودن آن

برای بررسی گواهی امضای فایل APK، از ابزار `apksigner` موجود در Android SDK (`build-tools`) استفاده کنید:

```bash
apksigner verify --print-certs app/build/outputs/apk/release/app-release.apk
```

و برای بررسی مستقیم خود Keystore:

```bash
keytool -list -v -keystore daneshino-release.jks -alias daneshino
```

### مقادیر مورد انتظار:
- **Owner / Signer DN:** `CN=Daneshino, OU=Mobile, O=Daneshino, L=Tehran, ST=Tehran, C=IR`  
  *(اگر `CN=Android Debug` دیدید، یعنی فایل با کلید Debug ساخته شده و نباید منتشر شود.)*
- **SHA-256 گواهی امضای رسمی این پروژه:**
  ```text
  E1:7E:67:6E:7C:36:71:9C:40:6B:64:FF:F9:5D:55:35:72:CA:DE:15:B6:46:38:B8:E7:40:F8:3C:3A:62:E1:7A
  ```

---

## ۶. خطاهای رایج و راه‌حل آن‌ها

| خطا | علت | راه‌حل |
|---|---|---|
| `Keystore file not found` | فایل `daneshino-release.jks` در ریشه پروژه نیست یا مسیر اشتباه است | مطمئن شوید `daneshino-release.jks` و `keystore.properties` در ریشه پروژه (کنار `settings.gradle.kts`) قرار دارند. |
| `Keystore was tampered with, or password was incorrect` | رمز واردشده با `keystore.properties` مطابقت ندارد | مقدار دقیق `storePassword` و `keyPassword` را بدون فاصله اضافی از `keystore.properties` کپی کنید. |
| `SDK location not found` | مسیر Android SDK تنظیم نشده است | در Android Studio از **File ← Project Structure ← SDK Location** مسیر SDK را مشخص کنید. |
| `Java version mismatch` | نسخه JDK قدیمی است | در **Settings ← Build Tools ← Gradle** گزینه Gradle JDK را روی **JDK 17** یا **JDK 21** بگذارید. |
| `INSTALL_FAILED_UPDATE_INCOMPATIBLE` روی گوشی | نسخه قدیمی با کلید متفاوت روی گوشی نصب است | ابتدا نسخه قبلی دانشینو را از گوشی حذف (Uninstall) کرده و سپس این نسخه Release را نصب کنید. |
