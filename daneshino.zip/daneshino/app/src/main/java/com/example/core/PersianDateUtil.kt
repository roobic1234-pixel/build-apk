package com.example.core

import android.icu.util.Calendar as IcuCalendar
import android.icu.util.ULocale
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.ceil

data class ShamsiDate(
    val year: Int,
    val month: Int, // 1..12 (Farvardin = 1)
    val day: Int,   // 1..31
    val dayOfWeekIndex: Int // 0 = Saturday .. 6 = Friday
)

/**
 * Reliable Jalali (Shamsi) calendar utility backed by Android ICU PersianCalendar (API 24+).
 * Never implements custom error-prone leap year or Gregorian conversion math from scratch.
 */
object PersianDateUtil {

    private val persianLocale = ULocale("fa_IR@calendar=persian")

    val persianMonthNames = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    val weekDayNames = listOf(
        "شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنج‌شنبه", "جمعه"
    )

    val weekDayShortNames = listOf(
        "ش", "ی", "د", "س", "چ", "پ", "ج"
    )

    private const val LRM = "\u200E"

    fun toPersianDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            if (ch in '0'..'9') {
                sb.append(('۰'.code + (ch - '0')).toChar())
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    /** Wraps numeric/time tokens in Left-to-Right Mark so HH:mm or decimals never reverse in RTL. */
    fun formatLtrPersian(input: String): String = "$LRM${toPersianDigits(input)}$LRM"

    fun formatInt(value: Int): String = formatLtrPersian(value.toString())

    fun formatDecimal(value: Double, decimals: Int = 2): String {
        val formatted = String.format(Locale.US, "%.${decimals}f", value)
        return formatLtrPersian(formatted)
    }

    fun formatCredits(credits: Double): String {
        return if (credits % 1.0 == 0.0) {
            formatInt(credits.toInt())
        } else {
            formatDecimal(credits, 1)
        }
    }

    fun formatTime(minuteOfDay: Int): String {
        val clamped = minuteOfDay.coerceIn(0, 1439)
        val hour = clamped / 60
        val minute = clamped % 60
        val raw = String.format(Locale.US, "%02d:%02d", hour, minute)
        return formatLtrPersian(raw)
    }

    fun formatTimeRange(startMinute: Int, endMinute: Int): String {
        return "${formatTime(startMinute)} تا ${formatTime(endMinute)}"
    }

    fun formatTimeFromMillis(epochMillis: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = epochMillis }
        val raw = String.format(
            Locale.US,
            "%02d:%02d",
            cal.get(Calendar.HOUR_OF_DAY),
            cal.get(Calendar.MINUTE)
        )
        return formatLtrPersian(raw)
    }

    fun formatDurationMinutes(totalMinutes: Int): String {
        if (totalMinutes <= 0) return "۰ دقیقه"
        val hours = totalMinutes / 60
        val minutes = totalMinutes % 60
        return when {
            hours > 0 && minutes > 0 -> "${formatInt(hours)} ساعت و ${formatInt(minutes)} دقیقه"
            hours > 0 -> "${formatInt(hours)} ساعت"
            else -> "${formatInt(minutes)} دقیقه"
        }
    }

    fun formatTimerClock(totalSeconds: Long): String {
        val safe = totalSeconds.coerceAtLeast(0L)
        val hours = safe / 3600
        val minutes = (safe % 3600) / 60
        val seconds = safe % 60
        val raw = if (hours > 0) {
            String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
        return formatLtrPersian(raw)
    }

    /** Converts java.util.Calendar.DAY_OF_WEEK (SUNDAY=1..SATURDAY=7) to Persian index (Saturday=0..Friday=6). */
    fun javaDayOfWeekToPersianIndex(javaDayOfWeek: Int): Int = when (javaDayOfWeek) {
        Calendar.SATURDAY -> 0
        Calendar.SUNDAY -> 1
        Calendar.MONDAY -> 2
        Calendar.TUESDAY -> 3
        Calendar.WEDNESDAY -> 4
        Calendar.THURSDAY -> 5
        Calendar.FRIDAY -> 6
        else -> 0
    }

    fun persianIndexToJavaDayOfWeek(persianIndex: Int): Int = when (persianIndex) {
        0 -> Calendar.SATURDAY
        1 -> Calendar.SUNDAY
        2 -> Calendar.MONDAY
        3 -> Calendar.TUESDAY
        4 -> Calendar.WEDNESDAY
        5 -> Calendar.THURSDAY
        6 -> Calendar.FRIDAY
        else -> Calendar.SATURDAY
    }

    fun toShamsi(epochMillis: Long): ShamsiDate {
        val icu = IcuCalendar.getInstance(persianLocale).apply {
            time = Date(epochMillis)
        }
        val year = icu.get(IcuCalendar.YEAR)
        val month = icu.get(IcuCalendar.MONTH) + 1
        val day = icu.get(IcuCalendar.DAY_OF_MONTH)
        val dow = javaDayOfWeekToPersianIndex(icu.get(IcuCalendar.DAY_OF_WEEK))
        return ShamsiDate(year, month, day, dow)
    }

    fun shamsiToEpochMillis(year: Int, month: Int, day: Int, hour: Int = 9, minute: Int = 0): Long {
        val icu = IcuCalendar.getInstance(persianLocale).apply {
            clear()
            set(IcuCalendar.YEAR, year)
            set(IcuCalendar.MONTH, (month - 1).coerceIn(0, 11))
            set(IcuCalendar.DAY_OF_MONTH, day.coerceAtLeast(1))
            set(IcuCalendar.HOUR_OF_DAY, hour)
            set(IcuCalendar.MINUTE, minute)
            set(IcuCalendar.SECOND, 0)
            set(IcuCalendar.MILLISECOND, 0)
        }
        return icu.timeInMillis
    }

    fun daysInShamsiMonth(year: Int, month: Int): Int {
        val icu = IcuCalendar.getInstance(persianLocale).apply {
            clear()
            set(IcuCalendar.YEAR, year)
            set(IcuCalendar.MONTH, (month - 1).coerceIn(0, 11))
            set(IcuCalendar.DAY_OF_MONTH, 1)
        }
        return icu.getActualMaximum(IcuCalendar.DAY_OF_MONTH)
    }

    fun firstDayOfWeekInShamsiMonth(year: Int, month: Int): Int {
        val icu = IcuCalendar.getInstance(persianLocale).apply {
            clear()
            set(IcuCalendar.YEAR, year)
            set(IcuCalendar.MONTH, (month - 1).coerceIn(0, 11))
            set(IcuCalendar.DAY_OF_MONTH, 1)
        }
        return javaDayOfWeekToPersianIndex(icu.get(IcuCalendar.DAY_OF_WEEK))
    }

    fun formatFullShamsiDate(epochMillis: Long): String {
        val d = toShamsi(epochMillis)
        val monthName = persianMonthNames.getOrElse(d.month - 1) { "" }
        val weekDay = weekDayNames.getOrElse(d.dayOfWeekIndex) { "" }
        return "$weekDay ${formatInt(d.day)} $monthName ${formatInt(d.year)}"
    }

    fun formatShortShamsiDate(epochMillis: Long): String {
        val d = toShamsi(epochMillis)
        val monthName = persianMonthNames.getOrElse(d.month - 1) { "" }
        return "${formatInt(d.day)} $monthName ${formatInt(d.year)}"
    }

    fun formatMonthYear(year: Int, month: Int): String {
        val monthName = persianMonthNames.getOrElse(month - 1) { "" }
        return "$monthName ${formatInt(year)}"
    }

    fun startOfDayMillis(epochMillis: Long): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = epochMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }

    fun endOfDayMillis(epochMillis: Long): Long = startOfDayMillis(epochMillis) + 86_400_000L - 1L

    fun isSameLocalDay(millisA: Long, millisB: Long): Boolean =
        startOfDayMillis(millisA) == startOfDayMillis(millisB)

    fun dateKey(epochMillis: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = epochMillis }
        return String.format(
            Locale.US,
            "%04d-%02d-%02d",
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun daysUntil(targetMillis: Long, nowMillis: Long = System.currentTimeMillis()): Int {
        val targetStart = startOfDayMillis(targetMillis)
        val nowStart = startOfDayMillis(nowMillis)
        val diff = targetStart - nowStart
        return (diff / 86_400_000L).toInt()
    }

    fun formatDaysUntilExam(examMillis: Long, nowMillis: Long = System.currentTimeMillis()): String {
        val days = daysUntil(examMillis, nowMillis)
        return when {
            days < 0 -> "${formatInt(-days)} روز گذشته"
            days == 0 -> "امروز"
            days == 1 -> "فردا (۱ روز تا امتحان)"
            else -> "${formatInt(days)} روز تا امتحان"
        }
    }

    fun formatCountdownMinutes(targetMillis: Long, nowMillis: Long = System.currentTimeMillis()): String {
        val diffMs = targetMillis - nowMillis
        if (diffMs <= 0L) return "هم‌اکنون"
        val totalMinutes = ceil(diffMs / 60_000.0).toInt()
        val days = totalMinutes / (24 * 60)
        val hours = (totalMinutes % (24 * 60)) / 60
        val minutes = totalMinutes % 60
        return when {
            days > 0 -> "${formatInt(days)} روز و ${formatInt(hours)} ساعت دیگر"
            hours > 0 && minutes > 0 -> "${formatInt(hours)} ساعت و ${formatInt(minutes)} دقیقه دیگر"
            hours > 0 -> "${formatInt(hours)} ساعت دیگر"
            else -> "${formatInt(minutes)} دقیقه دیگر"
        }
    }

    fun todayPersianDayOfWeek(nowMillis: Long = System.currentTimeMillis()): Int {
        val cal = Calendar.getInstance().apply { timeInMillis = nowMillis }
        return javaDayOfWeekToPersianIndex(cal.get(Calendar.DAY_OF_WEEK))
    }

    fun startOfPersianWeekMillis(anchorMillis: Long): Long {
        val todayStart = startOfDayMillis(anchorMillis)
        val dow = todayPersianDayOfWeek(todayStart)
        return todayStart - dow * 86_400_000L
    }
}
