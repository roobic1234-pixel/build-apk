package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.PersianDateUtil
import com.example.data.local.ClassSessionEntity
import com.example.data.local.CourseEntity
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.DaneshinoCard
import com.example.ui.components.PillBadge
import com.example.ui.components.ScreenHeader
import com.example.ui.theme.CourseColorPalette
import com.example.ui.viewmodel.DaneshinoDataState

@Composable
fun CourseDetailScreen(
    courseId: Long,
    state: DaneshinoDataState,
    onSaveCourse: (CourseEntity, List<ClassSessionEntity>) -> Unit,
    onDeleteCourse: (Long) -> Unit,
    onOpenAttachments: (Long) -> Unit,
    onBack: () -> Unit
) {
    val cws = state.coursesWithSessions.firstOrNull { it.course.id == courseId }
    var showEdit by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    if (cws == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .navigationBarsPadding()
        ) {
            ScreenHeader(title = "جزئیات درس", onBack = onBack)
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("این درس یافت نشد یا حذف شده است.", style = MaterialTheme.typography.bodyLarge)
            }
        }
        return
    }

    val course = cws.course
    val courseColor = CourseColorPalette.safeColor(course.colorArgb)
    val attachmentsCount = state.attachments.count { it.courseId == courseId }
    val notesCount = state.notes.count { it.courseId == courseId }

    if (showEdit) {
        CourseEditorDialog(
            existing = cws,
            defaultTerm = state.preferences.currentTerm,
            onSave = { updated, sessions ->
                onSaveCourse(updated, sessions)
                showEdit = false
            },
            onDismiss = { showEdit = false }
        )
    }

    if (showDeleteConfirm) {
        ConfirmDeleteDialog(
            title = stringResource(R.string.course_delete_confirm_title),
            body = stringResource(R.string.course_delete_confirm_body, course.name),
            onConfirm = {
                onDeleteCourse(course.id)
                showDeleteConfirm = false
                onBack()
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
    ) {
        ScreenHeader(
            title = course.name,
            subtitle = listOf(course.code, course.courseType, course.term).filter { it.isNotBlank() }.joinToString(" • "),
            onBack = onBack,
            actions = {
                IconButton(onClick = { showEdit = true }, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.Default.Edit, contentDescription = "ویرایش درس", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = { showDeleteConfirm = true }, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.Default.Delete, contentDescription = "حذف درس", tint = MaterialTheme.colorScheme.error)
                }
            }
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                DaneshinoCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(courseColor)
                        )
                        PillBadge(
                            text = "${PersianDateUtil.formatCredits(course.credits)} واحد",
                            containerColor = courseColor.copy(alpha = 0.16f),
                            contentColor = courseColor
                        )
                        if (course.grade != null) {
                            PillBadge(
                                text = "نمره: ${PersianDateUtil.formatDecimal(course.grade, 2)}",
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                    if (course.description.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text(course.description, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            if (course.instructorName.isNotBlank() || course.instructorEmail.isNotBlank() ||
                course.instructorPhone.isNotBlank() || course.instructorOffice.isNotBlank()
            ) {
                item {
                    DaneshinoCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("اطلاعات استاد", style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(Modifier.height(8.dp))
                        if (course.instructorName.isNotBlank()) Text("نام: ${course.instructorName}")
                        if (course.instructorEmail.isNotBlank()) Text("ایمیل: ${course.instructorEmail}", style = MaterialTheme.typography.bodySmall)
                        if (course.instructorPhone.isNotBlank()) Text("تلفن: ${PersianDateUtil.formatLtrPersian(course.instructorPhone)}", style = MaterialTheme.typography.bodySmall)
                        if (course.instructorOffice.isNotBlank()) Text("دفتر: ${course.instructorOffice}", style = MaterialTheme.typography.bodySmall)
                        if (course.instructorNotes.isNotBlank()) Text("یادداشت: ${course.instructorNotes}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            item {
                DaneshinoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("جلسات هفتگی", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(8.dp))
                    if (cws.sessions.isEmpty()) {
                        Text(
                            text = "جلسه کلاسی برای این درس ثبت نشده است.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        cws.sessions.forEach { s ->
                            val day = PersianDateUtil.weekDayNames.getOrElse(s.dayOfWeek) { "" }
                            val loc = listOf(s.building, s.roomNumber).filter { it.isNotBlank() }.joinToString(" - ")
                            Text(
                                text = "• $day ${PersianDateUtil.formatTimeRange(s.startMinuteOfDay, s.endMinuteOfDay)}" +
                                    if (loc.isNotBlank()) " ($loc)" else "",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            item {
                DaneshinoCard {
                    Text(
                        text = "پیوست‌ها و یادداشت‌های مرتبط",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "تعداد فایل‌های پیوست: ${PersianDateUtil.formatInt(attachmentsCount)} • تعداد یادداشت‌ها: ${PersianDateUtil.formatInt(notesCount)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { onOpenAttachments(courseId) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AttachFile, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("مدیریت فایل‌های پیوست این درس")
                    }
                }
            }
        }
    }
}
