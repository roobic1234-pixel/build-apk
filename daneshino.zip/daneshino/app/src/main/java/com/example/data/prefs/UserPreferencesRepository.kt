package com.example.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.daneshinoDataStore: DataStore<Preferences> by preferencesDataStore(name = "daneshino_prefs")

enum class ReminderMethod(val storageKey: String, val persianLabel: String) {
    NOTIFICATION("notification", "اعلان"),
    AUDIO_ALARM("audio_alarm", "آلارم صوتی"),
    BOTH("both", "هر دو");

    companion object {
        fun fromKey(key: String?): ReminderMethod =
            entries.firstOrNull { it.storageKey == key } ?: NOTIFICATION
    }
}

object ReminderLeadTime {
    val allowedMinutes: List<Int> = listOf(60, 30, 25, 20, 15, 10)
    const val DEFAULT_MINUTES: Int = 15

    fun sanitize(minutes: Int): Int =
        if (minutes in allowedMinutes) minutes else DEFAULT_MINUTES

    fun formatLabel(minutes: Int): String = when (minutes) {
        60 -> "۱ ساعت قبل"
        30 -> "۳۰ دقیقه قبل"
        25 -> "۲۵ دقیقه قبل"
        20 -> "۲۰ دقیقه قبل"
        15 -> "۱۵ دقیقه قبل"
        10 -> "۱۰ دقیقه قبل"
        else -> "۱۵ دقیقه قبل"
    }
}

data class UserPreferences(
    val onboardingCompleted: Boolean = false,
    val studentName: String = "",
    val university: String = "",
    val major: String = "",
    val degreeLevel: String = "",
    val currentTerm: String = "",
    val totalDegreeCredits: Double = 140.0,
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val classRemindersEnabled: Boolean = true,
    val classReminderMinutesBefore: Int = ReminderLeadTime.DEFAULT_MINUTES,
    val classReminderMethod: ReminderMethod = ReminderMethod.NOTIFICATION,
    val assignmentRemindersEnabled: Boolean = true,
    val examRemindersEnabled: Boolean = true
)

data class PersistedTimerState(
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val isBreakPhase: Boolean = false,
    val focusMinutes: Int = 25,
    val breakMinutes: Int = 5,
    val selectedCourseId: Long? = null,
    val phaseStartEpochMillis: Long = 0L,
    val accumulatedSeconds: Long = 0L,
    val sessionStartedEpochMillis: Long = 0L
)

class UserPreferencesRepository(private val dataStore: DataStore<Preferences>) {

    constructor(context: Context) : this(context.daneshinoDataStore)

    private object Keys {
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val STUDENT_NAME = stringPreferencesKey("student_name")
        val UNIVERSITY = stringPreferencesKey("university")
        val MAJOR = stringPreferencesKey("major")
        val DEGREE_LEVEL = stringPreferencesKey("degree_level")
        val CURRENT_TERM = stringPreferencesKey("current_term")
        val TOTAL_DEGREE_CREDITS = doublePreferencesKey("total_degree_credits")
        val THEME_MODE = stringPreferencesKey("theme_mode")

        val CLASS_REMINDERS_ENABLED = booleanPreferencesKey("class_reminders_enabled")
        val CLASS_REMINDER_MINUTES = intPreferencesKey("class_reminder_minutes")
        val CLASS_REMINDER_METHOD = stringPreferencesKey("class_reminder_method")
        val ASSIGNMENT_REMINDERS_ENABLED = booleanPreferencesKey("assignment_reminders_enabled")
        val EXAM_REMINDERS_ENABLED = booleanPreferencesKey("exam_reminders_enabled")

        // Study timer persistence for accurate background continuation
        val TIMER_RUNNING = booleanPreferencesKey("timer_running")
        val TIMER_PAUSED = booleanPreferencesKey("timer_paused")
        val TIMER_IS_BREAK = booleanPreferencesKey("timer_is_break")
        val TIMER_FOCUS_MIN = intPreferencesKey("timer_focus_min")
        val TIMER_BREAK_MIN = intPreferencesKey("timer_break_min")
        val TIMER_COURSE_ID = longPreferencesKey("timer_course_id")
        val TIMER_PHASE_START = longPreferencesKey("timer_phase_start")
        val TIMER_ACCUMULATED_SEC = longPreferencesKey("timer_accumulated_sec")
        val TIMER_SESSION_START = longPreferencesKey("timer_session_start")
    }

    val preferencesFlow: Flow<UserPreferences> = dataStore.data.map { prefs ->
        UserPreferences(
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false,
            studentName = prefs[Keys.STUDENT_NAME] ?: "",
            university = prefs[Keys.UNIVERSITY] ?: "",
            major = prefs[Keys.MAJOR] ?: "",
            degreeLevel = prefs[Keys.DEGREE_LEVEL] ?: "",
            currentTerm = prefs[Keys.CURRENT_TERM] ?: "",
            totalDegreeCredits = prefs[Keys.TOTAL_DEGREE_CREDITS] ?: 140.0,
            themeMode = AppThemeMode.fromKey(prefs[Keys.THEME_MODE]),
            classRemindersEnabled = prefs[Keys.CLASS_REMINDERS_ENABLED] ?: true,
            classReminderMinutesBefore = ReminderLeadTime.sanitize(
                prefs[Keys.CLASS_REMINDER_MINUTES] ?: ReminderLeadTime.DEFAULT_MINUTES
            ),
            classReminderMethod = ReminderMethod.fromKey(prefs[Keys.CLASS_REMINDER_METHOD]),
            assignmentRemindersEnabled = prefs[Keys.ASSIGNMENT_REMINDERS_ENABLED] ?: true,
            examRemindersEnabled = prefs[Keys.EXAM_REMINDERS_ENABLED] ?: true
        )
    }

    val timerStateFlow: Flow<PersistedTimerState> = dataStore.data.map { prefs ->
        val rawCourseId = prefs[Keys.TIMER_COURSE_ID] ?: -1L
        PersistedTimerState(
            isRunning = prefs[Keys.TIMER_RUNNING] ?: false,
            isPaused = prefs[Keys.TIMER_PAUSED] ?: false,
            isBreakPhase = prefs[Keys.TIMER_IS_BREAK] ?: false,
            focusMinutes = prefs[Keys.TIMER_FOCUS_MIN] ?: 25,
            breakMinutes = prefs[Keys.TIMER_BREAK_MIN] ?: 5,
            selectedCourseId = if (rawCourseId > 0L) rawCourseId else null,
            phaseStartEpochMillis = prefs[Keys.TIMER_PHASE_START] ?: 0L,
            accumulatedSeconds = prefs[Keys.TIMER_ACCUMULATED_SEC] ?: 0L,
            sessionStartedEpochMillis = prefs[Keys.TIMER_SESSION_START] ?: 0L
        )
    }

    suspend fun getPreferencesOnce(): UserPreferences = preferencesFlow.first()

    suspend fun completeOnboarding(name: String) {
        dataStore.edit {
            it[Keys.ONBOARDING_COMPLETED] = true
            it[Keys.STUDENT_NAME] = name.trim()
        }
    }

    suspend fun updateProfile(
        studentName: String,
        university: String,
        major: String,
        degreeLevel: String,
        currentTerm: String,
        totalDegreeCredits: Double
    ) {
        dataStore.edit {
            it[Keys.STUDENT_NAME] = studentName.trim()
            it[Keys.UNIVERSITY] = university.trim()
            it[Keys.MAJOR] = major.trim()
            it[Keys.DEGREE_LEVEL] = degreeLevel.trim()
            it[Keys.CURRENT_TERM] = currentTerm.trim()
            it[Keys.TOTAL_DEGREE_CREDITS] = totalDegreeCredits.coerceIn(1.0, 400.0)
        }
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        dataStore.edit { it[Keys.THEME_MODE] = mode.storageKey }
    }

    suspend fun setClassRemindersEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.CLASS_REMINDERS_ENABLED] = enabled }
    }

    suspend fun setClassReminderMinutes(minutes: Int) {
        dataStore.edit { it[Keys.CLASS_REMINDER_MINUTES] = ReminderLeadTime.sanitize(minutes) }
    }

    suspend fun setClassReminderMethod(method: ReminderMethod) {
        dataStore.edit { it[Keys.CLASS_REMINDER_METHOD] = method.storageKey }
    }

    suspend fun setAssignmentRemindersEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.ASSIGNMENT_REMINDERS_ENABLED] = enabled }
    }

    suspend fun setExamRemindersEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.EXAM_REMINDERS_ENABLED] = enabled }
    }

    suspend fun restorePreferences(prefs: UserPreferences) {
        dataStore.edit {
            it[Keys.ONBOARDING_COMPLETED] = true
            it[Keys.STUDENT_NAME] = prefs.studentName
            it[Keys.UNIVERSITY] = prefs.university
            it[Keys.MAJOR] = prefs.major
            it[Keys.DEGREE_LEVEL] = prefs.degreeLevel
            it[Keys.CURRENT_TERM] = prefs.currentTerm
            it[Keys.TOTAL_DEGREE_CREDITS] = prefs.totalDegreeCredits
            it[Keys.THEME_MODE] = prefs.themeMode.storageKey
            it[Keys.CLASS_REMINDERS_ENABLED] = prefs.classRemindersEnabled
            it[Keys.CLASS_REMINDER_MINUTES] = ReminderLeadTime.sanitize(prefs.classReminderMinutesBefore)
            it[Keys.CLASS_REMINDER_METHOD] = prefs.classReminderMethod.storageKey
            it[Keys.ASSIGNMENT_REMINDERS_ENABLED] = prefs.assignmentRemindersEnabled
            it[Keys.EXAM_REMINDERS_ENABLED] = prefs.examRemindersEnabled
        }
    }

    suspend fun saveTimerState(state: PersistedTimerState) {
        dataStore.edit {
            it[Keys.TIMER_RUNNING] = state.isRunning
            it[Keys.TIMER_PAUSED] = state.isPaused
            it[Keys.TIMER_IS_BREAK] = state.isBreakPhase
            it[Keys.TIMER_FOCUS_MIN] = state.focusMinutes
            it[Keys.TIMER_BREAK_MIN] = state.breakMinutes
            it[Keys.TIMER_COURSE_ID] = state.selectedCourseId ?: -1L
            it[Keys.TIMER_PHASE_START] = state.phaseStartEpochMillis
            it[Keys.TIMER_ACCUMULATED_SEC] = state.accumulatedSeconds
            it[Keys.TIMER_SESSION_START] = state.sessionStartedEpochMillis
        }
    }
}
