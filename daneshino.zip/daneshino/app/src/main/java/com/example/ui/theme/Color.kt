package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Daneshino Palette
val DaneshinoNavy = Color(0xFF172554)
val DaneshinoBlue = Color(0xFF3B82F6)
val DaneshinoTeal = Color(0xFF14B8A6)
val DaneshinoPurple = Color(0xFF8B5CF6)
val DaneshinoCoral = Color(0xFFFB7185)
val DaneshinoAmber = Color(0xFFFBBF24)
val DaneshinoWhite = Color(0xFFFFFFFF)
val DaneshinoLightGray = Color(0xFFF3F4F6)

// Light Theme Tokens
val LightBackground = Color(0xFFF3F4F6)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE8EEF7)
val LightSurfaceContainerLow = Color(0xFFF8FAFC)
val LightSurfaceContainer = Color(0xFFFFFFFF)
val LightSurfaceContainerHigh = Color(0xFFEEF2F8)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFCBD5E1)
val LightOutlineVariant = Color(0xFFE2E8F0)
val LightPrimaryContainer = Color(0xFFDBEAFE)
val LightOnPrimaryContainer = Color(0xFF172554)
val LightSecondaryContainer = Color(0xFFCCFBF1)
val LightOnSecondaryContainer = Color(0xFF0F4C46)
val LightTertiaryContainer = Color(0xFFEDE9FE)
val LightOnTertiaryContainer = Color(0xFF3B0764)
val LightError = Color(0xFFE11D48)
val LightErrorContainer = Color(0xFFFFE4E6)
val LightOnErrorContainer = Color(0xFF881337)

// Dark Theme Tokens
val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkSurfaceContainerLow = Color(0xFF111827)
val DarkSurfaceContainer = Color(0xFF162033)
val DarkSurfaceContainerHigh = Color(0xFF1E293B)
val DarkOnBackground = Color(0xFFF8FAFC)
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF475569)
val DarkOutlineVariant = Color(0xFF2B394F)
val DarkPrimary = Color(0xFF60A5FA)
val DarkOnPrimary = Color(0xFF0B1120)
val DarkPrimaryContainer = Color(0xFF1E3A8A)
val DarkOnPrimaryContainer = Color(0xFFDBEAFE)
val DarkSecondary = Color(0xFF2DD4BF)
val DarkOnSecondary = Color(0xFF042F2E)
val DarkSecondaryContainer = Color(0xFF115E59)
val DarkOnSecondaryContainer = Color(0xFFCCFBF1)
val DarkTertiary = Color(0xFFA78BFA)
val DarkOnTertiary = Color(0xFF2E1065)
val DarkTertiaryContainer = Color(0xFF4C1D95)
val DarkOnTertiaryContainer = Color(0xFFEDE9FE)
val DarkError = Color(0xFFFB7185)
val DarkOnError = Color(0xFF4C0519)
val DarkErrorContainer = Color(0xFF881337)
val DarkOnErrorContainer = Color(0xFFFFE4E6)

/**
 * Curated non-black ARGB course colors (32-bit standard Android ARGB ints).
 * Storing 32-bit ARGB Int guarantees Compose Color(argbInt) always renders the exact chosen hue.
 */
object CourseColorPalette {
    val defaultArgb: Int = 0xFF3B82F6.toInt()

    val swatches: List<Pair<String, Int>> = listOf(
        "آبی" to 0xFF3B82F6.toInt(),
        "فیروزه‌ای" to 0xFF14B8A6.toInt(),
        "بنفش" to 0xFF8B5CF6.toInt(),
        "مرجانی" to 0xFFFB7185.toInt(),
        "کهربایی" to 0xFFF59E0B.toInt(),
        "نیلی" to 0xFF6366F1.toInt(),
        "زمردی" to 0xFF10B981.toInt(),
        "صورتی" to 0xFFEC4899.toInt(),
        "فیروزه‌ای روشن" to 0xFF06B6D4.toInt(),
        "نارنجی" to 0xFFF97316.toInt(),
        "سرمه‌ای" to 0xFF1D4ED8.toInt(),
        "یاقوتی" to 0xFFEF4444.toInt()
    )

    fun safeColor(argb: Int): Color {
        val rgb = argb and 0x00FFFFFF
        if (rgb == 0) return Color(defaultArgb)
        return Color(argb or 0xFF000000.toInt())
    }
}
