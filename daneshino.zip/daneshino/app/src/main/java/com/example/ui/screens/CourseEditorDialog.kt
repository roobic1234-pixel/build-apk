package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.core.PersianDateUtil
import com.example.data.local.ClassSessionEntity
import com.example.data.local.CourseEntity
import com.example.data.local.CourseWithSessions
import com.example.ui.components.CourseColorPicker
import com.example.ui.components.StepperRow
import com.example.ui.theme.CourseColorPalette

private val courseTypes = listOf("تخصصی", "اصلی", "پایه", "عمومی", "آزمایشگاه", "کارگاه")

private data class SessionDraft(
    val dayOfWeek: Int = 0,
    val startMinute: Int = 8 * 60,
    val endMinute: Int = 9 * 60 + 30,
    val roomNumber: String = "",
    val building: String = "",
    val notes: String = "",
    val repeatWeekly: Boolean = true
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CourseEditorDialog(
    existing: CourseWithSessions?,
    defaultTerm: String,
    onSave: (CourseEntity, List<ClassSessionEntity>) -> Unit,
    onDismiss: () -> Unit
) {
    val c = existing?.course
    var name by remember { mutableStateOf(c?.name ?: "") }
    var code by remember { mutableStateOf(c?.code ?: "") }
    var creditsText by remember { mutableStateOf(c?.credits?.let { if (it % 1.0 == 0.0) it.toInt().toString() else it.toString() } ?: "3") }
    var term by remember { mutableStateOf(c?.term ?: defaultTerm) }
    var courseType by remember { mutableStateOf(c?.courseType ?: "تخصصی") }
    var colorArgb by remember { mutableIntStateOf(c?.colorArgb ?: CourseColorPalette.defaultArgb) }
    var description by remember { mutableStateOf(c?.description ?: "") }
    var instructorName by remember { mutableStateOf(c?.instructorName ?: "") }
    var instructorEmail by remember { mutableStateOf(c?.instructorEmail ?: "") }
    var instructorPhone by remember { mutableStateOf(c?.instructorPhone ?: "") }
    var instructorOffice by remember { mutableStateOf(c?.instructorOffice ?: "") }
    var instructorNotes by remember { mutableStateOf(c?.instructorNotes ?: "") }
    var showInstructorDetails by remember {
        mutableStateOf(
            c != null && (c.instructorEmail.isNotBlank() || c.instructorPhone.isNotBlank() ||
                c.instructorOffice.isNotBlank() || c.instructorNotes.isNotBlank())
        )
    }

    val sessions = remember {
        mutableStateListOf<SessionDraft>().apply {
            if (existing != null) {
                existing.sessions.forEach { s ->
                    add(
                        SessionDraft(
                            dayOfWeek = s.dayOfWeek,
                            startMinute = s.startMinuteOfDay,
                            endMinute = s.endMinuteOfDay,
                            roomNumber = s.roomNumber,
                            building = s.building,
                            notes = s.notes,
                            repeatWeekly = s.repeatWeekly
                        )
                    )
                }
            }
        }
    }

    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (existing == null) "افزودن درس جدید" else "ویرایش درس",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (errorText != null) {
                    Text(
                        text = errorText!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorText = null },
                    label = { Text("نام درس *") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("course_name_input")
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it },
                        label = { Text("کد درس") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = creditsText,
                        onValueChange = { creditsText = it },
                        label = { Text("واحد *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = term,
                    onValueChange = { term = it },
                    label = { Text("ترم (مثلاً ۱۴۰۵-۱)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("نوع درس", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    courseTypes.forEach { type ->
                        FilterChip(
                            selected = courseType == type,
                            onClick = { courseType = type },
                            label = { Text(type) }
                        )
                    }
                }

                Text("رنگ درس", style = MaterialTheme.typography.labelLarge)
                CourseColorPicker(
                    selectedArgb = colorArgb,
                    onSelect = { colorArgb = it }
                )

                OutlinedTextField(
                    value = instructorName,
                    onValueChange = { instructorName = it },
                    label = { Text("نام استاد (اختیاری)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                TextButton(onClick = { showInstructorDetails = !showInstructorDetails }) {
                    Text(if (showInstructorDetails) "بستن اطلاعات تکمیلی استاد" else "اطلاعات تکمیلی استاد (ایمیل، تلفن، دفتر)")
                }

                if (showInstructorDetails) {
                    OutlinedTextField(
                        value = instructorEmail,
                        onValueChange = { instructorEmail = it },
                        label = { Text("ایمیل استاد") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = instructorPhone,
                        onValueChange = { instructorPhone = it },
                        label = { Text("تلفن استاد") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = instructorOffice,
                        onValueChange = { instructorOffice = it },
                        label = { Text("دفتر استاد") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = instructorNotes,
                        onValueChange = { instructorNotes = it },
                        label = { Text("یادداشت درباره استاد") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("توضیحات درس") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                HorizontalDivider()

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("جلسات هفتگی کلاس", style = MaterialTheme.typography.titleSmall)
                    OutlinedButton(
                        onClick = { sessions.add(SessionDraft()) },
                        modifier = Modifier.testTag("add_session_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("افزودن جلسه")
                    }
                }

                sessions.forEachIndexed { index, draft ->
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "جلسه ${PersianDateUtil.formatInt(index + 1)}",
                                    style = MaterialTheme.typography.labelLarge
                                )
                                IconButton(
                                    onClick = { sessions.removeAt(index) },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف جلسه",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                PersianDateUtil.weekDayNames.forEachIndexed { dIdx, dayLabel ->
                                    FilterChip(
                                        selected = draft.dayOfWeek == dIdx,
                                        onClick = { sessions[index] = draft.copy(dayOfWeek = dIdx) },
                                        label = { Text(dayLabel, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }

                            StepperRow(
                                label = "شروع",
                                valueText = PersianDateUtil.formatTime(draft.startMinute),
                                onMinus = {
                                    val nextStart = (draft.startMinute - 15).coerceAtLeast(6 * 60)
                                    sessions[index] = draft.copy(startMinute = nextStart)
                                },
                                onPlus = {
                                    val nextStart = (draft.startMinute + 15).coerceAtMost(22 * 60)
                                    val adjustedEnd = draft.endMinute.coerceAtLeast(nextStart + 30)
                                    sessions[index] = draft.copy(startMinute = nextStart, endMinute = adjustedEnd.coerceAtMost(23 * 60 + 45))
                                }
                            )

                            StepperRow(
                                label = "پایان",
                                valueText = PersianDateUtil.formatTime(draft.endMinute),
                                onMinus = {
                                    val nextEnd = (draft.endMinute - 15).coerceAtLeast(draft.startMinute + 15)
                                    sessions[index] = draft.copy(endMinute = nextEnd)
                                },
                                onPlus = {
                                    val nextEnd = (draft.endMinute + 15).coerceAtMost(23 * 60 + 45)
                                    sessions[index] = draft.copy(endMinute = nextEnd)
                                }
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = draft.building,
                                    onValueChange = { sessions[index] = draft.copy(building = it) },
                                    label = { Text("ساختمان") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = draft.roomNumber,
                                    onValueChange = { sessions[index] = draft.copy(roomNumber = it) },
                                    label = { Text("کلاس") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("تکرار هفتگی", style = MaterialTheme.typography.bodySmall)
                                Switch(
                                    checked = draft.repeatWeekly,
                                    onCheckedChange = { sessions[index] = draft.copy(repeatWeekly = it) }
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmedName = name.trim()
                    val parsedCredits = creditsText.replace("٫", ".").replace(",", ".").toDoubleOrNull()
                    if (trimmedName.isBlank()) {
                        errorText = "لطفاً نام درس را وارد کنید."
                        return@Button
                    }
                    if (parsedCredits == null || parsedCredits <= 0.0 || parsedCredits > 24.0) {
                        errorText = "تعداد واحد باید عددی معتبر و بزرگ‌تر از صفر باشد."
                        return@Button
                    }
                    val courseEntity = CourseEntity(
                        id = c?.id ?: 0L,
                        name = trimmedName,
                        code = code.trim(),
                        credits = parsedCredits,
                        instructorName = instructorName.trim(),
                        instructorEmail = instructorEmail.trim(),
                        instructorPhone = instructorPhone.trim(),
                        instructorOffice = instructorOffice.trim(),
                        instructorNotes = instructorNotes.trim(),
                        term = term.trim(),
                        courseType = courseType,
                        colorArgb = colorArgb or 0xFF000000.toInt(),
                        description = description.trim(),
                        isFavorite = c?.isFavorite ?: false,
                        grade = c?.grade,
                        createdAtMillis = c?.createdAtMillis ?: System.currentTimeMillis()
                    )
                    val sessionEntities = sessions.map { d ->
                        ClassSessionEntity(
                            courseId = courseEntity.id,
                            dayOfWeek = d.dayOfWeek,
                            startMinuteOfDay = d.startMinute,
                            endMinuteOfDay = d.endMinute.coerceAtLeast(d.startMinute + 15),
                            roomNumber = d.roomNumber.trim(),
                            building = d.building.trim(),
                            notes = d.notes.trim(),
                            repeatWeekly = d.repeatWeekly
                        )
                    }
                    onSave(courseEntity, sessionEntities)
                },
                modifier = Modifier.testTag("save_course_button")
            ) {
                Text("ذخیره")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}
