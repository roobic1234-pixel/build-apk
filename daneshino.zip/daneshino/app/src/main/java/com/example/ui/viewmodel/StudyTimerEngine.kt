package com.example.ui.viewmodel

import com.example.data.prefs.PersistedTimerState

data class StudyPreset(
    val label: String,
    val focusMinutes: Int,
    val breakMinutes: Int
)

object StudyTimerEngine {

    val presets = listOf(
        StudyPreset("۲۵ / ۵", 25, 5),
        StudyPreset("۵۰ / ۱۰", 50, 10),
        StudyPreset("۹۰ / ۱۵", 90, 15)
    )

    fun phaseTargetSeconds(state: PersistedTimerState): Long {
        val mins = if (state.isBreakPhase) state.breakMinutes else state.focusMinutes
        return mins.coerceAtLeast(1) * 60L
    }

    /**
     * Computes actual elapsed seconds in the current phase, continuing accurately even when
     * the app was in the background or process was killed.
     */
    fun elapsedSeconds(state: PersistedTimerState, nowMillis: Long): Long {
        if (!state.isRunning) return 0L
        if (state.isPaused || state.phaseStartEpochMillis <= 0L) {
            return state.accumulatedSeconds.coerceAtLeast(0L)
        }
        val deltaSec = ((nowMillis - state.phaseStartEpochMillis) / 1000L).coerceAtLeast(0L)
        return (state.accumulatedSeconds + deltaSec).coerceAtLeast(0L)
    }

    fun remainingSeconds(state: PersistedTimerState, nowMillis: Long): Long {
        val target = phaseTargetSeconds(state)
        return (target - elapsedSeconds(state, nowMillis)).coerceAtLeast(0L)
    }

    fun isPhaseFinished(state: PersistedTimerState, nowMillis: Long): Boolean {
        if (!state.isRunning || state.isPaused) return false
        return elapsedSeconds(state, nowMillis) >= phaseTargetSeconds(state)
    }

    fun start(
        current: PersistedTimerState,
        nowMillis: Long,
        courseId: Long? = current.selectedCourseId
    ): PersistedTimerState = current.copy(
        isRunning = true,
        isPaused = false,
        selectedCourseId = courseId,
        phaseStartEpochMillis = nowMillis,
        accumulatedSeconds = 0L,
        sessionStartedEpochMillis = if (!current.isBreakPhase) nowMillis else current.sessionStartedEpochMillis
    )

    fun pause(current: PersistedTimerState, nowMillis: Long): PersistedTimerState {
        if (!current.isRunning || current.isPaused) return current
        return current.copy(
            isPaused = true,
            accumulatedSeconds = elapsedSeconds(current, nowMillis),
            phaseStartEpochMillis = 0L
        )
    }

    fun resume(current: PersistedTimerState, nowMillis: Long): PersistedTimerState {
        if (!current.isRunning || !current.isPaused) return current
        return current.copy(
            isPaused = false,
            phaseStartEpochMillis = nowMillis
        )
    }

    fun reset(current: PersistedTimerState): PersistedTimerState = current.copy(
        isRunning = false,
        isPaused = false,
        isBreakPhase = false,
        phaseStartEpochMillis = 0L,
        accumulatedSeconds = 0L,
        sessionStartedEpochMillis = 0L
    )

    fun switchPhaseAfterComplete(current: PersistedTimerState, nowMillis: Long): PersistedTimerState {
        val nextIsBreak = !current.isBreakPhase
        return current.copy(
            isRunning = false,
            isPaused = false,
            isBreakPhase = nextIsBreak,
            phaseStartEpochMillis = 0L,
            accumulatedSeconds = 0L,
            sessionStartedEpochMillis = if (!nextIsBreak) nowMillis else 0L
        )
    }
}
