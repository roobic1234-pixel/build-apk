package com.example.reminder

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

object ReminderNotificationHelper {

    const val EXTRA_NAV_DESTINATION = "extra_nav_destination"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val classChannel = NotificationChannel(
            ReminderIds.CHANNEL_CLASS,
            context.getString(R.string.reminder_channel_class_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.reminder_channel_class_desc)
            enableVibration(true)
        }

        val taskChannel = NotificationChannel(
            ReminderIds.CHANNEL_TASK,
            context.getString(R.string.reminder_channel_task_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = context.getString(R.string.reminder_channel_task_desc)
            enableVibration(true)
        }

        val alarmChannel = NotificationChannel(
            ReminderIds.CHANNEL_ALARM,
            context.getString(R.string.reminder_channel_alarm_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.reminder_channel_alarm_desc)
            setSound(null, null) // Audio is handled explicitly by ClassAlarmService with AudioFocus
            enableVibration(false)
        }

        manager.createNotificationChannels(listOf(classChannel, taskChannel, alarmChannel))
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            NotificationManagerCompat.from(context).areNotificationsEnabled()
        }
    }

    fun showClassNotification(
        context: Context,
        notificationId: Int,
        courseName: String,
        startTimeText: String,
        locationText: String
    ) {
        ensureChannels(context)
        if (!hasNotificationPermission(context)) return

        val locSuffix = if (locationText.isNotBlank()) " • $locationText" else ""
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_NAV_DESTINATION, "courses")
        }
        val pendingOpen = PendingIntent.getActivity(
            context,
            notificationId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, ReminderIds.CHANNEL_CLASS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(context.getString(R.string.reminder_notification_title, courseName))
            .setContentText(context.getString(R.string.reminder_notification_body, startTimeText, locSuffix))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(pendingOpen)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
        } catch (_: SecurityException) {
            // Ignored safely if user revoked POST_NOTIFICATIONS concurrently
        }
    }

    fun showTaskOrExamNotification(
        context: Context,
        notificationId: Int,
        title: String,
        body: String
    ) {
        ensureChannels(context)
        if (!hasNotificationPermission(context)) return

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_NAV_DESTINATION, "tasks")
        }
        val pendingOpen = PendingIntent.getActivity(
            context,
            notificationId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, ReminderIds.CHANNEL_TASK)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingOpen)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
        } catch (_: SecurityException) {
            // Safe fallback
        }
    }

    fun showTestNotification(context: Context) {
        showClassNotification(
            context = context,
            notificationId = ReminderIds.TEST_NOTIFICATION_ID,
            courseName = "اعلان آزمایشی دانشینو",
            startTimeText = "هم‌اکنون",
            locationText = "سیستم اعلان به‌درستی فعال است"
        )
    }

    fun cancelNotification(context: Context, notificationId: Int) {
        NotificationManagerCompat.from(context).cancel(notificationId)
    }
}
