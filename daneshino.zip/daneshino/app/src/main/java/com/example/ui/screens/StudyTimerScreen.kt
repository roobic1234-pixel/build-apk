package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.core.PersianDateUtil
import com.example.data.local.StudySessionEntity
import com.example.data.prefs.PersistedTimerState
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.DaneshinoCard
import com.example.ui.components.ScreenHeader
import com.example.ui.viewmodel.DaneshinoDataState
import com.example.ui.viewmodel.StudyTimerEngine

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudyTimerScreen(
    state: DaneshinoDataState,
    timerState: PersistedTimerState,
    nowMillis: Long,
    onConfigureTimer: (Int, Int, Long?) -> Unit,
    onStart: (Long?) -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStopAndSave: () -> Unit,
    onReset: () -> Unit,
    onDeleteSession: (Long) -> Unit,
    onBack: () -> Unit
) {
    var showCustomDialog by remember { mutableStateOf(false) }
    var deletingSession by remember { mutableStateOf<StudySessionEntity?>(null) }

    val targetSec = StudyTimerEngine.phaseTargetSeconds(timerState)
    val remainingSec = if (timerState.isRunning) {
        StudyTimerEngine.remainingSeconds(timerState, nowMillis)
    } else {
        targetSec
    }
    val progress = if (targetSec > 0L) {
        ((targetSec - remainingSec).toFloat() / targetSec.toFloat()).coerceIn(0f, 1f)
    } else 0f

    // Real statistics strictly computed from saved study_sessions
    val todayKey = PersianDateUtil.dateKey(nowMillis)
    val weekStart = PersianDateUtil.startOfPersianWeekMillis(nowMillis)
    val shamsiNow = PersianDateUtil.toShamsi(nowMillis)
    val monthStart = PersianDateUtil.shamsiToEpochMillis(shamsiNow.year, shamsiNow.month, 1, 0, 0)

    val todayMin = (state.studySessions.filter { it.dateKey == todayKey }.sumOf { it.durationSeconds } / 60L).toInt()
    val weekMin = (state.studySessions.filter { it.startAtMillis >= weekStart }.sumOf { it.durationSeconds } / 60L).toInt()
    val monthMin = (state.studySessions.filter { it.startAtMillis >= monthStart }.sumOf { it.durationSeconds } / 60L).toInt()
    val totalMin = (state.studySessions.sumOf { it.durationSeconds } / 60L).toInt()
    val uniqueDays = state.studySessions.map { it.dateKey }.distinct().size
    val dailyAvgMin = if (uniqueDays > 0) totalMin / uniqueDays else 0

    val topCourse = remember(state.studySessions) {
        state.studySessions
            .groupBy { it.courseNameSnapshot.ifBlank { "مطالعه آزاد" } }
            .mapValues { it.value.sumOf { s -> s.durationSeconds } }
            .maxByOrNull { it.value }
    }

    // Last 7 days bar chart data
    val last7Days = remember(state.studySessions, todayKey) {
        val todayStart = PersianDateUtil.startOfDayMillis(nowMillis)
        (6 downTo 0).map { offset ->
            val dayMillis = todayStart - offset * 86_400_000L
            val dk = PersianDateUtil.dateKey(dayMillis)
            val mins = (state.studySessions.filter { it.dateKey == dk }.sumOf { it.durationSeconds } / 60L).toInt()
            val dow = PersianDateUtil.todayPersianDayOfWeek(dayMillis)
            PersianDateUtil.weekDayShortNames[dow] to mins
        }
    }

    if (showCustomDialog) {
        CustomTimerDialog(
            initialFocus = timerState.focusMinutes,
            initialBreak = timerState.breakMinutes,
            onConfirm = { f, b ->
                onConfigureTimer(f, b, timerState.selectedCourseId)
                showCustomDialog = false
            },
            onDismiss = { showCustomDialog = false }
        )
    }

    deletingSession?.let { target ->
        ConfirmDeleteDialog(
            title = "حذف جلسه مطالعه",
            body = "آیا از حذف این جلسه مطالعه از تاریخچه و آمار مطمئن هستید؟",
            onConfirm = {
                onDeleteSession(target.id)
                deletingSession = null
            },
            onDismiss = { deletingSession = null }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
    ) {
        ScreenHeader(
            title = "تایمر مطالعه و آمار",
            subtitle = "تمرکز زمان‌بندی‌شده با ثبت خودکار جلسات",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Timer Dial Card
            item {
                DaneshinoCard {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (timerState.isBreakPhase) "زمان استراحت" else "زمان تمرکز و مطالعه",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (timerState.isBreakPhase) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(16.dp))

                        val primaryColor = if (timerState.isBreakPhase) {
                            MaterialTheme.colorScheme.secondary
                        } else {
                            MaterialTheme.colorScheme.primary
                        }
                        val trackColor = MaterialTheme.colorScheme.surfaceVariant

                        Box(
                            modifier = Modifier.size(210.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val stroke = 14.dp.toPx()
                                val inset = stroke / 2f
                                val arcSize = Size(size.width - stroke, size.height - stroke)
                                drawArc(
                                    color = trackColor,
                                    startAngle = -90f,
                                    sweepAngle = 360f,
                                    useCenter = false,
                                    topLeft = Offset(inset, inset),
                                    size = arcSize,
                                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                                )
                                drawArc(
                                    color = primaryColor,
                                    startAngle = -90f,
                                    sweepAngle = 360f * progress,
                                    useCenter = false,
                                    topLeft = Offset(inset, inset),
                                    size = arcSize,
                                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = PersianDateUtil.formatTimerClock(remainingSec),
                                    style = MaterialTheme.typography.displaySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                val selectedCourseName = state.courseById(timerState.selectedCourseId)?.name ?: "مطالعه آزاد"
                                Text(
                                    text = selectedCourseName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(Modifier.height(16.dp))

                        // Timer Controls
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (!timerState.isRunning) {
                                Button(
                                    onClick = { onStart(timerState.selectedCourseId) },
                                    modifier = Modifier.testTag("timer_start_button")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("شروع")
                                }
                            } else if (!timerState.isPaused) {
                                Button(
                                    onClick = onPause,
                                    modifier = Modifier.testTag("timer_pause_button")
                                ) {
                                    Icon(Icons.Default.Pause, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("مکث")
                                }
                            } else {
                                Button(
                                    onClick = onResume,
                                    modifier = Modifier.testTag("timer_resume_button")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("ادامه")
                                }
                            }

                            if (timerState.isRunning) {
                                FilledTonalButton(
                                    onClick = onStopAndSave,
                                    modifier = Modifier.testTag("timer_stop_save_button")
                                ) {
                                    Icon(Icons.Default.Stop, contentDescription = null)
                                    Spacer(Modifier.width(4.dp))
                                    Text("پایان و ذخیره")
                                }
                            }

                            OutlinedButton(
                                onClick = onReset,
                                modifier = Modifier.testTag("timer_reset_button")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "بازنشانی")
                            }
                        }

                        if (!timerState.isRunning) {
                            Spacer(Modifier.height(16.dp))
                            Text("پیش‌تنظیم مطالعه / استراحت (دقیقه)", style = MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.height(8.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                StudyTimerEngine.presets.forEach { preset ->
                                    FilterChip(
                                        selected = timerState.focusMinutes == preset.focusMinutes &&
                                            timerState.breakMinutes == preset.breakMinutes,
                                        onClick = { onConfigureTimer(preset.focusMinutes, preset.breakMinutes, timerState.selectedCourseId) },
                                        label = { Text(preset.label) }
                                    )
                                }
                                FilterChip(
                                    selected = StudyTimerEngine.presets.none {
                                        it.focusMinutes == timerState.focusMinutes && it.breakMinutes == timerState.breakMinutes
                                    },
                                    onClick = { showCustomDialog = true },
                                    label = { Text("سفارشی") }
                                )
                            }

                            if (state.courses.isNotEmpty()) {
                                Spacer(Modifier.height(12.dp))
                                Text("درس مورد مطالعه", style = MaterialTheme.typography.labelLarge)
                                Spacer(Modifier.height(6.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    FilterChip(
                                        selected = timerState.selectedCourseId == null,
                                        onClick = { onConfigureTimer(timerState.focusMinutes, timerState.breakMinutes, null) },
                                        label = { Text("مطالعه آزاد") }
                                    )
                                    state.courses.forEach { course ->
                                        FilterChip(
                                            selected = timerState.selectedCourseId == course.id,
                                            onClick = { onConfigureTimer(timerState.focusMinutes, timerState.breakMinutes, course.id) },
                                            label = { Text(course.name) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Real Study Statistics Card
            item {
                DaneshinoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BarChart, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("آمار واقعی مطالعه", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        StudyStatBox("امروز", PersianDateUtil.formatDurationMinutes(todayMin), Modifier.weight(1f))
                        StudyStatBox("این هفته", PersianDateUtil.formatDurationMinutes(weekMin), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        StudyStatBox("این ماه", PersianDateUtil.formatDurationMinutes(monthMin), Modifier.weight(1f))
                        StudyStatBox("کل مطالعه", PersianDateUtil.formatDurationMinutes(totalMin), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        StudyStatBox("میانگین روزانه", PersianDateUtil.formatDurationMinutes(dailyAvgMin), Modifier.weight(1f))
                        StudyStatBox(
                            "پرمطالعه‌ترین درس",
                            topCourse?.key ?: "—",
                            Modifier.weight(1f)
                        )
                    }

                    Spacer(Modifier.height(16.dp))
                    Text("نمودار ۷ روز اخیر", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(10.dp))

                    val maxMins = (last7Days.maxOfOrNull { it.second } ?: 0).coerceAtLeast(10)
                    val barColor = MaterialTheme.colorScheme.primary
                    val emptyBarColor = MaterialTheme.colorScheme.surfaceVariant

                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                    ) {
                        val slotWidth = size.width / 7f
                        val barWidth = (slotWidth * 0.48f).coerceAtMost(28.dp.toPx())
                        last7Days.forEachIndexed { idx, (_, mins) ->
                            val x = idx * slotWidth + (slotWidth - barWidth) / 2f
                            // Background track
                            drawRoundRect(
                                color = emptyBarColor,
                                topLeft = Offset(x, 0f),
                                size = Size(barWidth, size.height),
                                cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                            )
                            if (mins > 0) {
                                val h = (mins.toFloat() / maxMins.toFloat()) * size.height
                                drawRoundRect(
                                    color = barColor,
                                    topLeft = Offset(x, size.height - h),
                                    size = Size(barWidth, h),
                                    cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth()) {
                        last7Days.forEach { (label, _) ->
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Recent Study Sessions
            item {
                Text(
                    text = "تاریخچه جلسات ثبت‌شده",
                    style = MaterialTheme.typography.titleMedium
                )
            }

            if (state.studySessions.isEmpty()) {
                item {
                    DaneshinoCard {
                        Text(
                            text = "هنوز جلسه مطالعه‌ای ثبت نشده است. با شروع و پایان تایمر، جلسات واقعی شما اینجا ذخیره می‌شوند.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(state.studySessions.take(20), key = { it.id }) { session ->
                    DaneshinoCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = session.courseNameSnapshot.ifBlank { "مطالعه آزاد" },
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "${PersianDateUtil.formatShortShamsiDate(session.startAtMillis)} • ${PersianDateUtil.formatDurationMinutes((session.durationSeconds / 60L).toInt())}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = { deletingSession = session },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف جلسه مطالعه", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StudyStatBox(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier.padding(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun CustomTimerDialog(
    initialFocus: Int,
    initialBreak: Int,
    onConfirm: (Int, Int) -> Unit,
    onDismiss: () -> Unit
) {
    var focusText by remember { mutableStateOf(initialFocus.toString()) }
    var breakText by remember { mutableStateOf(initialBreak.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تنظیم سفارشی تایمر") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = focusText,
                    onValueChange = { focusText = it },
                    label = { Text("مدت مطالعه (دقیقه)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = breakText,
                    onValueChange = { breakText = it },
                    label = { Text("مدت استراحت (دقیقه)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val f = focusText.toIntOrNull()?.coerceIn(1, 240) ?: 25
                val b = breakText.toIntOrNull()?.coerceIn(1, 60) ?: 5
                onConfirm(f, b)
            }) { Text("اعمال") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}
