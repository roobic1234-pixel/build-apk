package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.core.PersianDateUtil
import com.example.data.local.AttachmentType
import com.example.data.local.CourseAttachmentEntity
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.DaneshinoCard
import com.example.ui.components.DaneshinoEmptyState
import com.example.ui.components.PillBadge
import com.example.ui.components.ScreenHeader
import com.example.ui.viewmodel.DaneshinoDataState

@Composable
fun AttachmentsScreen(
    state: DaneshinoDataState,
    initialCourseId: Long?,
    onAddAttachment: (CourseAttachmentEntity) -> Unit,
    onDeleteAttachment: (Long) -> Unit,
    onMessage: (String) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedCourseId by remember(initialCourseId, state.courses) {
        mutableStateOf(initialCourseId ?: state.courses.firstOrNull()?.id)
    }
    var deletingItem by remember { mutableStateOf<CourseAttachmentEntity?>(null) }

    fun queryDisplayName(uri: Uri): String {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        } catch (_: Exception) {
            null
        } ?: uri.lastPathSegment ?: "فایل پیوست"
    }

    // SAF document picker (PDF, text, etc.) — zero broad storage permissions!
    val documentPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        val targetCourseId = selectedCourseId
        if (uri != null && targetCourseId != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Some providers do not support persistable URI grants; still save metadata
            }
            val mime = context.contentResolver.getType(uri).orEmpty()
            val name = queryDisplayName(uri)
            onAddAttachment(
                CourseAttachmentEntity(
                    courseId = targetCourseId,
                    displayName = name,
                    uriString = uri.toString(),
                    mimeType = mime,
                    attachmentType = AttachmentType.fromMimeType(mime).name
                )
            )
        }
    }

    // Android Photo Picker — zero storage permissions!
    val photoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        val targetCourseId = selectedCourseId
        if (uri != null && targetCourseId != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
                // Safe fallback
            }
            val mime = context.contentResolver.getType(uri) ?: "image/*"
            val name = queryDisplayName(uri)
            onAddAttachment(
                CourseAttachmentEntity(
                    courseId = targetCourseId,
                    displayName = name,
                    uriString = uri.toString(),
                    mimeType = mime,
                    attachmentType = AttachmentType.IMAGE.name
                )
            )
        }
    }

    deletingItem?.let { target ->
        ConfirmDeleteDialog(
            title = "حذف پیوست",
            body = "آیا از حذف پیوست «${target.displayName}» از فهرست این درس مطمئن هستید؟ (فایل اصلی روی گوشی شما پاک نمی‌شود.)",
            onConfirm = {
                onDeleteAttachment(target.id)
                deletingItem = null
            },
            onDismiss = { deletingItem = null }
        )
    }

    val filteredAttachments = remember(state.attachments, selectedCourseId) {
        if (selectedCourseId == null) state.attachments
        else state.attachments.filter { it.courseId == selectedCourseId }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
    ) {
        ScreenHeader(
            title = "فایل‌های درسی",
            subtitle = "پیوست PDF، تصویر و فایل متنی بدون نیاز به مجوز حافظه",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (state.courses.isEmpty()) {
                item {
                    DaneshinoEmptyState(
                        icon = Icons.Default.AttachFile,
                        title = "ابتدا یک درس اضافه کنید",
                        subtitle = "برای پیوست کردن جزوه‌ها، PDFها و تصاویر، ابتدا باید حداقل یک درس ثبت کرده باشید."
                    )
                }
            } else {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("انتخاب درس", style = MaterialTheme.typography.labelLarge)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(state.courses, key = { it.id }) { course ->
                                FilterChip(
                                    selected = selectedCourseId == course.id,
                                    onClick = { selectedCourseId = course.id },
                                    label = { Text(course.name) }
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    documentPickerLauncher.launch(
                                        arrayOf("application/pdf", "text/plain", "text/*")
                                    )
                                },
                                enabled = selectedCourseId != null,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("پیوست PDF / متن")
                            }
                            FilledTonalButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                enabled = selectedCourseId != null,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Image, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("پیوست تصویر")
                            }
                        }
                    }
                }

                if (filteredAttachments.isEmpty()) {
                    item {
                        DaneshinoEmptyState(
                            icon = Icons.Default.AttachFile,
                            title = "فایلی برای این درس پیوست نشده است",
                            subtitle = "از دکمه‌های بالا برای افزودن جزوه PDF، فایل متنی یا عکس تخته و کتاب استفاده کنید."
                        )
                    }
                } else {
                    items(filteredAttachments, key = { it.id }) { item ->
                        val type = AttachmentType.fromName(item.attachmentType)
                        val icon = when (type) {
                            AttachmentType.PDF -> Icons.Default.PictureAsPdf
                            AttachmentType.IMAGE -> Icons.Default.Image
                            AttachmentType.TEXT -> Icons.Default.Description
                            AttachmentType.OTHER -> Icons.Default.AttachFile
                        }
                        DaneshinoCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.displayName, style = MaterialTheme.typography.titleSmall)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        PillBadge(
                                            text = type.persianLabel,
                                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                        Text(
                                            text = PersianDateUtil.formatShortShamsiDate(item.addedAtMillis),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = {
                                        try {
                                            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                                                setDataAndType(
                                                    Uri.parse(item.uriString),
                                                    item.mimeType.ifBlank { "*/*" }
                                                )
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(viewIntent)
                                        } catch (_: Exception) {
                                            onMessage("برنامه‌ای برای باز کردن این فایل یافت نشد یا دسترسی فایل تغییر کرده است.")
                                        }
                                    },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "باز کردن فایل")
                                }
                                IconButton(
                                    onClick = { deletingItem = item },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف پیوست", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
