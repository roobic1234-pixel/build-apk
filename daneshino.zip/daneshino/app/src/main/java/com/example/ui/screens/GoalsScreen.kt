package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.core.PersianDateUtil
import com.example.data.local.CourseEntity
import com.example.data.local.GoalEntity
import com.example.data.local.GoalPeriod
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.DaneshinoCard
import com.example.ui.components.DaneshinoEmptyState
import com.example.ui.components.PillBadge
import com.example.ui.components.ScreenHeader
import com.example.ui.viewmodel.DaneshinoDataState

@Composable
fun GoalsScreen(
    state: DaneshinoDataState,
    nowMillis: Long,
    onSaveGoal: (GoalEntity) -> Unit,
    onDeleteGoal: (Long) -> Unit,
    onBack: () -> Unit
) {
    var showEditor by remember { mutableStateOf(false) }
    var editingGoal by remember { mutableStateOf<GoalEntity?>(null) }
    var deletingGoal by remember { mutableStateOf<GoalEntity?>(null) }

    if (showEditor || editingGoal != null) {
        GoalEditorDialog(
            existing = editingGoal,
            courses = state.courses,
            onSave = {
                onSaveGoal(it)
                showEditor = false
                editingGoal = null
            },
            onDismiss = {
                showEditor = false
                editingGoal = null
            }
        )
    }

    deletingGoal?.let { target ->
        ConfirmDeleteDialog(
            title = "حذف هدف",
            body = "آیا از حذف هدف «${target.title}» مطمئن هستید؟",
            onConfirm = {
                onDeleteGoal(target.id)
                deletingGoal = null
            },
            onDismiss = { deletingGoal = null }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
    ) {
        ScreenHeader(
            title = "اهداف مطالعه",
            subtitle = "اهداف روزانه، هفتگی و ماهانه با پیشرفت واقعی",
            onBack = onBack,
            actions = {
                IconButton(
                    onClick = { showEditor = true },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Default.Add, contentDescription = "افزودن هدف جدید")
                }
            }
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (state.goals.isEmpty()) {
                item {
                    DaneshinoEmptyState(
                        icon = Icons.Default.Flag,
                        title = "هنوز هدفی ثبت نکرده‌اید",
                        subtitle = "برای مثال هدف «۱۰ ساعت مطالعه در هفته» بسازید تا پیشرفت شما به‌صورت خودکار از جلسات مطالعه محاسبه شود.",
                        actionLabel = "ثبت اولین هدف",
                        onAction = { showEditor = true }
                    )
                }
            } else {
                items(state.goals, key = { it.id }) { goal ->
                    val period = GoalPeriod.fromName(goal.period)
                    val doneMinutes = state.studyMinutesForGoal(goal, nowMillis)
                    val progress = if (goal.targetMinutes > 0) {
                        (doneMinutes.toFloat() / goal.targetMinutes.toFloat()).coerceIn(0f, 1f)
                    } else 0f
                    val pct = (progress * 100).toInt()
                    val course = state.courseById(goal.courseId)

                    DaneshinoCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(goal.title, style = MaterialTheme.typography.titleMedium)
                                if (course != null) {
                                    Text(
                                        text = "درس: ${course.name}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            PillBadge(
                                text = period.persianLabel,
                                containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                                contentColor = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${PersianDateUtil.formatDurationMinutes(doneMinutes)} از ${PersianDateUtil.formatDurationMinutes(goal.targetMinutes)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${PersianDateUtil.formatInt(pct)}٪",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            IconButton(
                                onClick = { editingGoal = goal },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "ویرایش هدف", tint = MaterialTheme.colorScheme.primary)
                            }
                            IconButton(
                                onClick = { deletingGoal = goal },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف هدف", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun GoalEditorDialog(
    existing: GoalEntity?,
    courses: List<CourseEntity>,
    onSave: (GoalEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var period by remember { mutableStateOf(GoalPeriod.fromName(existing?.period ?: GoalPeriod.WEEKLY.name)) }
    var hoursText by remember {
        mutableStateOf(
            existing?.let { String.format("%.1f", it.targetMinutes / 60.0).removeSuffix(".0") } ?: "10"
        )
    }
    var selectedCourseId by remember { mutableStateOf(existing?.courseId) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "ثبت هدف جدید" else "ویرایش هدف") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; error = null },
                    label = { Text("عنوان هدف (مثلاً ۱۰ ساعت مطالعه در هفته) *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("دوره هدف", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    GoalPeriod.entries.forEach { p ->
                        FilterChip(
                            selected = period == p,
                            onClick = { period = p },
                            label = { Text(p.persianLabel) }
                        )
                    }
                }
                OutlinedTextField(
                    value = hoursText,
                    onValueChange = { hoursText = it; error = null },
                    label = { Text("مقدار هدف (ساعت) *") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                if (courses.isNotEmpty()) {
                    Text("مرتبط با درس (اختیاری)", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = selectedCourseId == null,
                            onClick = { selectedCourseId = null },
                            label = { Text("همه درس‌ها") }
                        )
                        courses.forEach { c ->
                            FilterChip(
                                selected = selectedCourseId == c.id,
                                onClick = { selectedCourseId = c.id },
                                label = { Text(c.name) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val h = hoursText.replace(",", ".").toDoubleOrNull()
                if (title.trim().isBlank()) {
                    error = "لطفاً عنوان هدف را وارد کنید."
                    return@Button
                }
                if (h == null || h <= 0.0) {
                    error = "مدت هدف باید بزرگ‌تر از صفر باشد."
                    return@Button
                }
                onSave(
                    GoalEntity(
                        id = existing?.id ?: 0L,
                        title = title.trim(),
                        period = period.name,
                        targetMinutes = (h * 60.0).toInt().coerceAtLeast(1),
                        courseId = selectedCourseId,
                        createdAtMillis = existing?.createdAtMillis ?: System.currentTimeMillis()
                    )
                )
            }) { Text("ذخیره") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}
