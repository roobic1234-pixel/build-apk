package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.PersianDateUtil
import com.example.data.backup.DaneshinoBackupPayload
import com.example.data.prefs.ReminderLeadTime
import com.example.data.prefs.ReminderMethod
import com.example.reminder.ReminderNotificationHelper
import com.example.ui.components.DaneshinoCard
import com.example.ui.components.ScreenHeader
import com.example.ui.theme.AppThemeMode
import com.example.ui.viewmodel.DaneshinoDataState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    state: DaneshinoDataState,
    isAlarmPlaying: Boolean,
    pendingRestorePayload: DaneshinoBackupPayload?,
    canScheduleExactAlarms: () -> Boolean,
    isDeviceSilencedOrDnd: () -> Boolean,
    onUpdateProfile: (String, String, String, String, String, Double) -> Unit,
    onSetThemeMode: (AppThemeMode) -> Unit,
    onSetClassRemindersEnabled: (Boolean) -> Unit,
    onSetClassReminderMinutes: (Int) -> Unit,
    onSetClassReminderMethod: (ReminderMethod) -> Unit,
    onSetAssignmentRemindersEnabled: (Boolean) -> Unit,
    onSetExamRemindersEnabled: (Boolean) -> Unit,
    onStopAlarmAudio: () -> Unit,
    onTestAlarm: () -> Unit,
    onSendTestNotification: () -> Unit,
    onBuildBackupJson: suspend () -> String,
    onInspectBackupJson: (String) -> Unit,
    onConfirmRestore: () -> Unit,
    onCancelRestore: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = state.preferences

    var showEditProfile by remember { mutableStateOf(false) }
    var notifPermissionGranted by remember {
        mutableStateOf(ReminderNotificationHelper.hasNotificationPermission(context))
    }

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        notifPermissionGranted = granted
        if (!granted) {
            onMessage("مجوز اعلان رد شد. می‌توانید از تنظیمات گوشی بخش اعلان‌های دانشینو آن را فعال کنید.")
        } else {
            onMessage("مجوز اعلان فعال شد.")
        }
    }

    val exportBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    val json = onBuildBackupJson()
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            out.write(json.toByteArray(Charsets.UTF_8))
                        }
                    }
                    onMessage("فایل پشتیبان با موفقیت ذخیره شد.")
                } catch (_: Exception) {
                    onMessage("خطا در ذخیره فایل پشتیبان.")
                }
            }
        }
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    val raw = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    }.orEmpty()
                    onInspectBackupJson(raw)
                } catch (_: Exception) {
                    onMessage("خطا در خواندن فایل انتخاب‌شده.")
                }
            }
        }
    }

    if (showEditProfile) {
        EditProfileDialog(
            state = state,
            onSave = { name, uni, major, degree, term, totalCredits ->
                onUpdateProfile(name, uni, major, degree, term, totalCredits)
                showEditProfile = false
            },
            onDismiss = { showEditProfile = false }
        )
    }

    // Confirmation dialog before overwriting data during restore
    pendingRestorePayload?.let { payload ->
        AlertDialog(
            onDismissRequest = onCancelRestore,
            title = { Text("تأیید بازیابی پشتیبان") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("فایل پشتیبان معتبر است و شامل اطلاعات زیر می‌باشد:")
                    Text("• درس‌ها: ${PersianDateUtil.formatInt(payload.courses.size)}")
                    Text("• تکالیف: ${PersianDateUtil.formatInt(payload.assignments.size)}")
                    Text("• امتحانات: ${PersianDateUtil.formatInt(payload.exams.size)}")
                    Text("• جلسات مطالعه: ${PersianDateUtil.formatInt(payload.studySessions.size)}")
                    Text("• یادداشت‌ها: ${PersianDateUtil.formatInt(payload.notes.size)}")
                    Text("• دسته‌های فلش‌کارت: ${PersianDateUtil.formatInt(payload.decks.size)}")
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "با تأیید، تمام داده‌های فعلی جایگزین اطلاعات این فایل می‌شوند. آیا ادامه می‌دهید؟",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = onConfirmRestore,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_restore_button")
                ) {
                    Text("تأیید و جایگزینی")
                }
            },
            dismissButton = {
                TextButton(onClick = onCancelRestore) { Text("انصراف") }
            }
        )
    }

    val totalStudyMinutes = remember(state.studySessions) {
        (state.studySessions.sumOf { it.durationSeconds } / 60L).toInt()
    }
    val gpaSummary = state.gpaSummary

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = stringResource(R.string.nav_profile),
            subtitle = "اطلاعات دانشجو، یادآوری‌ها، تم و پشتیبان‌گیری"
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Student Identity & Real Stats
            item {
                DaneshinoCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(56.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = prefs.studentName.ifBlank { "دانشجوی دانشینو" },
                                style = MaterialTheme.typography.titleMedium
                            )
                            val subInfo = listOf(prefs.major, prefs.degreeLevel, prefs.university)
                                .filter { it.isNotBlank() }
                                .joinToString(" • ")
                            Text(
                                text = subInfo.ifBlank { "برای تکمیل مشخصات دانشگاهی روی ویرایش بزنید" },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (prefs.currentTerm.isNotBlank()) {
                                Text(
                                    text = "ترم جاری: ${prefs.currentTerm}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        IconButton(
                            onClick = { showEditProfile = true },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("edit_profile_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "ویرایش پروفایل",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    HorizontalDivider()
                    Spacer(Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ProfileStatColumn(
                            label = "معدل کل",
                            value = gpaSummary.overallGpa?.let { PersianDateUtil.formatDecimal(it, 2) } ?: "—",
                            modifier = Modifier.weight(1f)
                        )
                        ProfileStatColumn(
                            label = "درس‌ها",
                            value = PersianDateUtil.formatInt(state.courses.size),
                            modifier = Modifier.weight(1f)
                        )
                        ProfileStatColumn(
                            label = "واحد گذرانده",
                            value = PersianDateUtil.formatCredits(gpaSummary.passedCredits),
                            modifier = Modifier.weight(1f)
                        )
                        ProfileStatColumn(
                            label = "زمان مطالعه",
                            value = PersianDateUtil.formatDurationMinutes(totalStudyMinutes),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // 2. Theme Selector (Light / Dark / System)
            item {
                DaneshinoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Palette, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("ظاهر و تم برنامه", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(12.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AppThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = prefs.themeMode == mode,
                                onClick = { onSetThemeMode(mode) },
                                label = { Text(mode.persianLabel) },
                                modifier = Modifier.testTag("theme_${mode.storageKey}")
                            )
                        }
                    }
                }
            }

            // 3. Class Start Reminder Settings (Rule 3)
            item {
                DaneshinoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Alarm, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.reminder_settings_title), style = MaterialTheme.typography.titleMedium)
                    }

                    Spacer(Modifier.height(12.dp))

                    // Master switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.reminder_enable_label),
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = prefs.classRemindersEnabled,
                            onCheckedChange = { enabled ->
                                if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notifPermissionGranted) {
                                    notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                onSetClassRemindersEnabled(enabled)
                            },
                            modifier = Modifier.testTag("class_reminder_master_switch")
                        )
                    }

                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = stringResource(R.string.reminder_lead_time_label),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))

                    // Strictly 60, 30, 25, 20, 15, 10 minutes
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ReminderLeadTime.allowedMinutes.forEach { mins ->
                            FilterChip(
                                selected = prefs.classReminderMinutesBefore == mins,
                                onClick = { onSetClassReminderMinutes(mins) },
                                label = { Text(ReminderLeadTime.formatLabel(mins)) },
                                modifier = Modifier.testTag("lead_time_$mins")
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = stringResource(R.string.reminder_method_label),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))

                    ReminderMethodOption(
                        title = stringResource(R.string.reminder_method_notification),
                        description = stringResource(R.string.reminder_method_notification_desc),
                        selected = prefs.classReminderMethod == ReminderMethod.NOTIFICATION,
                        onClick = { onSetClassReminderMethod(ReminderMethod.NOTIFICATION) },
                        testTag = "method_notification"
                    )
                    ReminderMethodOption(
                        title = stringResource(R.string.reminder_method_alarm),
                        description = stringResource(R.string.reminder_method_alarm_desc),
                        selected = prefs.classReminderMethod == ReminderMethod.AUDIO_ALARM,
                        onClick = { onSetClassReminderMethod(ReminderMethod.AUDIO_ALARM) },
                        testTag = "method_audio_alarm"
                    )
                    ReminderMethodOption(
                        title = stringResource(R.string.reminder_method_both),
                        description = stringResource(R.string.reminder_method_both_desc),
                        selected = prefs.classReminderMethod == ReminderMethod.BOTH,
                        onClick = { onSetClassReminderMethod(ReminderMethod.BOTH) },
                        testTag = "method_both"
                    )

                    Spacer(Modifier.height(12.dp))
                    HorizontalDivider()
                    Spacer(Modifier.height(12.dp))

                    // Additional toggles for Assignment & Exam notifications
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("یادآوری مهلت تکالیف", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = prefs.assignmentRemindersEnabled,
                            onCheckedChange = onSetAssignmentRemindersEnabled
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("یادآوری امتحانات", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = prefs.examRemindersEnabled,
                            onCheckedChange = onSetExamRemindersEnabled
                        )
                    }

                    Spacer(Modifier.height(12.dp))

                    // Test & Stop Audio Controls
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onStopAlarmAudio,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isAlarmPlaying) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.surfaceContainerHigh,
                                contentColor = if (isAlarmPlaying) MaterialTheme.colorScheme.onError else MaterialTheme.colorScheme.onSurface
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("stop_alarm_audio_button")
                        ) {
                            Icon(Icons.Default.StopCircle, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.reminder_stop_audio))
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilledTonalButton(
                                onClick = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notifPermissionGranted) {
                                        notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    } else {
                                        onTestAlarm()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("test_alarm_button")
                            ) {
                                Text(stringResource(R.string.reminder_test_alarm))
                            }
                            OutlinedButton(
                                onClick = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notifPermissionGranted) {
                                        notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    } else {
                                        onSendTestNotification()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("test_notification_button")
                            ) {
                                Text(stringResource(R.string.reminder_test_notification))
                            }
                        }
                    }

                    // Permission & system guidance (honest, never making unrealistic guarantees)
                    Spacer(Modifier.height(12.dp))
                    if (!notifPermissionGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        PermissionGuidanceBox(
                            text = "مجوز ارسال اعلان فعال نیست. برای دریافت یادآوری‌ها، مجوز اعلان را تأیید کنید.",
                            buttonLabel = "درخواست مجوز اعلان",
                            onClick = { notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !canScheduleExactAlarms()) {
                        PermissionGuidanceBox(
                            text = "مجوز زمان‌بندی دقیق (Exact Alarm) فعال نیست؛ ممکن است یادآوری‌ها با چند دقیقه تأخیر ارسال شوند.",
                            buttonLabel = "باز کردن تنظیمات آلارم دقیق",
                            onClick = {
                                try {
                                    context.startActivity(
                                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                            data = Uri.parse("package:${context.packageName}")
                                        }
                                    )
                                } catch (_: Exception) {
                                    onMessage("تنظیمات آلارم دقیق در این دستگاه در دسترس نیست.")
                                }
                            }
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    if (isDeviceSilencedOrDnd()) {
                        Text(
                            text = stringResource(R.string.reminder_silent_warning),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                        Spacer(Modifier.height(6.dp))
                    }
                    Text(
                        text = "نکته: بهینه‌سازی باتری گوشی (Doze) یا حالت بی‌صدا ممکن است بر دقت زمان‌بندی یا پخش صدا اثر بگذارد. در صورت نیاز می‌توانید دانشینو را در تنظیمات باتری گوشی روی حالت بدون محدودیت قرار دهید.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // 4. Backup & Restore (JSON with validation + confirmation + honest attachments notice)
            item {
                DaneshinoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Backup, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.backup_title), style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.backup_attachments_notice),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val fileName = "daneshino-backup-${PersianDateUtil.dateKey(System.currentTimeMillis())}.json"
                                exportBackupLauncher.launch(fileName)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("backup_export_button")
                        ) {
                            Icon(Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.backup_export), maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = { importBackupLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("backup_import_button")
                        ) {
                            Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.backup_import), maxLines = 1)
                        }
                    }
                }
            }

            // 5. AI Roadmap Info Card (Purely informational, multi-line wrapping, zero fake buttons, zero clipping)
            item {
                DaneshinoCard(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.roadmap_title),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.roadmap_body),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ProfileStatColumn(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun ReminderMethodOption(
    title: String,
    description: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.Top
    ) {
        RadioButton(
            selected = selected,
            onClick = onClick
        )
        Spacer(Modifier.width(6.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PermissionGuidanceBox(
    text: String,
    buttonLabel: String,
    onClick: () -> Unit
) {
    Surface(
        shape = MaterialTheme.shapes.small,
        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.65f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = text,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onClick) {
                Text(buttonLabel)
            }
        }
    }
}

@Composable
private fun EditProfileDialog(
    state: DaneshinoDataState,
    onSave: (String, String, String, String, String, Double) -> Unit,
    onDismiss: () -> Unit
) {
    val prefs = state.preferences
    var name by remember { mutableStateOf(prefs.studentName) }
    var university by remember { mutableStateOf(prefs.university) }
    var major by remember { mutableStateOf(prefs.major) }
    var degreeLevel by remember { mutableStateOf(prefs.degreeLevel) }
    var currentTerm by remember { mutableStateOf(prefs.currentTerm) }
    var totalCreditsText by remember { mutableStateOf(prefs.totalDegreeCredits.toInt().toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ویرایش مشخصات دانشجو") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام و نام خانوادگی") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = university,
                    onValueChange = { university = it },
                    label = { Text("دانشگاه") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = major,
                    onValueChange = { major = it },
                    label = { Text("رشته تحصیلی") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = degreeLevel,
                    onValueChange = { degreeLevel = it },
                    label = { Text("مقطع (کارشناسی، ارشد، ...)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = currentTerm,
                    onValueChange = { currentTerm = it },
                    label = { Text("ترم جاری") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = totalCreditsText,
                    onValueChange = { totalCreditsText = it },
                    label = { Text("کل واحدهای دوره تحصیلی") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val credits = totalCreditsText.toDoubleOrNull()?.coerceIn(1.0, 400.0) ?: 140.0
                onSave(name, university, major, degreeLevel, currentTerm, credits)
            }) { Text("ذخیره") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}
