package com.example.core

import kotlin.math.abs

data class GradedCourseInput(
    val name: String,
    val credits: Double,
    val grade: Double?,
    val term: String
)

data class GpaSummary(
    val overallGpa: Double?,
    val gradedCredits: Double,
    val passedCredits: Double,
    val totalRegisteredCredits: Double,
    val remainingCredits: Double,
    val termGpas: Map<String, Double>
)

sealed class TargetGpaResult {
    data class Achievable(
        val requiredAverage: Double,
        val explanation: String
    ) : TargetGpaResult()

    data class AlreadyAchieved(
        val requiredAverage: Double,
        val explanation: String
    ) : TargetGpaResult()

    data class Impossible(
        val requiredAverage: Double?,
        val explanation: String
    ) : TargetGpaResult()

    data class InvalidInput(
        val explanation: String
    ) : TargetGpaResult()
}

/**
 * Pure domain calculator for Iranian university 0..20 weighted GPA:
 * GPA = Σ(grade * credits) / Σ(credits).
 */
object GpaCalculator {

    const val MIN_GRADE = 0.0
    const val MAX_GRADE = 20.0
    const val PASSING_GRADE = 10.0

    fun calculateWeightedGpa(items: List<Pair<Double, Double>>): Double? {
        val valid = items.filter { (grade, credits) ->
            credits > 0.0 && grade in MIN_GRADE..MAX_GRADE
        }
        val totalCredits = valid.sumOf { it.second }
        if (totalCredits <= 0.0) return null
        val weightedSum = valid.sumOf { it.first * it.second }
        return weightedSum / totalCredits
    }

    fun calculateSummary(
        courses: List<GradedCourseInput>,
        totalDegreeCredits: Double
    ): GpaSummary {
        val validGraded = courses.filter { it.credits > 0.0 && it.grade != null && it.grade in MIN_GRADE..MAX_GRADE }
        val overallGpa = calculateWeightedGpa(validGraded.map { (it.grade ?: 0.0) to it.credits })
        val gradedCredits = validGraded.sumOf { it.credits }
        val passedCredits = validGraded
            .filter { (it.grade ?: 0.0) >= PASSING_GRADE }
            .sumOf { it.credits }
        val totalRegistered = courses.filter { it.credits > 0.0 }.sumOf { it.credits }
        val remaining = (totalDegreeCredits - passedCredits).coerceAtLeast(0.0)

        val termGpas = validGraded
            .groupBy { it.term.ifBlank { "بدون ترم" } }
            .mapValuesNotNull { (_, termCourses) ->
                calculateWeightedGpa(termCourses.map { (it.grade ?: 0.0) to it.credits })
            }

        return GpaSummary(
            overallGpa = overallGpa,
            gradedCredits = gradedCredits,
            passedCredits = passedCredits,
            totalRegisteredCredits = totalRegistered,
            remainingCredits = remaining,
            termGpas = termGpas
        )
    }

    /**
     * Computes the required average grade across [upcomingCredits] to achieve [targetGpa]
     * given [currentGpa] over [completedCredits].
     */
    fun calculateRequiredAverage(
        currentGpa: Double,
        completedCredits: Double,
        upcomingCredits: Double,
        targetGpa: Double
    ): TargetGpaResult {
        if (targetGpa !in MIN_GRADE..MAX_GRADE) {
            return TargetGpaResult.InvalidInput("معدل هدف باید بین ۰ تا ۲۰ باشد.")
        }
        if (completedCredits < 0.0) {
            return TargetGpaResult.InvalidInput("تعداد واحدهای گذرانده نمی‌تواند منفی باشد.")
        }
        if (completedCredits > 0.0 && currentGpa !in MIN_GRADE..MAX_GRADE) {
            return TargetGpaResult.InvalidInput("معدل فعلی باید بین ۰ تا ۲۰ باشد.")
        }
        if (upcomingCredits <= 0.0) {
            return TargetGpaResult.InvalidInput("تعداد واحدهای پیش‌رو باید بزرگ‌تر از صفر باشد.")
        }

        val totalCredits = completedCredits + upcomingCredits
        val neededTotalPoints = targetGpa * totalCredits
        val currentPoints = if (completedCredits == 0.0) 0.0 else currentGpa * completedCredits
        val requiredAvg = (neededTotalPoints - currentPoints) / upcomingCredits

        val formattedReq = PersianDateUtil.formatDecimal(requiredAvg, 2)
        val formattedTarget = PersianDateUtil.formatDecimal(targetGpa, 2)
        val formattedUpcoming = PersianDateUtil.formatCredits(upcomingCredits)

        return when {
            requiredAvg > MAX_GRADE + 1e-6 -> {
                val maxPossible = (currentPoints + MAX_GRADE * upcomingCredits) / totalCredits
                val maxFormatted = PersianDateUtil.formatDecimal(maxPossible, 2)
                TargetGpaResult.Impossible(
                    requiredAverage = requiredAvg,
                    explanation = "رسیدن به معدل $formattedTarget از نظر ریاضی ممکن نیست؛ زیرا برای $formattedUpcoming واحد آینده به میانگین $formattedReq (بیشتر از ۲۰) نیاز است. حتی با کسب نمره ۲۰ در همه واحدهای آینده، بیشترین معدل ممکن شما $maxFormatted خواهد بود."
                )
            }
            requiredAvg <= MIN_GRADE + 1e-6 -> {
                TargetGpaResult.AlreadyAchieved(
                    requiredAverage = 0.0,
                    explanation = "حتی با کمترین نمره ممکن نیز معدل شما از $formattedTarget بالاتر می‌ماند. برای حفظ کیفیت تحصیلی همچنان به نمره قبولی (۱۰ به بالا) توجه کنید."
                )
            }
            else -> {
                val cleanReq = if (abs(requiredAvg) < 1e-9) 0.0 else requiredAvg
                val note = if (cleanReq < PASSING_GRADE) {
                    " (توجه: برای قبولی در درس‌ها حداقل نمره ۱۰ لازم است.)"
                } else ""
                TargetGpaResult.Achievable(
                    requiredAverage = cleanReq,
                    explanation = "برای رسیدن به معدل کل $formattedTarget، باید در $formattedUpcoming واحد آینده میانگین نمره $formattedReq از ۲۰ کسب کنید.$note"
                )
            }
        }
    }

    private inline fun <K, V, R : Any> Map<K, V>.mapValuesNotNull(transform: (Map.Entry<K, V>) -> R?): Map<K, R> {
        val result = LinkedHashMap<K, R>()
        for (entry in this) {
            val mapped = transform(entry)
            if (mapped != null) result[entry.key] = mapped
        }
        return result
    }
}
