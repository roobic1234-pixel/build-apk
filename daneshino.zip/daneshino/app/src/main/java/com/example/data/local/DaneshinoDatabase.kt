package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration

/**
 * Daneshino Room database.
 * - Fixed database name: "daneshino_db" (never change across releases).
 * - exportSchema = true for safe forward migrations.
 * - Zero prepopulation callbacks: fresh installs always start completely empty.
 * - fallbackToDestructiveMigration is strictly forbidden.
 */
@Database(
    entities = [
        CourseEntity::class,
        ClassSessionEntity::class,
        AssignmentEntity::class,
        ExamEntity::class,
        StudySessionEntity::class,
        GoalEntity::class,
        FlashcardDeckEntity::class,
        FlashcardEntity::class,
        NoteEntity::class,
        CourseAttachmentEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class DaneshinoDatabase : RoomDatabase() {
    abstract fun daneshinoDao(): DaneshinoDao

    companion object {
        const val DATABASE_NAME = "daneshino_db"

        /** Register future explicit Room migrations here when bumping schema version. */
        val MIGRATIONS: Array<Migration> = emptyArray()

        @Volatile
        private var instance: DaneshinoDatabase? = null

        fun getInstance(context: Context): DaneshinoDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    DaneshinoDatabase::class.java,
                    DATABASE_NAME
                )
                    .addMigrations(*MIGRATIONS)
                    .build()
                    .also { instance = it }
            }
        }
    }
}
