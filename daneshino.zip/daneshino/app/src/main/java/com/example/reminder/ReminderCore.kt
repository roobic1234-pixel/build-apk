package com.example.reminder

import com.example.core.PersianDateUtil
import com.example.data.local.AssignmentEntity
import com.example.data.local.ClassSessionEntity
import com.example.data.local.CourseEntity
import com.example.data.local.ExamEntity
import com.example.data.prefs.UserPreferences
import java.util.Calendar
import java.util.TimeZone

object ReminderIds {
    const val CHANNEL_CLASS = "daneshino_class_reminders"
    const val CHANNEL_TASK = "daneshino_task_reminders"
    const val CHANNEL_ALARM = "daneshino_alarm_service"

    const val ALARM_SERVICE_NOTIFICATION_ID = 900_001
    const val TEST_NOTIFICATION_ID = 900_002

    fun classRequestCode(sessionId: Long): Int =
        100_000 + ((sessionId and 0x0001FFFFL).toInt())

    fun assignmentRequestCode(assignmentId: Long): Int =
        300_000 + ((assignmentId and 0x0001FFFFL).toInt())

    fun examRequestCode(examId: Long): Int =
        500_000 + ((examId and 0x0001FFFFL).toInt())
}

interface ReminderController {
    fun scheduleClassSessionReminder(
        session: ClassSessionEntity,
        course: CourseEntity,
        prefs: UserPreferences
    )

    fun cancelClassSessionReminder(sessionId: Long)

    fun scheduleAssignmentReminder(assignment: AssignmentEntity, courseName: String)
    fun cancelAssignmentReminder(assignmentId: Long)

    fun scheduleExamReminder(exam: ExamEntity, courseName: String)
    fun cancelExamReminder(examId: Long)

    fun triggerTestAlarm()
    fun sendTestNotification()
    fun stopAlarmAudio()
    fun stopAlarmIfSessionMatches(sessionId: Long)
    fun canScheduleExactAlarms(): Boolean
    fun isDeviceSilencedOrDnd(): Boolean
}

/**
 * Pure, deterministic trigger time calculator using local TimeZone.
 * Guarantees past timestamps are NEVER scheduled to fire immediately.
 */
object ReminderTriggerCalculator {

    private const val ONE_WEEK_MILLIS = 7L * 24L * 60L * 60L * 1000L

    /**
     * Computes the next strictly-future trigger epoch millis for a class session.
     * Returns null if non-repeating and already in the past.
     */
    fun nextClassTriggerMillis(
        dayOfWeekPersian: Int,
        startMinuteOfDay: Int,
        leadMinutesBefore: Int,
        repeatWeekly: Boolean,
        nowMillis: Long = System.currentTimeMillis(),
        timeZone: TimeZone = TimeZone.getDefault()
    ): Long? {
        val targetJavaDow = PersianDateUtil.persianIndexToJavaDayOfWeek(dayOfWeekPersian)
        val cal = Calendar.getInstance(timeZone).apply {
            timeInMillis = nowMillis
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val currentJavaDow = cal.get(Calendar.DAY_OF_WEEK)
        var daysDiff = targetJavaDow - currentJavaDow
        if (daysDiff < 0) daysDiff += 7

        cal.add(Calendar.DAY_OF_YEAR, daysDiff)
        cal.set(Calendar.HOUR_OF_DAY, (startMinuteOfDay / 60).coerceIn(0, 23))
        cal.set(Calendar.MINUTE, (startMinuteOfDay % 60).coerceIn(0, 59))

        val classStartMillis = cal.timeInMillis
        val triggerMillis = classStartMillis - leadMinutesBefore * 60_000L

        if (triggerMillis > nowMillis + 1_000L) {
            return triggerMillis
        }
        return if (repeatWeekly) {
            triggerMillis + ONE_WEEK_MILLIS
        } else {
            null
        }
    }

    /**
     * Computes trigger millis for a one-off assignment/exam reminder.
     * Returns null if reminder is disabled or the trigger time is already in the past.
     */
    fun oneShotTriggerMillis(
        eventAtMillis: Long,
        reminderMinutesBefore: Int?,
        nowMillis: Long = System.currentTimeMillis()
    ): Long? {
        if (reminderMinutesBefore == null || reminderMinutesBefore < 0) return null
        val trigger = eventAtMillis - reminderMinutesBefore * 60_000L
        return if (trigger > nowMillis + 1_000L) trigger else null
    }
}
