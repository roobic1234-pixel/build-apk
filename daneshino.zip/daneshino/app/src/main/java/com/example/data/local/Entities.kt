package com.example.data.local

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

enum class AssignmentPriority(val persianLabel: String, val sortRank: Int) {
    LOW("کم", 1),
    MEDIUM("متوسط", 2),
    HIGH("زیاد", 3),
    CRITICAL("بحرانی", 4);

    companion object {
        fun fromName(name: String): AssignmentPriority =
            entries.firstOrNull { it.name == name } ?: MEDIUM
    }
}

enum class AssignmentStatus(val persianLabel: String) {
    NOT_STARTED("شروع‌نشده"),
    IN_PROGRESS("در حال انجام"),
    COMPLETED("انجام‌شده");

    companion object {
        fun fromName(name: String): AssignmentStatus =
            entries.firstOrNull { it.name == name } ?: NOT_STARTED
    }
}

enum class GoalPeriod(val persianLabel: String) {
    DAILY("روزانه"),
    WEEKLY("هفتگی"),
    MONTHLY("ماهانه");

    companion object {
        fun fromName(name: String): GoalPeriod =
            entries.firstOrNull { it.name == name } ?: WEEKLY
    }
}

enum class AttachmentType(val persianLabel: String) {
    PDF("PDF"),
    IMAGE("تصویر"),
    TEXT("متن"),
    OTHER("سایر");

    companion object {
        fun fromMimeType(mimeType: String?): AttachmentType = when {
            mimeType == null -> OTHER
            mimeType.contains("pdf", ignoreCase = true) -> PDF
            mimeType.startsWith("image/", ignoreCase = true) -> IMAGE
            mimeType.startsWith("text/", ignoreCase = true) -> TEXT
            else -> OTHER
        }

        fun fromName(name: String): AttachmentType =
            entries.firstOrNull { it.name == name } ?: OTHER
    }
}

@Entity(tableName = "courses")
data class CourseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val code: String = "",
    val credits: Double = 3.0,
    val instructorName: String = "",
    val instructorEmail: String = "",
    val instructorPhone: String = "",
    val instructorOffice: String = "",
    val instructorNotes: String = "",
    val term: String = "",
    val courseType: String = "تخصصی",
    val colorArgb: Int = 0xFF3B82F6.toInt(),
    val description: String = "",
    val isFavorite: Boolean = false,
    val grade: Double? = null,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "class_sessions",
    foreignKeys = [
        ForeignKey(
            entity = CourseEntity::class,
            parentColumns = ["id"],
            childColumns = ["courseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("courseId")]
)
data class ClassSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseId: Long,
    /** 0 = Saturday .. 6 = Friday */
    val dayOfWeek: Int,
    val startMinuteOfDay: Int,
    val endMinuteOfDay: Int,
    val roomNumber: String = "",
    val building: String = "",
    val notes: String = "",
    val repeatWeekly: Boolean = true
)

data class CourseWithSessions(
    @Embedded val course: CourseEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "courseId"
    )
    val sessions: List<ClassSessionEntity>
)

data class SessionWithCourse(
    @Embedded val session: ClassSessionEntity,
    @Relation(
        parentColumn = "courseId",
        entityColumn = "id"
    )
    val course: CourseEntity?
)

@Entity(
    tableName = "assignments",
    foreignKeys = [
        ForeignKey(
            entity = CourseEntity::class,
            parentColumns = ["id"],
            childColumns = ["courseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("courseId")]
)
data class AssignmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseId: Long? = null,
    val title: String,
    val description: String = "",
    val dueAtMillis: Long,
    val priority: String = AssignmentPriority.MEDIUM.name,
    val status: String = AssignmentStatus.NOT_STARTED.name,
    /** Minutes before dueAtMillis to remind; null disables reminder for this assignment. */
    val reminderMinutesBefore: Int? = null,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "exams",
    foreignKeys = [
        ForeignKey(
            entity = CourseEntity::class,
            parentColumns = ["id"],
            childColumns = ["courseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("courseId")]
)
data class ExamEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseId: Long? = null,
    val title: String,
    val examAtMillis: Long,
    val location: String = "",
    val syllabus: String = "",
    val notes: String = "",
    /** Minutes before examAtMillis to remind; null disables reminder. */
    val reminderMinutesBefore: Int? = 60,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "study_sessions",
    foreignKeys = [
        ForeignKey(
            entity = CourseEntity::class,
            parentColumns = ["id"],
            childColumns = ["courseId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("courseId")]
)
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseId: Long? = null,
    val courseNameSnapshot: String = "",
    val startAtMillis: Long,
    val endAtMillis: Long,
    val durationSeconds: Long,
    val dateKey: String
)

@Entity(
    tableName = "goals",
    foreignKeys = [
        ForeignKey(
            entity = CourseEntity::class,
            parentColumns = ["id"],
            childColumns = ["courseId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("courseId")]
)
data class GoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val period: String = GoalPeriod.WEEKLY.name,
    val targetMinutes: Int,
    val courseId: Long? = null,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "flashcard_decks",
    foreignKeys = [
        ForeignKey(
            entity = CourseEntity::class,
            parentColumns = ["id"],
            childColumns = ["courseId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("courseId")]
)
data class FlashcardDeckEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val courseId: Long? = null,
    val description: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "flashcards",
    foreignKeys = [
        ForeignKey(
            entity = FlashcardDeckEntity::class,
            parentColumns = ["id"],
            childColumns = ["deckId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("deckId")]
)
data class FlashcardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deckId: Long,
    val front: String,
    val back: String,
    val knownCount: Int = 0,
    val reviewCount: Int = 0,
    val lastReviewedAtMillis: Long? = null
)

@Entity(
    tableName = "notes",
    foreignKeys = [
        ForeignKey(
            entity = CourseEntity::class,
            parentColumns = ["id"],
            childColumns = ["courseId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("courseId")]
)
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseId: Long? = null,
    val title: String,
    val content: String,
    val category: String = "عمومی",
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "course_attachments",
    foreignKeys = [
        ForeignKey(
            entity = CourseEntity::class,
            parentColumns = ["id"],
            childColumns = ["courseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("courseId")]
)
data class CourseAttachmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseId: Long,
    val displayName: String,
    val uriString: String,
    val mimeType: String = "",
    val attachmentType: String = AttachmentType.OTHER.name,
    val addedAtMillis: Long = System.currentTimeMillis()
)
