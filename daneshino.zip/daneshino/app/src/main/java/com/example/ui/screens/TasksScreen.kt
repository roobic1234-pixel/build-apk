package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.PersianDateUtil
import com.example.data.local.AssignmentEntity
import com.example.data.local.AssignmentPriority
import com.example.data.local.AssignmentStatus
import com.example.data.local.CourseEntity
import com.example.data.local.ExamEntity
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.DaneshinoCard
import com.example.ui.components.DaneshinoEmptyState
import com.example.ui.components.PillBadge
import com.example.ui.components.ScreenHeader
import com.example.ui.components.ShamsiDateTimePickerDialog
import com.example.ui.theme.DaneshinoAmber
import com.example.ui.theme.DaneshinoBlue
import com.example.ui.theme.DaneshinoCoral
import com.example.ui.theme.DaneshinoTeal
import com.example.ui.viewmodel.DaneshinoDataState

private enum class TaskFilterMode(val label: String) {
    ALL("همه"),
    ACTIVE("در حال انجام"),
    COMPLETED("انجام‌شده")
}

private enum class TaskSortMode(val label: String) {
    DUE_DATE("مهلت"),
    PRIORITY("اولویت")
}

@Composable
fun TasksScreen(
    state: DaneshinoDataState,
    nowMillis: Long,
    onSaveAssignment: (AssignmentEntity) -> Unit,
    onDeleteAssignment: (Long) -> Unit,
    onSaveExam: (ExamEntity) -> Unit,
    onDeleteExam: (Long) -> Unit,
    showAddDialogExternal: Boolean,
    onDismissAddDialogExternal: () -> Unit
) {
    // 0 = Assignments, 1 = Exams
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var filterMode by rememberSaveable { mutableStateOf(TaskFilterMode.ALL) }
    var sortMode by rememberSaveable { mutableStateOf(TaskSortMode.DUE_DATE) }

    var editingAssignment by remember { mutableStateOf<AssignmentEntity?>(null) }
    var showAddAssignment by remember { mutableStateOf(false) }
    var deletingAssignment by remember { mutableStateOf<AssignmentEntity?>(null) }

    var editingExam by remember { mutableStateOf<ExamEntity?>(null) }
    var showAddExam by remember { mutableStateOf(false) }
    var deletingExam by remember { mutableStateOf<ExamEntity?>(null) }

    if (showAddDialogExternal) {
        if (selectedTab == 0) showAddAssignment = true else showAddExam = true
        onDismissAddDialogExternal()
    }

    if (showAddAssignment || editingAssignment != null) {
        AssignmentEditorDialog(
            existing = editingAssignment,
            courses = state.courses,
            onSave = {
                onSaveAssignment(it)
                showAddAssignment = false
                editingAssignment = null
            },
            onDismiss = {
                showAddAssignment = false
                editingAssignment = null
            }
        )
    }

    if (showAddExam || editingExam != null) {
        ExamEditorDialog(
            existing = editingExam,
            courses = state.courses,
            onSave = {
                onSaveExam(it)
                showAddExam = false
                editingExam = null
            },
            onDismiss = {
                showAddExam = false
                editingExam = null
            }
        )
    }

    deletingAssignment?.let { target ->
        ConfirmDeleteDialog(
            title = "حذف تکلیف",
            body = "آیا از حذف تکلیف «${target.title}» مطمئن هستید؟ یادآوری آن نیز لغو خواهد شد.",
            onConfirm = {
                onDeleteAssignment(target.id)
                deletingAssignment = null
            },
            onDismiss = { deletingAssignment = null }
        )
    }

    deletingExam?.let { target ->
        ConfirmDeleteDialog(
            title = "حذف امتحان",
            body = "آیا از حذف امتحان «${target.title}» مطمئن هستید؟ یادآوری آن نیز لغو خواهد شد.",
            onConfirm = {
                onDeleteExam(target.id)
                deletingExam = null
            },
            onDismiss = { deletingExam = null }
        )
    }

    val filteredAssignments = remember(state.assignments, searchQuery, filterMode, sortMode) {
        val q = searchQuery.trim().lowercase()
        val list = state.assignments.filter { item ->
            val matchesFilter = when (filterMode) {
                TaskFilterMode.ALL -> true
                TaskFilterMode.ACTIVE -> item.status != AssignmentStatus.COMPLETED.name
                TaskFilterMode.COMPLETED -> item.status == AssignmentStatus.COMPLETED.name
            }
            val matchesQuery = q.isEmpty() ||
                item.title.lowercase().contains(q) ||
                item.description.lowercase().contains(q)
            matchesFilter && matchesQuery
        }
        when (sortMode) {
            TaskSortMode.DUE_DATE -> list.sortedBy { it.dueAtMillis }
            TaskSortMode.PRIORITY -> list.sortedByDescending { AssignmentPriority.fromName(it.priority).sortRank }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = stringResource(R.string.nav_tasks),
            subtitle = if (selectedTab == 0) {
                "مدیریت تکالیف و پروژه‌ها"
            } else {
                "برنامه امتحانات و شمارش معکوس"
            }
        )

        // Two-tab switcher: Assignments | Exams
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surfaceContainerHigh
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    stringResource(R.string.tasks_tab_assignments),
                    stringResource(R.string.tasks_tab_exams)
                ).forEachIndexed { idx, label ->
                    val selected = selectedTab == idx
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(MaterialTheme.shapes.small)
                            .clickable { selectedTab = idx }
                            .testTag(if (idx == 0) "tasks_tab_assignments" else "tasks_tab_exams"),
                        shape = MaterialTheme.shapes.small,
                        color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        if (selectedTab == 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 92.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (state.assignments.isEmpty()) {
                    item {
                        DaneshinoEmptyState(
                            icon = Icons.AutoMirrored.Filled.Assignment,
                            title = stringResource(R.string.assignments_empty_title),
                            subtitle = stringResource(R.string.assignments_empty_subtitle),
                            actionLabel = stringResource(R.string.assignments_add_first),
                            onAction = { showAddAssignment = true },
                            actionTestTag = "assignments_add_first_button"
                        )
                    }
                } else {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("جستجو در تکالیف...") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "جستجو") },
                                singleLine = true,
                                shape = MaterialTheme.shapes.medium,
                                modifier = Modifier.fillMaxWidth()
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(TaskFilterMode.entries) { mode ->
                                    FilterChip(
                                        selected = filterMode == mode,
                                        onClick = { filterMode = mode },
                                        label = { Text(mode.label) }
                                    )
                                }
                                items(TaskSortMode.entries) { sm ->
                                    FilterChip(
                                        selected = sortMode == sm,
                                        onClick = { sortMode = sm },
                                        label = { Text("مرتب: ${sm.label}") }
                                    )
                                }
                            }
                        }
                    }

                    items(filteredAssignments, key = { it.id }) { task ->
                        val isDone = task.status == AssignmentStatus.COMPLETED.name
                        val priority = AssignmentPriority.fromName(task.priority)
                        val course = state.courseById(task.courseId)
                        DaneshinoCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Top
                            ) {
                                IconButton(
                                    onClick = {
                                        val nextStatus = if (isDone) AssignmentStatus.IN_PROGRESS else AssignmentStatus.COMPLETED
                                        onSaveAssignment(task.copy(status = nextStatus.name))
                                    },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("assignment_toggle_${task.id}")
                                ) {
                                    Icon(
                                        imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                        contentDescription = if (isDone) "تکمیل‌شده" else "علامت‌گذاری به عنوان انجام‌شده",
                                        tint = if (isDone) DaneshinoTeal else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = task.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        textDecoration = if (isDone) TextDecoration.LineThrough else TextDecoration.None,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    if (course != null) {
                                        Text(
                                            text = course.name,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    if (task.description.isNotBlank()) {
                                        Spacer(Modifier.height(4.dp))
                                        Text(
                                            text = task.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        val pColor = when (priority) {
                                            AssignmentPriority.LOW -> DaneshinoTeal
                                            AssignmentPriority.MEDIUM -> DaneshinoBlue
                                            AssignmentPriority.HIGH -> DaneshinoAmber
                                            AssignmentPriority.CRITICAL -> DaneshinoCoral
                                        }
                                        PillBadge(
                                            text = "اولویت: ${priority.persianLabel}",
                                            containerColor = pColor.copy(alpha = 0.16f),
                                            contentColor = pColor
                                        )
                                        PillBadge(
                                            text = "${PersianDateUtil.formatShortShamsiDate(task.dueAtMillis)} • ${PersianDateUtil.formatTimeFromMillis(task.dueAtMillis)}",
                                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                IconButton(
                                    onClick = { editingAssignment = task },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "ویرایش تکلیف", tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(
                                    onClick = { deletingAssignment = task },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف تکلیف", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Exams Tab — unified clean empty state & cards in both Light and Dark themes
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 92.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (state.exams.isEmpty()) {
                    item {
                        DaneshinoEmptyState(
                            icon = Icons.Default.Event,
                            title = stringResource(R.string.exams_empty_title),
                            subtitle = stringResource(R.string.exams_empty_subtitle),
                            actionLabel = stringResource(R.string.exams_add_first),
                            onAction = { showAddExam = true },
                            actionTestTag = "exams_add_first_button"
                        )
                    }
                } else {
                    items(state.exams, key = { it.id }) { exam ->
                        val course = state.courseById(exam.courseId)
                        DaneshinoCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(exam.title, style = MaterialTheme.typography.titleMedium)
                                    if (course != null) {
                                        Text(
                                            text = course.name,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                Spacer(Modifier.width(8.dp))
                                PillBadge(
                                    text = PersianDateUtil.formatDaysUntilExam(exam.examAtMillis, nowMillis),
                                    containerColor = MaterialTheme.colorScheme.errorContainer,
                                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "زمان: ${PersianDateUtil.formatFullShamsiDate(exam.examAtMillis)} ساعت ${PersianDateUtil.formatTimeFromMillis(exam.examAtMillis)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (exam.location.isNotBlank()) {
                                Text(
                                    text = "مکان: ${exam.location}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (exam.syllabus.isNotBlank()) {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "سرفصل‌ها: ${exam.syllabus}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            if (exam.notes.isNotBlank()) {
                                Text(
                                    text = "یادداشت: ${exam.notes}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                IconButton(
                                    onClick = { editingExam = exam },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "ویرایش امتحان", tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(
                                    onClick = { deletingExam = exam },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف امتحان", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AssignmentEditorDialog(
    existing: AssignmentEntity?,
    courses: List<CourseEntity>,
    onSave: (AssignmentEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var description by remember { mutableStateOf(existing?.description ?: "") }
    var selectedCourseId by remember { mutableStateOf(existing?.courseId) }
    var dueAtMillis by remember { mutableLongStateOf(existing?.dueAtMillis ?: (System.currentTimeMillis() + 86_400_000L)) }
    var priority by remember { mutableStateOf(AssignmentPriority.fromName(existing?.priority ?: AssignmentPriority.MEDIUM.name)) }
    var status by remember { mutableStateOf(AssignmentStatus.fromName(existing?.status ?: AssignmentStatus.NOT_STARTED.name)) }
    var reminderMinutes by remember { mutableStateOf<Int?>(existing?.reminderMinutesBefore ?: 60) }
    var showDatePicker by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }

    if (showDatePicker) {
        ShamsiDateTimePickerDialog(
            initialMillis = dueAtMillis,
            title = "انتخاب تاریخ و ساعت مهلت",
            onConfirm = { dueAtMillis = it; showDatePicker = false },
            onDismiss = { showDatePicker = false }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "ثبت تکلیف جدید" else "ویرایش تکلیف") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                errorText?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; errorText = null },
                    label = { Text("عنوان تکلیف *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("توضیحات") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                if (courses.isNotEmpty()) {
                    Text("درس مرتبط", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = selectedCourseId == null,
                            onClick = { selectedCourseId = null },
                            label = { Text("بدون درس") }
                        )
                        courses.forEach { course ->
                            FilterChip(
                                selected = selectedCourseId == course.id,
                                onClick = { selectedCourseId = course.id },
                                label = { Text(course.name) }
                            )
                        }
                    }
                }

                OutlinedButton(
                    onClick = { showDatePicker = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("مهلت: ${PersianDateUtil.formatShortShamsiDate(dueAtMillis)} ساعت ${PersianDateUtil.formatTimeFromMillis(dueAtMillis)}")
                }

                Text("اولویت", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AssignmentPriority.entries.forEach { p ->
                        FilterChip(
                            selected = priority == p,
                            onClick = { priority = p },
                            label = { Text(p.persianLabel) }
                        )
                    }
                }

                Text("وضعیت", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AssignmentStatus.entries.forEach { st ->
                        FilterChip(
                            selected = status == st,
                            onClick = { status = st },
                            label = { Text(st.persianLabel) }
                        )
                    }
                }

                Text("یادآوری قبل از مهلت", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(null to "خاموش", 30 to "۳۰ دقیقه", 60 to "۱ ساعت", 1440 to "۱ روز").forEach { (mins, label) ->
                        FilterChip(
                            selected = reminderMinutes == mins,
                            onClick = { reminderMinutes = mins },
                            label = { Text(label) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (title.trim().isBlank()) {
                    errorText = "لطفاً عنوان تکلیف را وارد کنید."
                    return@Button
                }
                onSave(
                    AssignmentEntity(
                        id = existing?.id ?: 0L,
                        courseId = selectedCourseId,
                        title = title.trim(),
                        description = description.trim(),
                        dueAtMillis = dueAtMillis,
                        priority = priority.name,
                        status = status.name,
                        reminderMinutesBefore = reminderMinutes,
                        createdAtMillis = existing?.createdAtMillis ?: System.currentTimeMillis()
                    )
                )
            }) { Text("ذخیره") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ExamEditorDialog(
    existing: ExamEntity?,
    courses: List<CourseEntity>,
    onSave: (ExamEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var selectedCourseId by remember { mutableStateOf(existing?.courseId) }
    var examAtMillis by remember { mutableLongStateOf(existing?.examAtMillis ?: (System.currentTimeMillis() + 7L * 86_400_000L)) }
    var location by remember { mutableStateOf(existing?.location ?: "") }
    var syllabus by remember { mutableStateOf(existing?.syllabus ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var reminderMinutes by remember { mutableStateOf<Int?>(existing?.reminderMinutesBefore ?: 1440) }
    var showDatePicker by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }

    if (showDatePicker) {
        ShamsiDateTimePickerDialog(
            initialMillis = examAtMillis,
            title = "انتخاب تاریخ و ساعت امتحان",
            onConfirm = { examAtMillis = it; showDatePicker = false },
            onDismiss = { showDatePicker = false }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "ثبت امتحان جدید" else "ویرایش امتحان") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                errorText?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; errorText = null },
                    label = { Text("عنوان امتحان *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (courses.isNotEmpty()) {
                    Text("درس مرتبط", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = selectedCourseId == null,
                            onClick = { selectedCourseId = null },
                            label = { Text("بدون درس") }
                        )
                        courses.forEach { course ->
                            FilterChip(
                                selected = selectedCourseId == course.id,
                                onClick = {
                                    selectedCourseId = course.id
                                    if (title.isBlank()) title = "امتحان ${course.name}"
                                },
                                label = { Text(course.name) }
                            )
                        }
                    }
                }
                OutlinedButton(
                    onClick = { showDatePicker = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("زمان: ${PersianDateUtil.formatShortShamsiDate(examAtMillis)} ساعت ${PersianDateUtil.formatTimeFromMillis(examAtMillis)}")
                }
                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("مکان برگزاری (سالن / کلاس)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = syllabus,
                    onValueChange = { syllabus = it },
                    label = { Text("سرفصل‌ها") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("یادداشت") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("یادآوری امتحان", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(null to "خاموش", 60 to "۱ ساعت قبل", 1440 to "۱ روز قبل", 4320 to "۳ روز قبل").forEach { (mins, label) ->
                        FilterChip(
                            selected = reminderMinutes == mins,
                            onClick = { reminderMinutes = mins },
                            label = { Text(label) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (title.trim().isBlank()) {
                    errorText = "لطفاً عنوان امتحان را وارد کنید."
                    return@Button
                }
                onSave(
                    ExamEntity(
                        id = existing?.id ?: 0L,
                        courseId = selectedCourseId,
                        title = title.trim(),
                        examAtMillis = examAtMillis,
                        location = location.trim(),
                        syllabus = syllabus.trim(),
                        notes = notes.trim(),
                        reminderMinutesBefore = reminderMinutes,
                        createdAtMillis = existing?.createdAtMillis ?: System.currentTimeMillis()
                    )
                )
            }) { Text("ذخیره") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}
