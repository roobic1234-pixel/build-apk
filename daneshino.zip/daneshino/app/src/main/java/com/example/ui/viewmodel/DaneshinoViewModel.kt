package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.AppContainer
import com.example.core.GpaCalculator
import com.example.core.GpaSummary
import com.example.core.GradedCourseInput
import com.example.core.PersianDateUtil
import com.example.data.backup.BackupValidationResult
import com.example.data.backup.DaneshinoBackupPayload
import com.example.data.local.AssignmentEntity
import com.example.data.local.ClassSessionEntity
import com.example.data.local.CourseAttachmentEntity
import com.example.data.local.CourseEntity
import com.example.data.local.CourseWithSessions
import com.example.data.local.ExamEntity
import com.example.data.local.FlashcardDeckEntity
import com.example.data.local.FlashcardEntity
import com.example.data.local.GoalEntity
import com.example.data.local.GoalPeriod
import com.example.data.local.NoteEntity
import com.example.data.local.StudySessionEntity
import com.example.data.prefs.PersistedTimerState
import com.example.data.prefs.ReminderMethod
import com.example.data.prefs.UserPreferences
import com.example.reminder.ClassAlarmService
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class DaneshinoDataState(
    val isLoading: Boolean = true,
    val preferences: UserPreferences = UserPreferences(),
    val coursesWithSessions: List<CourseWithSessions> = emptyList(),
    val assignments: List<AssignmentEntity> = emptyList(),
    val exams: List<ExamEntity> = emptyList(),
    val studySessions: List<StudySessionEntity> = emptyList(),
    val goals: List<GoalEntity> = emptyList(),
    val decks: List<FlashcardDeckEntity> = emptyList(),
    val flashcards: List<FlashcardEntity> = emptyList(),
    val notes: List<NoteEntity> = emptyList(),
    val attachments: List<CourseAttachmentEntity> = emptyList()
) {
    val courses: List<CourseEntity> get() = coursesWithSessions.map { it.course }
    val allSessions: List<ClassSessionEntity> get() = coursesWithSessions.flatMap { it.sessions }

    val gpaSummary: GpaSummary
        get() = GpaCalculator.calculateSummary(
            courses = courses.map {
                GradedCourseInput(
                    name = it.name,
                    credits = it.credits,
                    grade = it.grade,
                    term = it.term
                )
            },
            totalDegreeCredits = preferences.totalDegreeCredits
        )

    fun courseById(id: Long?): CourseEntity? = courses.firstOrNull { it.id == id }

    fun studyMinutesForGoal(goal: GoalEntity, nowMillis: Long = System.currentTimeMillis()): Int {
        val windowStart = when (GoalPeriod.fromName(goal.period)) {
            GoalPeriod.DAILY -> PersianDateUtil.startOfDayMillis(nowMillis)
            GoalPeriod.WEEKLY -> PersianDateUtil.startOfPersianWeekMillis(nowMillis)
            GoalPeriod.MONTHLY -> {
                val shamsi = PersianDateUtil.toShamsi(nowMillis)
                PersianDateUtil.shamsiToEpochMillis(shamsi.year, shamsi.month, 1, 0, 0)
            }
        }
        val seconds = studySessions
            .filter { session ->
                session.startAtMillis >= windowStart &&
                    (goal.courseId == null || session.courseId == goal.courseId)
            }
            .sumOf { it.durationSeconds }
        return (seconds / 60L).toInt()
    }
}

class DaneshinoViewModel(private val container: AppContainer) : ViewModel() {

    private val repository = container.repository
    private val preferencesRepo = container.preferencesRepository
    private val reminderController = container.reminderController
    private val backupManager = container.backupManager

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private val _pendingRestorePayload = MutableStateFlow<DaneshinoBackupPayload?>(null)
    val pendingRestorePayload: StateFlow<DaneshinoBackupPayload?> = _pendingRestorePayload.asStateFlow()

    val isAlarmPlaying: StateFlow<Boolean> = ClassAlarmService.isAlarmPlaying

    private val _nowMillis = MutableStateFlow(System.currentTimeMillis())
    val nowMillis: StateFlow<Long> = _nowMillis.asStateFlow()

    val timerState: StateFlow<PersistedTimerState> = preferencesRepo.timerStateFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PersistedTimerState())

    // Combine reactive flows in two clean stages to avoid tuple limits
    private val primaryDataFlow = combine(
        preferencesRepo.preferencesFlow,
        repository.coursesWithSessions,
        repository.allAssignments,
        repository.allExams,
        repository.allStudySessions
    ) { prefs, courses, assignments, exams, studySessions ->
        DaneshinoDataState(
            isLoading = false,
            preferences = prefs,
            coursesWithSessions = courses,
            assignments = assignments,
            exams = exams,
            studySessions = studySessions
        )
    }

    private val secondaryDataFlow = combine(
        repository.allGoals,
        repository.allDecks,
        repository.allFlashcards,
        repository.allNotes,
        repository.allAttachments
    ) { goals, decks, flashcards, notes, attachments ->
        SecondarySlice(goals, decks, flashcards, notes, attachments)
    }

    val dataState: StateFlow<DaneshinoDataState> = combine(
        primaryDataFlow,
        secondaryDataFlow
    ) { primary, secondary ->
        primary.copy(
            goals = secondary.goals,
            decks = secondary.decks,
            flashcards = secondary.flashcards,
            notes = secondary.notes,
            attachments = secondary.attachments
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DaneshinoDataState(isLoading = true)
    )

    init {
        viewModelScope.launch {
            while (isActive) {
                val now = System.currentTimeMillis()
                _nowMillis.value = now
                val ts = timerState.value
                if (StudyTimerEngine.isPhaseFinished(ts, now)) {
                    completeCurrentTimerPhase(now)
                }
                delay(1000L)
            }
        }
    }

    // --- Onboarding & Profile ---
    fun completeOnboarding(name: String) = viewModelScope.launch {
        preferencesRepo.completeOnboarding(name)
    }

    fun updateProfile(
        studentName: String,
        university: String,
        major: String,
        degreeLevel: String,
        currentTerm: String,
        totalDegreeCredits: Double
    ) = viewModelScope.launch {
        preferencesRepo.updateProfile(
            studentName = studentName,
            university = university,
            major = major,
            degreeLevel = degreeLevel,
            currentTerm = currentTerm,
            totalDegreeCredits = totalDegreeCredits
        )
        _messages.tryEmit("اطلاعات پروفایل ذخیره شد.")
    }

    fun setThemeMode(mode: AppThemeMode) = viewModelScope.launch {
        preferencesRepo.setThemeMode(mode)
    }

    // --- Reminder Settings & Actions ---
    fun setClassRemindersEnabled(enabled: Boolean) = viewModelScope.launch {
        preferencesRepo.setClassRemindersEnabled(enabled)
        val updated = preferencesRepo.getPreferencesOnce()
        repository.rescheduleAllReminders(updated)
        if (!enabled) reminderController.stopAlarmAudio()
    }

    fun setClassReminderMinutes(minutes: Int) = viewModelScope.launch {
        preferencesRepo.setClassReminderMinutes(minutes)
        val updated = preferencesRepo.getPreferencesOnce()
        repository.rescheduleAllReminders(updated)
    }

    fun setClassReminderMethod(method: ReminderMethod) = viewModelScope.launch {
        preferencesRepo.setClassReminderMethod(method)
        val updated = preferencesRepo.getPreferencesOnce()
        repository.rescheduleAllReminders(updated)
    }

    fun setAssignmentRemindersEnabled(enabled: Boolean) = viewModelScope.launch {
        preferencesRepo.setAssignmentRemindersEnabled(enabled)
        val updated = preferencesRepo.getPreferencesOnce()
        repository.rescheduleAllReminders(updated)
    }

    fun setExamRemindersEnabled(enabled: Boolean) = viewModelScope.launch {
        preferencesRepo.setExamRemindersEnabled(enabled)
        val updated = preferencesRepo.getPreferencesOnce()
        repository.rescheduleAllReminders(updated)
    }

    fun canScheduleExactAlarms(): Boolean = reminderController.canScheduleExactAlarms()

    fun isDeviceSilencedOrDnd(): Boolean = reminderController.isDeviceSilencedOrDnd()

    fun testAlarm() {
        if (reminderController.isDeviceSilencedOrDnd()) {
            _messages.tryEmit("گوشی در حالت بی‌صدا یا مزاحم نشوید است؛ دانشینو تنظیمات سیستم را دور نمی‌زند.")
        } else {
            reminderController.triggerTestAlarm()
            _messages.tryEmit("آزمون آلارم صوتی شروع شد. برای قطع صدا روی «توقف پخش صدا» بزنید.")
        }
    }

    fun stopAlarmAudio() {
        reminderController.stopAlarmAudio()
        _messages.tryEmit("پخش صدا متوقف شد.")
    }

    fun sendTestNotification() {
        reminderController.sendTestNotification()
        _messages.tryEmit("اعلان آزمایشی ارسال شد.")
    }

    // --- Courses ---
    fun saveCourseWithSessions(course: CourseEntity, sessions: List<ClassSessionEntity>) = viewModelScope.launch {
        val prefs = preferencesRepo.getPreferencesOnce()
        repository.saveCourseWithSessions(course, sessions, prefs)
        _messages.tryEmit(if (course.id > 0L) "درس ویرایش شد." else "درس جدید اضافه شد.")
    }

    fun toggleCourseFavorite(course: CourseEntity) = viewModelScope.launch {
        repository.toggleCourseFavorite(course)
    }

    fun updateCourseGrade(courseId: Long, grade: Double?) = viewModelScope.launch {
        repository.updateCourseGrade(courseId, grade)
        _messages.tryEmit("نمره ذخیره شد.")
    }

    fun deleteCourse(courseId: Long) = viewModelScope.launch {
        repository.deleteCourse(courseId)
        _messages.tryEmit("درس حذف شد و تمام یادآوری‌های آن لغو شدند.")
    }

    // --- Assignments ---
    fun saveAssignment(assignment: AssignmentEntity) = viewModelScope.launch {
        val prefs = preferencesRepo.getPreferencesOnce()
        repository.saveAssignment(assignment, prefs)
        _messages.tryEmit(if (assignment.id > 0L) "تکلیف به‌روزرسانی شد." else "تکلیف ثبت شد.")
    }

    fun deleteAssignment(assignmentId: Long) = viewModelScope.launch {
        repository.deleteAssignment(assignmentId)
        _messages.tryEmit("تکلیف حذف شد.")
    }

    // --- Exams ---
    fun saveExam(exam: ExamEntity) = viewModelScope.launch {
        val prefs = preferencesRepo.getPreferencesOnce()
        repository.saveExam(exam, prefs)
        _messages.tryEmit(if (exam.id > 0L) "امتحان به‌روزرسانی شد." else "امتحان ثبت شد.")
    }

    fun deleteExam(examId: Long) = viewModelScope.launch {
        repository.deleteExam(examId)
        _messages.tryEmit("امتحان حذف شد.")
    }

    // --- Study Timer & Sessions ---
    fun configureTimer(focusMinutes: Int, breakMinutes: Int, courseId: Long?) = viewModelScope.launch {
        val current = timerState.value
        if (current.isRunning) return@launch
        preferencesRepo.saveTimerState(
            current.copy(
                focusMinutes = focusMinutes.coerceIn(1, 240),
                breakMinutes = breakMinutes.coerceIn(1, 60),
                selectedCourseId = courseId,
                isBreakPhase = false
            )
        )
    }

    fun startTimer(courseId: Long?) = viewModelScope.launch {
        val now = System.currentTimeMillis()
        val updated = StudyTimerEngine.start(timerState.value, now, courseId)
        preferencesRepo.saveTimerState(updated)
    }

    fun pauseTimer() = viewModelScope.launch {
        val updated = StudyTimerEngine.pause(timerState.value, System.currentTimeMillis())
        preferencesRepo.saveTimerState(updated)
    }

    fun resumeTimer() = viewModelScope.launch {
        val updated = StudyTimerEngine.resume(timerState.value, System.currentTimeMillis())
        preferencesRepo.saveTimerState(updated)
    }

    fun stopAndSaveStudyTimer() = viewModelScope.launch {
        val now = System.currentTimeMillis()
        val state = timerState.value
        val elapsed = StudyTimerEngine.elapsedSeconds(state, now)
        if (!state.isBreakPhase && elapsed >= 60L) {
            saveCompletedStudySession(state, elapsed, now)
            _messages.tryEmit("جلسه مطالعه (${PersianDateUtil.formatDurationMinutes((elapsed / 60L).toInt())}) ذخیره شد.")
        } else if (!state.isBreakPhase && elapsed > 0L) {
            _messages.tryEmit("جلسات کمتر از ۱ دقیقه در آمار ذخیره نمی‌شوند.")
        }
        preferencesRepo.saveTimerState(StudyTimerEngine.reset(state))
    }

    fun resetTimer() = viewModelScope.launch {
        preferencesRepo.saveTimerState(StudyTimerEngine.reset(timerState.value))
    }

    fun deleteStudySession(id: Long) = viewModelScope.launch {
        repository.deleteStudySession(id)
        _messages.tryEmit("جلسه مطالعه حذف شد.")
    }

    private suspend fun completeCurrentTimerPhase(now: Long) {
        val state = timerState.value
        if (!state.isBreakPhase) {
            val targetSec = StudyTimerEngine.phaseTargetSeconds(state)
            saveCompletedStudySession(state, targetSec, now)
            _messages.tryEmit("بازه مطالعه تمام شد و در آمار ثبت گردید! وقت استراحت است.")
        } else {
            _messages.tryEmit("زمان استراحت تمام شد. آماده بازه مطالعه بعدی هستید.")
        }
        preferencesRepo.saveTimerState(StudyTimerEngine.switchPhaseAfterComplete(state, now))
    }

    private suspend fun saveCompletedStudySession(
        state: PersistedTimerState,
        durationSeconds: Long,
        endMillis: Long
    ) {
        val startMillis = if (state.sessionStartedEpochMillis > 0L) {
            state.sessionStartedEpochMillis
        } else {
            (endMillis - durationSeconds * 1000L).coerceAtLeast(0L)
        }
        val courseName = dataState.value.courseById(state.selectedCourseId)?.name ?: "مطالعه آزاد"
        repository.insertStudySession(
            StudySessionEntity(
                courseId = state.selectedCourseId,
                courseNameSnapshot = courseName,
                startAtMillis = startMillis,
                endAtMillis = endMillis,
                durationSeconds = durationSeconds,
                dateKey = PersianDateUtil.dateKey(startMillis)
            )
        )
    }

    // --- Goals ---
    fun saveGoal(goal: GoalEntity) = viewModelScope.launch {
        repository.saveGoal(goal)
        _messages.tryEmit(if (goal.id > 0L) "هدف ویرایش شد." else "هدف جدید ثبت شد.")
    }

    fun deleteGoal(id: Long) = viewModelScope.launch {
        repository.deleteGoal(id)
        _messages.tryEmit("هدف حذف شد.")
    }

    // --- Flashcards ---
    fun saveDeck(deck: FlashcardDeckEntity) = viewModelScope.launch {
        repository.saveDeck(deck)
        _messages.tryEmit(if (deck.id > 0L) "دسته فلش‌کارت ویرایش شد." else "دسته فلش‌کارت ساخته شد.")
    }

    fun deleteDeck(id: Long) = viewModelScope.launch {
        repository.deleteDeck(id)
        _messages.tryEmit("دسته فلش‌کارت حذف شد.")
    }

    fun saveFlashcard(card: FlashcardEntity) = viewModelScope.launch {
        repository.saveFlashcard(card)
        _messages.tryEmit(if (card.id > 0L) "کارت ویرایش شد." else "کارت اضافه شد.")
    }

    fun markFlashcardReviewed(card: FlashcardEntity, known: Boolean) = viewModelScope.launch {
        repository.saveFlashcard(
            card.copy(
                reviewCount = card.reviewCount + 1,
                knownCount = if (known) card.knownCount + 1 else card.knownCount,
                lastReviewedAtMillis = System.currentTimeMillis()
            )
        )
    }

    fun deleteFlashcard(id: Long) = viewModelScope.launch {
        repository.deleteFlashcard(id)
        _messages.tryEmit("کارت حذف شد.")
    }

    // --- Notes ---
    fun saveNote(note: NoteEntity) = viewModelScope.launch {
        repository.saveNote(note.copy(updatedAtMillis = System.currentTimeMillis()))
        _messages.tryEmit(if (note.id > 0L) "یادداشت ویرایش شد." else "یادداشت ذخیره شد.")
    }

    fun deleteNote(id: Long) = viewModelScope.launch {
        repository.deleteNote(id)
        _messages.tryEmit("یادداشت حذف شد.")
    }

    // --- Attachments ---
    fun addAttachment(attachment: CourseAttachmentEntity) = viewModelScope.launch {
        repository.addAttachment(attachment)
        _messages.tryEmit("فایل به درس پیوست شد.")
    }

    fun deleteAttachment(id: Long) = viewModelScope.launch {
        repository.deleteAttachment(id)
        _messages.tryEmit("پیوست حذف شد.")
    }

    // --- Backup & Restore ---
    suspend fun buildBackupJson(): String = backupManager.exportToJson()

    fun inspectBackupJson(rawJson: String) {
        when (val result = backupManager.validateJson(rawJson)) {
            is BackupValidationResult.Valid -> {
                _pendingRestorePayload.value = result.payload
            }
            is BackupValidationResult.Invalid -> {
                _messages.tryEmit(result.errorMessage)
            }
        }
    }

    fun cancelPendingRestore() {
        _pendingRestorePayload.value = null
    }

    fun confirmPendingRestore() = viewModelScope.launch {
        val payload = _pendingRestorePayload.value ?: return@launch
        try {
            backupManager.restoreFromValidatedPayload(payload)
            _pendingRestorePayload.value = null
            _messages.tryEmit("پشتیبان با موفقیت بازیابی شد و یادآوری‌ها بازسازی شدند.")
        } catch (e: Exception) {
            _pendingRestorePayload.value = null
            _messages.tryEmit("خطا هنگام بازیابی اطلاعات. داده‌های فعلی حفظ شدند.")
        }
    }

    fun emitMessage(text: String) {
        _messages.tryEmit(text)
    }

    private data class SecondarySlice(
        val goals: List<GoalEntity>,
        val decks: List<FlashcardDeckEntity>,
        val flashcards: List<FlashcardEntity>,
        val notes: List<NoteEntity>,
        val attachments: List<CourseAttachmentEntity>
    )

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DaneshinoViewModel(container) as T
        }
    }
}
