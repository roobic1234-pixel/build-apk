package com.example

import com.example.core.GpaCalculator
import com.example.core.GradedCourseInput
import com.example.core.TargetGpaResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GpaCalculatorTest {

    @Test
    fun `weighted GPA follows sum of grade times credits divided by credits`() {
        val gpa = GpaCalculator.calculateWeightedGpa(
            listOf(
                18.0 to 3.0,
                16.0 to 2.0,
                20.0 to 1.0
            )
        )
        // (54 + 32 + 20) / 6 = 106 / 6 = 17.6667
        assertEquals(17.6667, gpa ?: 0.0, 0.001)
    }

    @Test
    fun `empty course list returns null GPA and zero credits`() {
        val summary = GpaCalculator.calculateSummary(emptyList(), totalDegreeCredits = 140.0)
        assertNull(summary.overallGpa)
        assertEquals(0.0, summary.passedCredits, 0.001)
        assertEquals(140.0, summary.remainingCredits, 0.001)
        assertTrue(summary.termGpas.isEmpty())
    }

    @Test
    fun `summary separates passed credits and term GPAs properly`() {
        val courses = listOf(
            GradedCourseInput("ریاضی ۱", 3.0, 18.0, "۱۴۰۴-۱"),
            GradedCourseInput("فیزیک ۱", 3.0, 8.5, "۱۴۰۴-۱"), // failed (< 10)
            GradedCourseInput("برنامه‌نویسی", 4.0, 19.0, "۱۴۰۴-۲"),
            GradedCourseInput("زبان", 2.0, null, "۱۴۰۴-۲") // ungraded
        )
        val summary = GpaCalculator.calculateSummary(courses, totalDegreeCredits = 140.0)
        // Overall: (54 + 25.5 + 76) / 10 = 15.55
        assertEquals(15.55, summary.overallGpa ?: 0.0, 0.001)
        // Passed credits: 3 + 4 = 7
        assertEquals(7.0, summary.passedCredits, 0.001)
        assertEquals(133.0, summary.remainingCredits, 0.001)
        // Term 1404-1: (54 + 25.5) / 6 = 13.25
        assertEquals(13.25, summary.termGpas["۱۴۰۴-۱"] ?: 0.0, 0.001)
        assertEquals(19.0, summary.termGpas["۱۴۰۴-۲"] ?: 0.0, 0.001)
    }

    @Test
    fun `target GPA calculator returns achievable required grade`() {
        // Current 15 over 20 credits (300 pts), upcoming 20 credits, target 17 (680 pts) -> needs 380 / 20 = 19.0
        val result = GpaCalculator.calculateRequiredAverage(
            currentGpa = 15.0,
            completedCredits = 20.0,
            upcomingCredits = 20.0,
            targetGpa = 17.0
        )
        assertTrue(result is TargetGpaResult.Achievable)
        assertEquals(19.0, (result as TargetGpaResult.Achievable).requiredAverage, 0.001)
    }

    @Test
    fun `target GPA calculator detects mathematically impossible goal above 20`() {
        // Current 12 over 100 credits, upcoming 10 credits, target 18 -> needs (1980 - 1200)/10 = 78 > 20
        val result = GpaCalculator.calculateRequiredAverage(
            currentGpa = 12.0,
            completedCredits = 100.0,
            upcomingCredits = 10.0,
            targetGpa = 18.0
        )
        assertTrue(result is TargetGpaResult.Impossible)
        val impossible = result as TargetGpaResult.Impossible
        assertTrue(impossible.explanation.contains("ممکن نیست"))
    }

    @Test
    fun `target GPA calculator rejects out-of-range target`() {
        val result = GpaCalculator.calculateRequiredAverage(15.0, 20.0, 10.0, 21.5)
        assertTrue(result is TargetGpaResult.InvalidInput)
    }
}
