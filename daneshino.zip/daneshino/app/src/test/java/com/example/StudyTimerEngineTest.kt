package com.example

import com.example.data.prefs.PersistedTimerState
import com.example.ui.viewmodel.StudyTimerEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StudyTimerEngineTest {

    @Test
    fun `presets contain 25-5, 50-10, and 90-15`() {
        val pairs = StudyTimerEngine.presets.map { it.focusMinutes to it.breakMinutes }
        assertEquals(listOf(25 to 5, 50 to 10, 90 to 15), pairs)
    }

    @Test
    fun `timer continues accurately across background interval and pause-resume`() {
        val initial = PersistedTimerState(focusMinutes = 25, breakMinutes = 5)
        val t0 = 1_000_000L

        val started = StudyTimerEngine.start(initial, nowMillis = t0, courseId = 42L)
        assertTrue(started.isRunning)
        assertFalse(started.isPaused)

        // Simulate 10 minutes passing while app is in background
        val t10m = t0 + 600_000L
        assertEquals(600L, StudyTimerEngine.elapsedSeconds(started, t10m))
        assertEquals(900L, StudyTimerEngine.remainingSeconds(started, t10m))
        assertFalse(StudyTimerEngine.isPhaseFinished(started, t10m))

        // Pause at 10m and wait 5m paused
        val paused = StudyTimerEngine.pause(started, nowMillis = t10m)
        assertTrue(paused.isPaused)
        assertEquals(600L, StudyTimerEngine.elapsedSeconds(paused, t10m + 300_000L))

        // Resume and run remaining 15m
        val resumed = StudyTimerEngine.resume(paused, nowMillis = t10m + 300_000L)
        val finishTime = t10m + 300_000L + 900_000L
        assertEquals(1500L, StudyTimerEngine.elapsedSeconds(resumed, finishTime))
        assertEquals(0L, StudyTimerEngine.remainingSeconds(resumed, finishTime))
        assertTrue(StudyTimerEngine.isPhaseFinished(resumed, finishTime))

        // Switch phase transitions cleanly to break phase
        val nextPhase = StudyTimerEngine.switchPhaseAfterComplete(resumed, finishTime)
        assertFalse(nextPhase.isRunning)
        assertTrue(nextPhase.isBreakPhase)
        assertEquals(300L, StudyTimerEngine.phaseTargetSeconds(nextPhase))
    }

    @Test
    fun `reset clears running timer cleanly`() {
        val started = StudyTimerEngine.start(PersistedTimerState(), nowMillis = 10_000L, courseId = 1L)
        val reset = StudyTimerEngine.reset(started)
        assertFalse(reset.isRunning)
        assertFalse(reset.isPaused)
        assertFalse(reset.isBreakPhase)
        assertEquals(0L, reset.accumulatedSeconds)
    }
}
