package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DaneshinoDao {

    // --- Courses & Sessions ---
    @Transaction
    @Query("SELECT * FROM courses ORDER BY isFavorite DESC, createdAtMillis DESC")
    fun observeCoursesWithSessions(): Flow<List<CourseWithSessions>>

    @Query("SELECT * FROM courses ORDER BY isFavorite DESC, name ASC")
    fun observeAllCourses(): Flow<List<CourseEntity>>

    @Transaction
    @Query("SELECT * FROM courses WHERE id = :courseId")
    fun observeCourseWithSessions(courseId: Long): Flow<CourseWithSessions?>

    @Query("SELECT * FROM courses")
    suspend fun getAllCoursesOnce(): List<CourseEntity>

    @Query("SELECT * FROM courses WHERE id = :courseId")
    suspend fun getCourseById(courseId: Long): CourseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourse(course: CourseEntity): Long

    @Update
    suspend fun updateCourse(course: CourseEntity)

    @Query("DELETE FROM courses WHERE id = :courseId")
    suspend fun deleteCourseById(courseId: Long)

    @Query("SELECT * FROM class_sessions ORDER BY dayOfWeek ASC, startMinuteOfDay ASC")
    fun observeAllSessions(): Flow<List<ClassSessionEntity>>

    @Query("SELECT * FROM class_sessions")
    suspend fun getAllSessionsOnce(): List<ClassSessionEntity>

    @Query("SELECT * FROM class_sessions WHERE courseId = :courseId ORDER BY dayOfWeek ASC, startMinuteOfDay ASC")
    suspend fun getSessionsForCourseOnce(courseId: Long): List<ClassSessionEntity>

    @Transaction
    @Query("SELECT * FROM class_sessions WHERE id = :sessionId")
    suspend fun getSessionWithCourse(sessionId: Long): SessionWithCourse?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: ClassSessionEntity): Long

    @Update
    suspend fun updateSession(session: ClassSessionEntity)

    @Query("DELETE FROM class_sessions WHERE id = :sessionId")
    suspend fun deleteSessionById(sessionId: Long)

    @Query("DELETE FROM class_sessions WHERE courseId = :courseId")
    suspend fun deleteSessionsForCourse(courseId: Long)

    // --- Assignments ---
    @Query("SELECT * FROM assignments ORDER BY dueAtMillis ASC")
    fun observeAllAssignments(): Flow<List<AssignmentEntity>>

    @Query("SELECT * FROM assignments")
    suspend fun getAllAssignmentsOnce(): List<AssignmentEntity>

    @Query("SELECT * FROM assignments WHERE courseId = :courseId")
    suspend fun getAssignmentsForCourseOnce(courseId: Long): List<AssignmentEntity>

    @Query("SELECT * FROM assignments WHERE id = :id")
    suspend fun getAssignmentById(id: Long): AssignmentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssignment(assignment: AssignmentEntity): Long

    @Update
    suspend fun updateAssignment(assignment: AssignmentEntity)

    @Query("DELETE FROM assignments WHERE id = :id")
    suspend fun deleteAssignmentById(id: Long)

    // --- Exams ---
    @Query("SELECT * FROM exams ORDER BY examAtMillis ASC")
    fun observeAllExams(): Flow<List<ExamEntity>>

    @Query("SELECT * FROM exams")
    suspend fun getAllExamsOnce(): List<ExamEntity>

    @Query("SELECT * FROM exams WHERE courseId = :courseId")
    suspend fun getExamsForCourseOnce(courseId: Long): List<ExamEntity>

    @Query("SELECT * FROM exams WHERE id = :id")
    suspend fun getExamById(id: Long): ExamEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExam(exam: ExamEntity): Long

    @Update
    suspend fun updateExam(exam: ExamEntity)

    @Query("DELETE FROM exams WHERE id = :id")
    suspend fun deleteExamById(id: Long)

    // --- Study Sessions ---
    @Query("SELECT * FROM study_sessions ORDER BY startAtMillis DESC")
    fun observeAllStudySessions(): Flow<List<StudySessionEntity>>

    @Query("SELECT * FROM study_sessions")
    suspend fun getAllStudySessionsOnce(): List<StudySessionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudySession(session: StudySessionEntity): Long

    @Query("DELETE FROM study_sessions WHERE id = :id")
    suspend fun deleteStudySessionById(id: Long)

    // --- Goals ---
    @Query("SELECT * FROM goals ORDER BY createdAtMillis DESC")
    fun observeAllGoals(): Flow<List<GoalEntity>>

    @Query("SELECT * FROM goals")
    suspend fun getAllGoalsOnce(): List<GoalEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: GoalEntity): Long

    @Update
    suspend fun updateGoal(goal: GoalEntity)

    @Query("DELETE FROM goals WHERE id = :id")
    suspend fun deleteGoalById(id: Long)

    // --- Flashcards ---
    @Query("SELECT * FROM flashcard_decks ORDER BY createdAtMillis DESC")
    fun observeAllDecks(): Flow<List<FlashcardDeckEntity>>

    @Query("SELECT * FROM flashcard_decks")
    suspend fun getAllDecksOnce(): List<FlashcardDeckEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDeck(deck: FlashcardDeckEntity): Long

    @Update
    suspend fun updateDeck(deck: FlashcardDeckEntity)

    @Query("DELETE FROM flashcard_decks WHERE id = :id")
    suspend fun deleteDeckById(id: Long)

    @Query("SELECT * FROM flashcards ORDER BY id ASC")
    fun observeAllFlashcards(): Flow<List<FlashcardEntity>>

    @Query("SELECT * FROM flashcards WHERE deckId = :deckId ORDER BY id ASC")
    fun observeFlashcardsForDeck(deckId: Long): Flow<List<FlashcardEntity>>

    @Query("SELECT * FROM flashcards")
    suspend fun getAllFlashcardsOnce(): List<FlashcardEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlashcard(card: FlashcardEntity): Long

    @Update
    suspend fun updateFlashcard(card: FlashcardEntity)

    @Query("DELETE FROM flashcards WHERE id = :id")
    suspend fun deleteFlashcardById(id: Long)

    // --- Notes ---
    @Query("SELECT * FROM notes ORDER BY updatedAtMillis DESC")
    fun observeAllNotes(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes")
    suspend fun getAllNotesOnce(): List<NoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity): Long

    @Update
    suspend fun updateNote(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteNoteById(id: Long)

    // --- Attachments ---
    @Query("SELECT * FROM course_attachments ORDER BY addedAtMillis DESC")
    fun observeAllAttachments(): Flow<List<CourseAttachmentEntity>>

    @Query("SELECT * FROM course_attachments WHERE courseId = :courseId ORDER BY addedAtMillis DESC")
    fun observeAttachmentsForCourse(courseId: Long): Flow<List<CourseAttachmentEntity>>

    @Query("SELECT * FROM course_attachments")
    suspend fun getAllAttachmentsOnce(): List<CourseAttachmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttachment(attachment: CourseAttachmentEntity): Long

    @Delete
    suspend fun deleteAttachment(attachment: CourseAttachmentEntity)

    @Query("DELETE FROM course_attachments WHERE id = :id")
    suspend fun deleteAttachmentById(id: Long)

    // --- Backup Restore Atomic Operations ---
    @Query("DELETE FROM course_attachments")
    suspend fun clearAttachments()

    @Query("DELETE FROM notes")
    suspend fun clearNotes()

    @Query("DELETE FROM flashcards")
    suspend fun clearFlashcards()

    @Query("DELETE FROM flashcard_decks")
    suspend fun clearDecks()

    @Query("DELETE FROM goals")
    suspend fun clearGoals()

    @Query("DELETE FROM study_sessions")
    suspend fun clearStudySessions()

    @Query("DELETE FROM exams")
    suspend fun clearExams()

    @Query("DELETE FROM assignments")
    suspend fun clearAssignments()

    @Query("DELETE FROM class_sessions")
    suspend fun clearSessions()

    @Query("DELETE FROM courses")
    suspend fun clearCourses()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCoursesBulk(items: List<CourseEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessionsBulk(items: List<ClassSessionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssignmentsBulk(items: List<AssignmentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExamsBulk(items: List<ExamEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudySessionsBulk(items: List<StudySessionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoalsBulk(items: List<GoalEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDecksBulk(items: List<FlashcardDeckEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlashcardsBulk(items: List<FlashcardEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotesBulk(items: List<NoteEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttachmentsBulk(items: List<CourseAttachmentEntity>)

    @Transaction
    suspend fun replaceAllData(
        courses: List<CourseEntity>,
        sessions: List<ClassSessionEntity>,
        assignments: List<AssignmentEntity>,
        exams: List<ExamEntity>,
        studySessions: List<StudySessionEntity>,
        goals: List<GoalEntity>,
        decks: List<FlashcardDeckEntity>,
        flashcards: List<FlashcardEntity>,
        notes: List<NoteEntity>,
        attachments: List<CourseAttachmentEntity>
    ) {
        clearAttachments()
        clearNotes()
        clearFlashcards()
        clearDecks()
        clearGoals()
        clearStudySessions()
        clearExams()
        clearAssignments()
        clearSessions()
        clearCourses()

        if (courses.isNotEmpty()) insertCoursesBulk(courses)
        if (sessions.isNotEmpty()) insertSessionsBulk(sessions)
        if (assignments.isNotEmpty()) insertAssignmentsBulk(assignments)
        if (exams.isNotEmpty()) insertExamsBulk(exams)
        if (studySessions.isNotEmpty()) insertStudySessionsBulk(studySessions)
        if (goals.isNotEmpty()) insertGoalsBulk(goals)
        if (decks.isNotEmpty()) insertDecksBulk(decks)
        if (flashcards.isNotEmpty()) insertFlashcardsBulk(flashcards)
        if (notes.isNotEmpty()) insertNotesBulk(notes)
        if (attachments.isNotEmpty()) insertAttachmentsBulk(attachments)
    }
}
