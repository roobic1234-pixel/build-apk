package com.example.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.data.local.AssignmentEntity
import com.example.data.local.ClassSessionEntity
import com.example.data.local.CourseEntity
import com.example.data.local.ExamEntity
import com.example.data.prefs.UserPreferences

class AndroidReminderScheduler(private val context: Context) : ReminderController {

    private val alarmManager: AlarmManager
        get() = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    override fun canScheduleExactAlarms(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    override fun isDeviceSilencedOrDnd(): Boolean = ClassAlarmService.isSilencedOrDnd(context)

    override fun scheduleClassSessionReminder(
        session: ClassSessionEntity,
        course: CourseEntity,
        prefs: UserPreferences
    ) {
        if (!prefs.classRemindersEnabled) {
            cancelClassSessionReminder(session.id)
            return
        }

        val triggerAtMillis = ReminderTriggerCalculator.nextClassTriggerMillis(
            dayOfWeekPersian = session.dayOfWeek,
            startMinuteOfDay = session.startMinuteOfDay,
            leadMinutesBefore = prefs.classReminderMinutesBefore,
            repeatWeekly = session.repeatWeekly
        ) ?: run {
            cancelClassSessionReminder(session.id)
            return
        }

        val requestCode = ReminderIds.classRequestCode(session.id)
        val pendingIntent = buildClassPendingIntent(session.id, course.id, requestCode, createIfMissing = true)
            ?: return
        scheduleAlarmAt(triggerAtMillis, pendingIntent)
    }

    override fun cancelClassSessionReminder(sessionId: Long) {
        val requestCode = ReminderIds.classRequestCode(sessionId)
        val existing = buildClassPendingIntent(sessionId, -1L, requestCode, createIfMissing = false)
        if (existing != null) {
            alarmManager.cancel(existing)
            existing.cancel()
        }
        ReminderNotificationHelper.cancelNotification(context, requestCode)
        ClassAlarmService.stopIfSessionMatches(context, sessionId)
    }

    override fun scheduleAssignmentReminder(assignment: AssignmentEntity, courseName: String) {
        val triggerAtMillis = ReminderTriggerCalculator.oneShotTriggerMillis(
            eventAtMillis = assignment.dueAtMillis,
            reminderMinutesBefore = assignment.reminderMinutesBefore
        ) ?: run {
            cancelAssignmentReminder(assignment.id)
            return
        }

        val requestCode = ReminderIds.assignmentRequestCode(assignment.id)
        val pendingIntent = buildAssignmentPendingIntent(assignment.id, requestCode, createIfMissing = true)
            ?: return
        scheduleAlarmAt(triggerAtMillis, pendingIntent)
    }

    override fun cancelAssignmentReminder(assignmentId: Long) {
        val requestCode = ReminderIds.assignmentRequestCode(assignmentId)
        val existing = buildAssignmentPendingIntent(assignmentId, requestCode, createIfMissing = false)
        if (existing != null) {
            alarmManager.cancel(existing)
            existing.cancel()
        }
        ReminderNotificationHelper.cancelNotification(context, requestCode)
    }

    override fun scheduleExamReminder(exam: ExamEntity, courseName: String) {
        val triggerAtMillis = ReminderTriggerCalculator.oneShotTriggerMillis(
            eventAtMillis = exam.examAtMillis,
            reminderMinutesBefore = exam.reminderMinutesBefore
        ) ?: run {
            cancelExamReminder(exam.id)
            return
        }

        val requestCode = ReminderIds.examRequestCode(exam.id)
        val pendingIntent = buildExamPendingIntent(exam.id, requestCode, createIfMissing = true)
            ?: return
        scheduleAlarmAt(triggerAtMillis, pendingIntent)
    }

    override fun cancelExamReminder(examId: Long) {
        val requestCode = ReminderIds.examRequestCode(examId)
        val existing = buildExamPendingIntent(examId, requestCode, createIfMissing = false)
        if (existing != null) {
            alarmManager.cancel(existing)
            existing.cancel()
        }
        ReminderNotificationHelper.cancelNotification(context, requestCode)
    }

    override fun triggerTestAlarm() {
        ClassAlarmService.start(
            context = context,
            sessionId = -999L,
            courseName = "آزمون آلارم صوتی دانشینو",
            startTimeText = "هم‌اکنون"
        )
    }

    override fun sendTestNotification() {
        ReminderNotificationHelper.showTestNotification(context)
    }

    override fun stopAlarmAudio() {
        ClassAlarmService.stop(context)
    }

    override fun stopAlarmIfSessionMatches(sessionId: Long) {
        ClassAlarmService.stopIfSessionMatches(context, sessionId)
    }

    private fun scheduleAlarmAt(triggerAtMillis: Long, pendingIntent: PendingIntent) {
        try {
            if (canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            }
        } catch (_: SecurityException) {
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAtMillis,
                pendingIntent
            )
        }
    }

    private fun buildClassPendingIntent(
        sessionId: Long,
        courseId: Long,
        requestCode: Int,
        createIfMissing: Boolean
    ): PendingIntent? {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ReminderReceiver.ACTION_CLASS_REMINDER
            putExtra(ReminderReceiver.EXTRA_ENTITY_ID, sessionId)
            putExtra(ReminderReceiver.EXTRA_COURSE_ID, courseId)
        }
        val flags = (if (createIfMissing) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE) or
            PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, requestCode, intent, flags)
    }

    private fun buildAssignmentPendingIntent(
        assignmentId: Long,
        requestCode: Int,
        createIfMissing: Boolean
    ): PendingIntent? {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ReminderReceiver.ACTION_ASSIGNMENT_REMINDER
            putExtra(ReminderReceiver.EXTRA_ENTITY_ID, assignmentId)
        }
        val flags = (if (createIfMissing) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE) or
            PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, requestCode, intent, flags)
    }

    private fun buildExamPendingIntent(
        examId: Long,
        requestCode: Int,
        createIfMissing: Boolean
    ): PendingIntent? {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ReminderReceiver.ACTION_EXAM_REMINDER
            putExtra(ReminderReceiver.EXTRA_ENTITY_ID, examId)
        }
        val flags = (if (createIfMissing) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE) or
            PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, requestCode, intent, flags)
    }
}
